#!/usr/bin/env bash
# Hapus mylandx. Tambahkan --purge untuk sekaligus menghapus datamu (tugas, alarm, statistik).
set -euo pipefail
PREFIX="${HOME}/.local"
APP_ID="org.mylandx.Mylandx"
rm -rf "${PREFIX}/lib/mylandx"
rm -f "${PREFIX}/bin/mylandx" \
      "${PREFIX}/share/applications/${APP_ID}.desktop" \
      "${PREFIX}/share/icons/hicolor/scalable/apps/${APP_ID}.svg" \
      "${PREFIX}/share/icons/hicolor/256x256/apps/${APP_ID}.png" \
      "${XDG_CONFIG_HOME:-$HOME/.config}/autostart/mylandx.desktop"
if [ "${1:-}" = "--purge" ]; then
    rm -rf "${XDG_DATA_HOME:-$HOME/.local/share}/mylandx"
    echo "Data ikut dihapus."
else
    echo "Data tetap disimpan di ${XDG_DATA_HOME:-$HOME/.local/share}/mylandx (pakai --purge untuk menghapusnya)."
fi
echo "mylandx dihapus."
