# mylandx

App desktop ringan untuk Fedora Linux: **pengingat tugas, timer belajar (Pomodoro), alarm, jam, dan kalender**.
Dibuat dengan Python + GTK4 — tidak butuh Electron, tidak ada layanan latar yang berat, datanya lokal di komputermu.

## Pasang
```bash
tar xzf mylandx.tar.gz && cd mylandx-app
./install.sh
```
Lalu buka dari menu aplikasi (cari "mylandx") atau ketik `mylandx` di terminal.
Mau coba tanpa memasang? `./bin/mylandx`

Dependensi (dipasang otomatis kalau kurang): `python3-gobject`, `gtk4`, `python3-cairo`, `pipewire-utils`, `mpv` (pemutar musik).

## Fitur
| Halaman | Isi |
|---|---|
| **Beranda** | Jam analog + digital, tanggal Masehi + **Hijriyah**, **pemberitahuan di dekat jam** (libur nasional, cuti bersama, hari nasional/internasional, peristiwa Hijriyah — hari ini s/d 7 hari ke depan), jam WIB/WITA/WIT/UTC, ringkasan tugas, alarm, fokus, **sholat berikutnya** |
| **Tugas** | Tambah cepat (Enter), tenggat, prioritas, catatan, pengingat (tepat waktu s/d 1 hari sebelum), filter, penanda terlambat |
| **Fokus** | Timer Pomodoro (fokus / istirahat / istirahat panjang), durasi bebas, kaitkan ke tugas, statistik 7 hari |
| **Alarm** | Banyak alarm, ulang per hari (hari kerja, akhir pekan, dst.), tunda 5 menit, suara lonceng |
| **Kalender** | Tampilan bulan dengan **angka Hijriyah** di bawah tiap tanggal, titik warna (merah = libur, kuning = cuti bersama, ungu = hari nasional/internasional/Hijriyah), daftar peristiwa per tanggal & per bulan, klik 2x untuk tambah tugas |
| **Sholat** | Jadwal 5 waktu (+ terbit) untuk **semua negara** (pilih negara → kota, atau isi koordinat manual), hitung mundur ke sholat berikutnya, tombol aktif/mati per sholat, **notifikasi + adzan** saat waktunya tiba, tes adzan |
| **Catatan** | Editor teks (tombol *Hapus* di tiap catatan) dengan simpan otomatis (±0,6 detik setelah berhenti mengetik), cari, sematkan, hitung kata. Cadangan berlapis: `data.bak.json` + snapshot harian 14 hari di `backups/`, dan data rusak dipulihkan otomatis |
| **Musik** | Pemutar **lokal**: tambah file/folder musikmu, putar dengan antrean + acak/ulang, favorit, dan **album buatan sendiri** untuk memisahkan lagu per kategori. Bisa hapus lagu dari daftar (file aslinya tidak disentuh), keluarkan dari album, ubah nama/hapus album. Bar pemutar di bawah dengan tombol ✕ untuk menutup |
| **Pengaturan** | Tema gelap/terang, 6 warna aksen, 24 jam/AM-PM, suara, notifikasi, jalan di latar belakang, mulai saat login; **sholat & adzan** (negara, kota/koordinat, mazhab Ashar, file adzan, pengingat sebelum waktu, koreksi Hijriyah, pemberitahuan Beranda) |

Jendela memakai tombol bulat **merah (tutup) · kuning (minimize) · hijau (perbesar)** ala macOS di kiri atas; bilah judul bisa diseret.

Pintasan: `Ctrl+1…9` pindah halaman, `Ctrl+Q` keluar, `Esc` menutup dialog.

## Catatan
* **Latar belakang**: aktifkan "Tetap berjalan di latar belakang" di Pengaturan agar alarm tetap bunyi saat jendela ditutup. Buka lagi dengan menjalankan mylandx; tombol **Keluar** di sidebar menutup total.
* **Adzan**: mylandx tidak membawa rekaman adzan. Di Pengaturan → *Waktu sholat & adzan* pilih file audio adzan milikmu (mp3/ogg/wav; boleh file khusus Subuh). Tanpa file, yang bunyi lonceng lembut. Musik yang sedang diputar otomatis dijeda saat waktu sholat dan dilanjut setelah jendela sholat ditutup.
* **Jadwal sholat** dihitung di komputer (offline) untuk lokasi mana pun: ±250 negara dan ±750 kota bawaan (Indonesia ±260 kabupaten/kota, termasuk Ponorogo) (koordinat + zona waktu, termasuk perubahan jam musim panas), atau isi koordinat manual untuk kota yang tidak ada di daftar. Metode mengikuti otoritas setempat bila dikenal (Kemenag RI, JAKIM, MUIS, Umm al-Qura, ISNA, Karachi, Mesir, dll.), selain itu Muslim World League; di lintang tinggi dipakai aturan berbasis sudut. Dibandingkan jadwal Jakarta Okt 2026 selisihnya ≤ 1 menit; di tempat lain bisa 1–3 menit dari jadwal resmi setempat. Jam yang tampil & bunyi adzan memakai **waktu setempat kota yang dipilih**.
* **Libur resmi 2026 & 2027** memakai SKB 3 Menteri (libur nasional + cuti bersama). Tahun lain: libur tanggal tetap, Paskah-turunan, dan libur Hijriyah dihitung (ditandai "perkiraan"); Nyepi/Waisak di luar 2026–2027 belum tercakup. Tidak ada sinkron online.
* **Tanggal Hijriyah** memakai hitungan tabular yang disesuaikan ke penetapan pemerintah pada 2026–2027. Awal bulan sebenarnya ditentukan rukyat/sidang isbat sehingga bisa beda ±1 hari; geser lewat *Koreksi tanggal Hijriyah*.
* **Latar belakang**: aktifkan "Tetap berjalan di latar belakang" di Pengaturan agar alarm & adzan tetap bunyi saat jendela ditutup. Buka lagi dengan menjalankan mylandx; tombol **Keluar** di sidebar menutup total.
* **Data**: `~/.local/share/mylandx/data.json` (cadangan otomatis kalau file rusak). Aman di-backup / disalin ke laptop lain.
* **Copot**: `./uninstall.sh` (tambah `--purge` untuk hapus data).
* Kalau tampilan terasa janggal atau ada error, jalankan dari terminal (`mylandx`) dan kirim pesan error-nya.
