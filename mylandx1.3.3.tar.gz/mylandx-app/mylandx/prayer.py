"""Hitung 5 waktu sholat untuk kota mana pun di dunia (offline).

Metode mengikuti otoritas setempat jika dikenal (Kemenag RI untuk Indonesia, JAKIM, Umm al-Qura,
ISNA, Karachi, Mesir, dst.), selain itu Muslim World League. Akurasi biasanya +-1-3 menit
dibanding jadwal resmi setempat. Di lintang tinggi (sudut Subuh/Isya tak tercapai) dipakai aturan 1/7 malam."""
import math
from datetime import date, datetime, timedelta, timezone

try:
    from zoneinfo import ZoneInfo
except ImportError:  # pragma: no cover
    ZoneInfo = None

from . import world

NAMA = ["Subuh", "Dzuhur", "Ashar", "Maghrib", "Isya"]
KEYS = ["subuh", "dzuhur", "ashar", "maghrib", "isya"]
HORIZON = 0.8333

# kode negara -> (nama metode, sudut Subuh, sudut Isya atau None, menit Isya setelah Maghrib, ihtiyat menit)
M_KEMENAG = ("Kemenag RI", 20.0, 18.0, 0, 2)
M_MWL = ("Muslim World League", 18.0, 17.0, 0, 0)
M_ISNA = ("ISNA (Amerika Utara)", 15.0, 15.0, 0, 0)
M_KARACHI = ("Karachi", 18.0, 18.0, 0, 0)
M_EGYPT = ("Otoritas Mesir", 19.5, 17.5, 0, 0)
M_UMM = ("Umm al-Qura (Makkah)", 18.5, None, 90, 0)
M_GULF = ("Teluk", 19.5, None, 90, 0)
M_JAKIM = ("JAKIM Malaysia", 18.0, 18.0, 0, 0)
M_MUIS = ("MUIS Singapura", 20.0, 18.0, 0, 0)
METODE = {"ID": M_KEMENAG, "MY": M_JAKIM, "BN": M_JAKIM, "SG": M_MUIS,
          "SA": M_UMM, "AE": M_GULF, "OM": M_GULF, "BH": M_GULF, "QA": ("Qatar", 18.0, None, 90, 0),
          "KW": ("Kuwait", 18.0, 17.5, 0, 0), "EG": M_EGYPT, "SY": M_EGYPT, "IQ": M_EGYPT, "LB": M_EGYPT,
          "JO": M_EGYPT, "PS": M_EGYPT, "SD": M_EGYPT, "LY": M_EGYPT, "PK": M_KARACHI, "BD": M_KARACHI,
          "IN": M_KARACHI, "AF": M_KARACHI, "LK": M_KARACHI, "NP": M_KARACHI,
          "US": M_ISNA, "CA": M_ISNA, "MX": M_ISNA, "DZ": ("Aljazair", 18.0, 17.0, 0, 0),
          "MA": ("Maroko", 19.0, 17.0, 0, 0), "TN": ("Tunisia", 18.0, 18.0, 0, 0),
          "IR": ("Teheran", 17.7, 14.0, 0, 0), "TR": ("Diyanet Turki", 18.0, 17.0, 0, 0)}


class Lokasi:
    def __init__(self, negara, nama, lat, lng, tz):
        self.negara, self.nama, self.lat, self.lng, self.tz = negara, nama, float(lat), float(lng), tz

    @property
    def metode(self):
        return METODE.get(self.negara, M_MWL)

    def zona(self):
        if ZoneInfo is not None:
            try:
                return ZoneInfo(self.tz)
            except Exception:
                pass
        return timezone(timedelta(hours=round(self.lng / 15.0)))

    def offset(self, d):
        """selisih UTC (jam) di tanggal d, memperhitungkan DST."""
        off = self.zona().utcoffset(datetime(d.year, d.month, d.day, 12))
        return off.total_seconds() / 3600.0

    def kunci(self):
        return (self.negara, self.nama, self.lat, self.lng, self.tz)


DEFAULT = ("ID", "Jakarta")


def cari(negara, nama):
    for n, la, ln, tz in world.KOTA.get(negara, []):
        if n == nama:
            return Lokasi(negara, n, la, ln, tz)
    return None


def lokasi_dari(st):
    """Lokasi dari pengaturan: koordinat manual (jika ada) atau negara+kota."""
    m = st.get("kota_manual")
    if isinstance(m, dict):
        try:
            return Lokasi(st.get("negara", "ID"), m.get("nama") or "Lokasi saya", float(m["lat"]), float(m["lng"]), m.get("tz") or "UTC")
        except (KeyError, TypeError, ValueError):
            pass
    return cari(st.get("negara", "ID"), st.get("kota", "Jakarta")) or cari(*DEFAULT)


def _lok(x):
    if isinstance(x, Lokasi):
        return x
    return cari("ID", x) or cari(*DEFAULT)      # nama kota Indonesia (kompatibel dengan versi lama)


def sekarang(lok, now=None):
    """Waktu setempat lokasi (naif). now = waktu sistem (naif) atau None untuk sekarang."""
    lok = _lok(lok)
    now = now or datetime.now()
    try:
        return now.astimezone(lok.zona()).replace(tzinfo=None)
    except Exception:
        return now


# ---------------------------------------------------------------- astronomi
def _sun(jd):
    d = jd - 2451545.0
    g = math.radians((357.529 + 0.98560028 * d) % 360)
    q = (280.459 + 0.98564736 * d) % 360
    L = math.radians((q + 1.915 * math.sin(g) + 0.020 * math.sin(2 * g)) % 360)
    e = math.radians(23.439 - 0.00000036 * d)
    ra = math.degrees(math.atan2(math.cos(e) * math.sin(L), math.cos(L))) / 15.0
    ra %= 24
    dec = math.degrees(math.asin(math.sin(e) * math.sin(L)))
    eqt = q / 15.0 - ra
    while eqt > 12:
        eqt -= 24
    while eqt < -12:
        eqt += 24
    return dec, eqt


def _jd(d):
    y, m = d.year, d.month
    if m <= 2:
        y -= 1
        m += 12
    a = y // 100
    b = 2 - a + a // 4
    return int(365.25 * (y + 4716)) + int(30.6001 * (m + 1)) + d.day + b - 1524.5


def _x(angle, dec, lat):
    """cos sudut jam saat matahari berada `angle` derajat DI BAWAH horizon."""
    return (-math.sin(math.radians(angle)) - math.sin(math.radians(dec)) * math.sin(math.radians(lat))) / (
        math.cos(math.radians(dec)) * math.cos(math.radians(lat)))


def _t(angle, dec, lat, dhuhr, sign):
    x = _x(angle, dec, lat)
    if x < -1 or x > 1:
        return None
    return dhuhr + sign * math.degrees(math.acos(x)) / 15.0


def hitung(d, lat, lng, tz, metode=M_MWL, hanafi=False):
    """-> dict key -> datetime naif setempat (+ 'terbit'). Waktu yang tak terdefinisi dilewati."""
    _, subuh_deg, isya_deg, isya_min, ihtiyat = metode
    jd = _jd(d) + 0.5 - tz / 24.0
    dec, eqt = _sun(jd)
    dhuhr = 12 + tz - lng / 15.0 - eqt
    terbit = _t(HORIZON, dec, lat, dhuhr, -1)
    maghrib = _t(HORIZON, dec, lat, dhuhr, +1)
    subuh = _t(subuh_deg, dec, lat, dhuhr, -1)
    if isya_deg is None:
        isya = maghrib + isya_min / 60.0 if maghrib is not None else None
    else:
        isya = _t(isya_deg, dec, lat, dhuhr, +1)
    if terbit is not None and maghrib is not None:   # lintang tinggi: batasi dengan aturan berbasis sudut (PrayTimes)
        malam = (terbit + 24) - maghrib
        porsi = subuh_deg / 60.0 * malam
        if subuh is None or (terbit - subuh) > porsi:
            subuh = terbit - porsi
        if isya_deg is not None:
            porsi = isya_deg / 60.0 * malam
            if isya is None or (isya - maghrib) > porsi:
                isya = maghrib + porsi
    faktor = 2 if hanafi else 1
    a = math.degrees(math.atan(1.0 / (faktor + math.tan(math.radians(abs(lat - dec))))))
    x = (math.sin(math.radians(a)) - math.sin(math.radians(dec)) * math.sin(math.radians(lat))) / (
        math.cos(math.radians(dec)) * math.cos(math.radians(lat)))
    ashar = dhuhr + math.degrees(math.acos(max(-1, min(1, x)))) / 15.0
    base = datetime(d.year, d.month, d.day)
    out = {}
    for key, h, off in (("subuh", subuh, ihtiyat), ("terbit", terbit, -ihtiyat), ("dzuhur", dhuhr, ihtiyat),
                        ("ashar", ashar, ihtiyat), ("maghrib", maghrib, ihtiyat), ("isya", isya, ihtiyat)):
        if h is None:
            continue
        v = base + timedelta(minutes=h * 60 + off)
        out[key] = v.replace(second=0, microsecond=0) + (timedelta(minutes=1) if v.second >= 30 else timedelta())
    return out


def jadwal(d, lok="Jakarta", hanafi=False):
    lok = _lok(lok)
    return hitung(d, lok.lat, lok.lng, lok.offset(d), lok.metode, hanafi)


def berikutnya(now, lok="Jakarta", hanafi=False):
    """now = waktu SETEMPAT lokasi. -> (key, datetime) sholat berikutnya."""
    lok = _lok(lok)
    for add in (0, 1, 2):
        s = jadwal(now.date() + timedelta(days=add), lok, hanafi)
        for k in KEYS:
            if k in s and s[k] > now:
                return k, s[k]
    return None, None
