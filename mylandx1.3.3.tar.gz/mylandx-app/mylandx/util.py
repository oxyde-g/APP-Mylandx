"""Helper murni (tanpa GUI): format tanggal Indonesia, hitung alarm berikutnya, dll."""
from datetime import datetime, date, timedelta, timezone

HARI = ["Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu", "Minggu"]
HARI_S = ["Sen", "Sel", "Rab", "Kam", "Jum", "Sab", "Min"]
BULAN = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli",
         "Agustus", "September", "Oktober", "November", "Desember"]
BULAN_S = [b[:3] for b in BULAN]

# Libur nasional yang tanggalnya tetap tiap tahun.
# (Libur yang berpindah-pindah seperti Idulfitri/Waisak tidak ikut, karena tergantung penetapan tahunan.)
LIBUR_TETAP = {
    (1, 1): "Tahun Baru Masehi",
    (5, 1): "Hari Buruh Internasional",
    (6, 1): "Hari Lahir Pancasila",
    (8, 17): "Hari Kemerdekaan RI",
    (12, 25): "Hari Raya Natal",
}


def libur(d):
    return LIBUR_TETAP.get((d.month, d.day))


def tanggal_panjang(d):
    return f"{HARI[d.weekday()]}, {d.day} {BULAN[d.month - 1]} {d.year}"


def tanggal_pendek(d):
    return f"{d.day} {BULAN_S[d.month - 1]}"


def salam(hour):
    if hour < 4:
        return "Masih melek nih"
    if hour < 11:
        return "Selamat pagi"
    if hour < 15:
        return "Selamat siang"
    if hour < 18:
        return "Selamat sore"
    return "Selamat malam"


def fmt_jam(dt, clock24=True):
    if clock24:
        return dt.strftime("%H:%M")
    h = dt.hour % 12 or 12
    return f"{h}:{dt.minute:02d} {'AM' if dt.hour < 12 else 'PM'}"


def fmt_hhmm(hhmm, clock24=True):
    h, m = (int(x) for x in hhmm.split(":"))
    return fmt_jam(datetime(2000, 1, 1, h, m), clock24)


def mmss(sec):
    sec = max(0, int(round(sec)))
    return f"{sec // 60:02d}:{sec % 60:02d}"


def durasi(sec):
    """Durasi kasar yang enak dibaca: '5 menit', '2 jam', '3 hari'."""
    sec = abs(int(sec))
    if sec < 60:
        return "kurang dari semenit"
    m = sec // 60
    if m < 60:
        return f"{m} menit"
    h, mm = divmod(m, 60)
    if h < 24:
        return f"{h} jam {mm} mnt" if (mm and h < 6) else f"{h} jam"
    return f"{h // 24} hari"


def parse_dt(s):
    if not s:
        return None
    try:
        return datetime.fromisoformat(s)
    except ValueError:
        return None


def due_label(dt, now, clock24=True):
    today = now.date()
    if dt.date() == today:
        day = "Hari ini"
    elif dt.date() == today + timedelta(days=1):
        day = "Besok"
    elif dt.date() == today - timedelta(days=1):
        day = "Kemarin"
    else:
        day = f"{HARI_S[dt.weekday()]}, {tanggal_pendek(dt.date())}"
        if dt.year != today.year:
            day += f" {dt.year}"
    return f"{day}, {fmt_jam(dt, clock24)}"


def due_relative(dt, now):
    """('Terlambat 2 jam' | '3 jam lagi', overdue: bool)"""
    delta = (dt - now).total_seconds()
    if delta < 0:
        return f"Terlambat {durasi(delta)}", True
    return f"{durasi(delta)} lagi", False


def days_text(days):
    s = set(days)
    if not s:
        return "Sekali"
    if len(s) == 7:
        return "Setiap hari"
    if s == {0, 1, 2, 3, 4}:
        return "Hari kerja"
    if s == {5, 6}:
        return "Akhir pekan"
    return " ".join(HARI_S[i] for i in sorted(s))


def next_alarm(alarms, now):
    """Kembalikan (datetime, alarm) alarm aktif berikutnya, atau None."""
    best = None
    for a in alarms:
        if not a.get("enabled"):
            continue
        h, m = (int(x) for x in a["time"].split(":"))
        for add in range(8):
            cand = datetime.combine(now.date() + timedelta(days=add), datetime.min.time()).replace(hour=h, minute=m)
            if cand <= now:
                continue
            if a.get("days") and cand.weekday() not in a["days"]:
                continue
            if best is None or cand < best[0]:
                best = (cand, a)
            break
    return best


ZONA = [("WIB", 7), ("WITA", 8), ("WIT", 9), ("UTC", 0)]


def waktu_zona(offset_hours):
    return datetime.now(timezone.utc) + timedelta(hours=offset_hours)


def month_grid(year, month):
    """42 tanggal (6 minggu, mulai Senin) yang menampilkan bulan itu."""
    first = date(year, month, 1)
    start = first - timedelta(days=first.weekday())
    return [start + timedelta(days=i) for i in range(42)]


def shift_month(year, month, delta):
    idx = year * 12 + (month - 1) + delta
    return idx // 12, idx % 12 + 1
