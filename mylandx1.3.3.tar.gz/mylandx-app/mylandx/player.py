"""Pemutar: `Player` (antrean, acak/ulang, status) + `MpvBackend` (mpv lewat IPC socket).
mpv dipilih karena decoder MP3/AAC/FLAC-nya lengkap dari repo resmi Fedora, ringan, dan stabil untuk stream HTTP."""
import ctypes
import json
import os
import random
import shutil
import socket
import subprocess
import tempfile
import threading
import time

from gi.repository import GLib

MPV_HINT = "Pemutar belum terpasang. Jalankan di terminal:  sudo dnf install mpv"


def _die_with_parent():
    try:
        ctypes.CDLL("libc.so.6").prctl(1, 15)  # PR_SET_PDEATHSIG=SIGTERM: mpv ikut mati kalau app crash
    except Exception:  # noqa: BLE001
        pass


class MpvBackend:
    """Backend: kendalikan satu proses mpv (`--idle`) lewat JSON IPC."""
    reports_loaded = True

    def __init__(self, volume=0.8, exe=None):
        self.exe = exe or shutil.which("mpv")
        self.available = bool(self.exe)
        self.volume = volume
        self.on_loaded = lambda: None
        self.on_end = lambda: None
        self.on_error = lambda msg: None
        self._proc = None
        self._sock = None
        self._path = ""
        self._pending = []
        self._lock = threading.Lock()
        self._pos = 0.0
        self._dur = 0.0
        self._quitting = False

    # ---- proses & koneksi
    def _ensure(self):
        if self._proc and self._proc.poll() is None:
            return True
        if not self.available:
            return False
        base = os.environ.get("XDG_RUNTIME_DIR") or tempfile.gettempdir()
        self._path = os.path.join(base, f"mylandx-mpv-{os.getpid()}.sock")
        try:
            os.unlink(self._path)
        except OSError:
            pass
        args = [self.exe, "--idle=yes", "--no-video", "--no-terminal", "--really-quiet", "--no-config",
                "--force-window=no", "--audio-display=no", "--ytdl=no", f"--volume={round(self.volume * 100)}",
                f"--input-ipc-server={self._path}"]
        try:
            self._proc = subprocess.Popen(args, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                                          stderr=subprocess.DEVNULL, preexec_fn=_die_with_parent)
        except OSError as e:
            self.available = False
            self.on_error(f"mpv tidak bisa dijalankan: {e}")
            return False
        self._sock, self._pending = None, []
        threading.Thread(target=self._reader, args=(self._proc, self._path), daemon=True).start()
        return True

    def _reader(self, proc, path):
        s = None
        for _ in range(120):  # tunggu socket siap (maks. ~6 dtk)
            if proc.poll() is not None:
                break
            c = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            try:
                c.connect(path)
                s = c
                break
            except OSError:
                c.close()
                time.sleep(0.05)
        if s is None:
            GLib.idle_add(self._closed, proc)
            return
        with self._lock:
            self._sock = s
            first = b"".join((json.dumps({"command": ["observe_property", i, n]}) + "\n").encode()
                             for i, n in enumerate(("time-pos", "duration"), 1))
            try:
                s.sendall(first + b"".join(self._pending))
            except OSError:
                pass
            self._pending = []
        buf = b""
        while True:
            try:
                chunk = s.recv(65536)
            except OSError:
                break
            if not chunk:
                break
            buf += chunk
            while b"\n" in buf:
                line, buf = buf.split(b"\n", 1)
                try:
                    GLib.idle_add(self._event, json.loads(line))
                except ValueError:
                    pass
        GLib.idle_add(self._closed, proc)

    def _send(self, cmd):
        data = (json.dumps({"command": cmd}) + "\n").encode()
        with self._lock:
            if self._sock:
                try:
                    self._sock.sendall(data)
                except OSError:
                    pass
            else:
                self._pending.append(data)

    # ---- event (thread utama)
    def _event(self, msg):
        ev = msg.get("event")
        if ev == "property-change":
            val = msg.get("data")
            if isinstance(val, (int, float)):
                if msg.get("name") == "time-pos":
                    self._pos = float(val)
                elif msg.get("name") == "duration":
                    self._dur = float(val)
        elif ev == "start-file":
            self._pos = self._dur = 0.0
        elif ev == "file-loaded":
            self.on_loaded()
        elif ev == "end-file":
            reason = msg.get("reason")
            if reason == "eof":
                self.on_end()
            elif reason == "error":
                self.on_error("Lagu ini gagal dimuat (sumber tidak merespons atau formatnya tidak didukung).")
        return False

    def _closed(self, proc):
        if proc is self._proc:
            self._proc = self._sock = None
            if not self._quitting:
                self.on_error("Pemutar (mpv) berhenti tiba-tiba. Coba putar lagi.")
        return False

    # ---- antarmuka backend
    def load(self, url):
        if not self._ensure():
            if not self.available:
                self.on_error(MPV_HINT)
            return
        self._pos = self._dur = 0.0
        self._send(["set_property", "pause", False])
        self._send(["loadfile", url, "replace"])

    def play(self):
        self._send(["set_property", "pause", False])

    def pause(self):
        self._send(["set_property", "pause", True])

    def stop(self):
        self._send(["stop"])

    def seek(self, seconds):
        self._pos = max(0.0, seconds)
        self._send(["seek", max(0.0, seconds), "absolute"])

    def position(self):
        return self._pos

    def duration(self):
        return self._dur

    def set_volume(self, v):
        self.volume = max(0.0, min(1.0, v))
        if self._proc:
            self._send(["set_property", "volume", round(self.volume * 100)])

    def quit(self):
        self._quitting = True
        try:
            self._send(["quit"])
            if self._proc and self._proc.poll() is None:
                try:
                    self._proc.wait(timeout=1)
                except subprocess.TimeoutExpired:
                    self._proc.terminate()
        except Exception:  # noqa: BLE001
            pass
        try:
            os.unlink(self._path)
        except OSError:
            pass


class Player:
    """Antrean + status pemutaran. UI membaca: current, state, pos, dur, error, shuffle, repeat; dan mendaftar ke `listeners`."""

    def __init__(self, backend=None, volume=0.8):
        self.backend = backend if backend is not None else MpvBackend(volume)
        self.queue, self.index = [], -1
        self.current = None
        self.state = "stopped"          # stopped | loading | playing | paused
        self.pos = self.dur = 0.0
        self.error = ""
        self.shuffle = self.repeat = False
        self.listeners = []
        self._token = 0
        self._tick_src = 0
        self._held = False
        self.backend.on_loaded = self._loaded
        self.backend.on_end = self._ended
        self.backend.on_error = self._failed
        self.backend.set_volume(volume)

    # ---- notifikasi
    def _notify(self):
        for fn in list(self.listeners):
            fn()

    def _set_state(self, st):
        self.state = st
        if st in ("loading", "playing") and not self._tick_src:
            self._tick_src = GLib.timeout_add(500, self._tick)
        self._notify()

    def _tick(self):
        if self.state not in ("loading", "playing"):
            self._tick_src = 0
            return False
        self.pos, self.dur = self.backend.position(), self.backend.duration()
        self._notify()
        return True

    # ---- antrean
    def play_queue(self, tracks, index):
        self.queue = list(tracks)
        self._start(index)

    def _start(self, index):
        if not (0 <= index < len(self.queue)):
            return
        self.index = index
        self.current = self.queue[index]
        self.error = ""
        self.pos = self.dur = 0.0
        self._token += 1
        token, track = self._token, self.current
        self._set_state("loading")
        if not self.backend.available:
            self._failed(MPV_HINT)
            return
        self._load(token, track["url"])

    def _load(self, token, url):
        if token == self._token:
            self.backend.load(url)
            if not getattr(self.backend, "reports_loaded", False):
                self._set_state("playing")
        return False

    def next(self):
        n = len(self.queue)
        if not n:
            return
        if self.shuffle and n > 1:
            self._start(random.choice([i for i in range(n) if i != self.index]))
        elif self.index + 1 < n:
            self._start(self.index + 1)
        elif self.repeat:
            self._start(0)
        else:
            self.stop()

    def prev(self):
        if self.pos > 3 or self.index <= 0:
            self.seek_frac(0)
        else:
            self._start(self.index - 1)

    def toggle(self):
        if self.state == "playing":
            self.backend.pause()
            self._set_state("paused")
        elif self.state == "paused":
            self.backend.play()
            self._set_state("playing")
        elif self.current:
            self._start(self.index)

    def stop(self):
        self._token += 1
        self.backend.stop()
        self._set_state("stopped")

    def close(self):
        """Hentikan lagu, kosongkan antrean, dan sembunyikan bar pemutar."""
        self._token += 1
        self.backend.stop()
        self.queue, self.index, self.current = [], -1, None
        self.error = ""
        self.pos = self.dur = 0.0
        self._held = False
        self._set_state("stopped")

    def seek_frac(self, f):
        dur = self.dur or self.backend.duration()
        if dur > 0:
            self.backend.seek(dur * max(0.0, min(1.0, f)))
        elif f == 0:
            self.backend.seek(0.0)

    def set_volume(self, v):
        self.backend.set_volume(v)

    # ---- alarm berbunyi: jeda musik lalu lanjutkan
    def hold(self):
        self._held = self.state == "playing"
        if self._held:
            self.toggle()

    def release(self):
        if self._held:
            self._held = False
            if self.state == "paused":
                self.toggle()

    # ---- callback backend
    def _loaded(self):
        if self.state == "loading":
            self._set_state("playing")

    def _ended(self):
        self.next()

    def _failed(self, msg):
        self.error = msg
        self._set_state("stopped")

    def shutdown(self):
        q = getattr(self.backend, "quit", None)
        if q:
            q()
