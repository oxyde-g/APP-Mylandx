from datetime import datetime

import gi
gi.require_version("Gtk", "4.0")
from gi.repository import Gtk, GLib

from ..util import tanggal_pendek, parse_dt
from .common import vbox, hbox, label, button, clear
from .dialogs import confirm
from .page import Page

SAVE_DELAY_MS = 600


class NotesPage(Page):
    def __init__(self, ctx):
        super().__init__(ctx, "Catatan", "Ketik apa saja — tersimpan otomatis, ada cadangan, tidak akan hilang.")
        self.current = None
        self._dirty = False
        self._loading = False
        self._src = 0
        self.body.append(self.head)

        cols = hbox(16)
        # ---------- kiri: daftar
        left = vbox(10, ["card"])
        left.set_size_request(300, -1)
        top = hbox(8)
        self.search = Gtk.Entry(placeholder_text="Cari catatan…")
        self.search.set_hexpand(True)
        self.search.connect("changed", lambda *_: self._rebuild())
        top.append(self.search)
        top.append(button("+ Baru", ["primary"], self.new_note))
        left.append(top)
        self.list = vbox(4)
        left.append(self.list)
        cols.append(left)

        # ---------- kanan: editor
        right = vbox(10, ["card"])
        right.set_hexpand(True)
        self.title_e = Gtk.Entry(placeholder_text="Judul catatan")
        self.title_e.add_css_class("note-title")
        self.title_e.connect("changed", lambda *_: self._edited())
        right.append(self.title_e)
        self.view = Gtk.TextView()
        self.view.set_wrap_mode(Gtk.WrapMode.WORD_CHAR)
        self.view.set_left_margin(14)
        self.view.set_right_margin(14)
        self.view.set_top_margin(12)
        self.view.set_bottom_margin(12)
        self.view.set_accepts_tab(True)
        self.buf = self.view.get_buffer()
        self.buf.connect("changed", lambda *_: self._edited())
        sw = Gtk.ScrolledWindow()
        sw.add_css_class("editor")
        sw.set_min_content_height(400)
        sw.set_vexpand(True)
        sw.set_child(self.view)
        right.append(sw)
        foot = hbox(10)
        self.status = label("", ["tiny"])
        self.status.set_hexpand(True)
        foot.append(self.status)
        self.pin_btn = button("Sematkan", ["ghost"], self._toggle_pin)
        foot.append(self.pin_btn)
        foot.append(button("Hapus", ["ghost", "danger"], self._delete))
        right.append(foot)
        cols.append(right)
        self.body.append(cols)

        self.connect("unmap", lambda *_: self.flush())
        self._rebuild()
        notes = self._sorted()
        if notes:
            self.select(notes[0]["id"])
        else:
            self._sync_editor()

    # ---------- data
    def _sorted(self):
        q = self.search.get_text().strip().lower()
        ns = [n for n in self.ctx.store.notes
              if not q or q in n["title"].lower() or q in n["body"].lower()]
        return sorted(ns, key=lambda n: (bool(n.get("pinned")), n.get("updated", "")), reverse=True)

    def _preview(self, n):
        title = n["title"].strip() or (n["body"].strip().splitlines() or [""])[0][:40] or "Catatan tanpa judul"
        rest = n["body"].strip().replace("\n", " ")
        return title, (rest[:70] if rest and rest != title else "")

    def _rebuild(self):
        clear(self.list)
        notes = self._sorted()
        if not notes:
            e = label("Belum ada catatan." if not self.ctx.store.notes else "Tidak ada yang cocok.", ["sub"], xalign=0.5)
            e.set_margin_top(20)
            self.list.append(e)
        for n in notes:
            self.list.append(self._item(n))

    def _item(self, n):
        title, prev = self._preview(n)
        b = Gtk.Button()
        b.add_css_class("note-item")
        if n["id"] == self.current:
            b.add_css_class("note-sel")
        box = vbox(2)
        box.set_hexpand(True)
        head = ("• " if n.get("pinned") else "") + title
        box.append(label(head, ["row-title"], ellipsize=True))
        if prev:
            box.append(label(prev, ["tiny"], ellipsize=True))
        upd = parse_dt(n.get("updated"))
        if upd:
            box.append(label(tanggal_pendek(upd.date()) + upd.strftime(", %H:%M"), ["tiny"]))
        b.set_child(box)
        b.connect("clicked", lambda *_: self.select(n["id"]))
        b.set_hexpand(True)
        row = hbox(2)
        row.append(b)
        d = button("Hapus", ["ghost", "danger"], lambda: self._confirm_delete(n), "Hapus catatan ini")
        d.set_valign(Gtk.Align.CENTER)
        row.append(d)
        return row

    # ---------- editor
    def _sync_editor(self):
        n = self.ctx.store.get_note(self.current) if self.current else None
        for w in (self.title_e, self.view, self.pin_btn):
            w.set_sensitive(n is not None)
        if n is None:
            self._loading = True
            self.title_e.set_text("")
            self.buf.set_text("", -1)
            self._loading = False
            self.status.set_text("Klik “+ Baru” untuk membuat catatan pertamamu.")
            self.pin_btn.set_label("Sematkan")
        else:
            self.pin_btn.set_label("Lepas sematan" if n.get("pinned") else "Sematkan")

    def select(self, nid):
        self.flush()
        self.current = nid
        n = self.ctx.store.get_note(nid)
        self._loading = True
        self.title_e.set_text(n["title"] if n else "")
        self.buf.set_text(n["body"] if n else "", -1)
        self._loading = False
        self._dirty = False
        self._sync_editor()
        if n:
            self._status_saved(n)
        self._rebuild()

    def new_note(self):
        self.flush()
        self.search.set_text("")
        n = self.ctx.store.add_note()
        self.select(n["id"])
        self.title_e.grab_focus()

    def _text(self):
        return self.buf.get_text(self.buf.get_start_iter(), self.buf.get_end_iter(), False)

    def _edited(self):
        if self._loading or not self.current:
            return
        self._dirty = True
        self.status.set_text("Menyimpan…")
        if self._src:
            GLib.source_remove(self._src)
        self._src = GLib.timeout_add(SAVE_DELAY_MS, self._timer)
        words = len(self._text().split())
        self.sub.set_text(f"{words} kata di catatan ini")

    def _timer(self):
        self._src = 0
        self.flush()
        return False

    def flush(self):
        """Simpan sekarang juga (dipanggil saat pindah catatan/halaman dan saat app ditutup)."""
        if self._src:
            GLib.source_remove(self._src)
            self._src = 0
        if not (self._dirty and self.current):
            return
        self._dirty = False
        store = self.ctx.store
        store.update_note(self.current, quiet=True, title=self.title_e.get_text(), body=self._text())
        n = store.get_note(self.current)
        if n:
            self._status_saved(n)
        self._rebuild()

    def _status_saved(self, n):
        upd = parse_dt(n.get("updated")) or datetime.now()
        self.status.set_text(f"Tersimpan {upd.strftime('%H:%M')} · {len(n['body'].split())} kata")

    def _toggle_pin(self):
        n = self.ctx.store.get_note(self.current)
        if n:
            self.flush()
            self.ctx.store.update_note(n["id"], pinned=not n.get("pinned"))

    def _delete(self):
        n = self.ctx.store.get_note(self.current)
        if n:
            self._confirm_delete(n)

    def _confirm_delete(self, n):
        name = self._preview(n)[0]
        confirm(self.ctx.window, f"Hapus catatan “{name}”?", lambda: self._do_delete(n["id"]))

    def _do_delete(self, nid):
        """Hapus satu catatan (bisa yang sedang dibuka, bisa juga yang lain di daftar)."""
        was_current = nid == self.current
        if was_current:
            self._dirty = False
            if self._src:
                GLib.source_remove(self._src)
                self._src = 0
        else:
            self.flush()
        self.ctx.store.delete_note(nid)
        if was_current:
            notes = self._sorted()
            self.current = None
            if notes:
                self.select(notes[0]["id"])
                return
            self._sync_editor()
        self._rebuild()

    def refresh(self):
        if self.current and not self.ctx.store.get_note(self.current):
            self.current = None
            self._sync_editor()
        elif self.current:
            self._sync_editor()
        self._rebuild()
