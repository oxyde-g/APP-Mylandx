import gi
gi.require_version("Gtk", "4.0")
from gi.repository import Gtk, GLib

from .. import draw
from ..util import mmss
from .common import vbox, hbox, label, Canvas, icon_button


class PlayerBar(Gtk.Box):
    """Bar pemutar di bawah jendela; tersembunyi sampai ada lagu diputar."""

    def __init__(self, ctx):
        super().__init__(orientation=Gtk.Orientation.HORIZONTAL, spacing=16)
        self.ctx = ctx
        self.p = ctx.player
        self.add_css_class("playerbar")
        self._vol_src = 0

        self.cover = Canvas(self._draw_cover, 48, 48)
        self.cover.set_valign(Gtk.Align.CENTER)
        self.append(self.cover)

        info = vbox(2)
        info.set_size_request(210, -1)
        info.set_valign(Gtk.Align.CENTER)
        self.title = label("", ["row-title"], ellipsize=True)
        self.artist = label("", ["tiny"], ellipsize=True)
        info.append(self.title)
        info.append(self.artist)
        self.append(info)

        ctl = hbox(4)
        ctl.set_valign(Gtk.Align.CENTER)
        self.shuffle = icon_button("shuffle", 18, self._shuffle, toggle=True, tooltip="Acak")
        self.prev = icon_button("prev", 18, self.p.prev, tooltip="Sebelumnya")
        self.play = icon_button("play", 20, self.p.toggle, css=("play-btn",), white=True,
                                state_fn=lambda: "pause" if self.p.state == "playing" else "play", tooltip="Putar / jeda")
        self.next = icon_button("next", 18, self.p.next, tooltip="Berikutnya")
        self.repeat = icon_button("repeat", 18, self._repeat, toggle=True, tooltip="Ulangi daftar")
        for w in (self.shuffle, self.prev, self.play, self.next, self.repeat):
            ctl.append(w)
        self.append(ctl)

        seek = hbox(10)
        seek.set_hexpand(True)
        seek.set_valign(Gtk.Align.CENTER)
        self.t_pos = label("0:00", ["tiny"])
        self.scale = Gtk.Scale.new_with_range(Gtk.Orientation.HORIZONTAL, 0, 1000, 1)
        self.scale.set_draw_value(False)
        self.scale.set_hexpand(True)
        self.scale.connect("change-value", self._seek)
        self.t_dur = label("0:00", ["tiny"])
        seek.append(self.t_pos)
        seek.append(self.scale)
        seek.append(self.t_dur)
        self.append(seek)

        self.fav = icon_button("heart", 20, self._fav, tooltip="Suka",
                               state_fn=lambda: "heart_fill" if self._is_fav() else "heart")
        self.fav.set_valign(Gtk.Align.CENTER)
        self.append(self.fav)

        self.vol = Gtk.Scale.new_with_range(Gtk.Orientation.HORIZONTAL, 0, 100, 1)
        self.vol.set_draw_value(False)
        self.vol.set_size_request(100, -1)
        self.vol.set_valign(Gtk.Align.CENTER)
        self.vol.set_value(ctx.store.settings.get("volume", 80))
        self.vol.connect("value-changed", self._volume)
        self.append(self.vol)

        self.close_btn = icon_button("close", 16, self.p.close, tooltip="Hentikan lagu & tutup pemutar")
        self.close_btn.set_valign(Gtk.Align.CENTER)
        self.append(self.close_btn)

        self.p.listeners.append(self.sync)
        self.set_visible(False)

    # ---------- aksi
    def _shuffle(self):
        self.p.shuffle = self.shuffle.get_active()

    def _repeat(self):
        self.p.repeat = self.repeat.get_active()

    def _is_fav(self):
        c = self.p.current
        return bool(c and self.ctx.store.is_fav(c["id"]))

    def _fav(self):
        if self.p.current:
            self.ctx.store.toggle_fav(self.p.current)

    def _seek(self, scale, scroll, value):
        self.p.seek_frac(value / 1000.0)
        return False

    def _volume(self, scale):
        v = scale.get_value()
        self.p.set_volume(v / 100.0)
        self.ctx.store.settings["volume"] = int(v)
        if self._vol_src:
            GLib.source_remove(self._vol_src)
        self._vol_src = GLib.timeout_add(700, self._save_vol)

    def _save_vol(self):
        self._vol_src = 0
        self.ctx.store.save()
        return False

    # ---------- tampilan
    def _draw_cover(self, cr, w, h):
        c = self.p.current
        if c:
            draw.draw_cover(cr, w, h, c["id"], c["title"])

    def sync(self):
        p, c = self.p, self.p.current
        self.set_visible(bool(c) or bool(p.error))
        if c:
            self.title.set_text(c["title"])
            self.artist.set_text(p.error or (c["artist"] + (" · preview 30 detik" if c.get("preview") else "")))
            if p.error:
                self.artist.add_css_class("danger-text")
            else:
                self.artist.remove_css_class("danger-text")
            self.t_pos.set_text(mmss(p.pos))
            self.t_dur.set_text(mmss(p.dur))
            if p.dur > 0:
                self.scale.set_value(min(1000, p.pos / p.dur * 1000))
        elif p.error:
            self.title.set_text("Tidak bisa memutar")
            self.artist.set_text(p.error)
        for w in (self.cover, self.play.canvas, self.fav.canvas, self.close_btn.canvas):
            w.queue_draw()
