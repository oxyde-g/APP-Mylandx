"""Baris tugas yang dipakai di halaman Tugas, Beranda, dan Kalender."""
from datetime import datetime

import gi
gi.require_version("Gtk", "4.0")
from gi.repository import Gtk

from .common import hbox, vbox, label, button, esc
from .dialogs import TaskDialog, confirm
from ..util import parse_dt, due_label, due_relative


def make_task_row(ctx, t, compact=False):
    store = ctx.store
    now = datetime.now()
    row = hbox(12, ["row"])
    if t.get("done"):
        row.add_css_class("row-done")

    bar = Gtk.Box()
    bar.add_css_class("prio")
    bar.add_css_class(f"prio-{t.get('priority', 1)}")
    bar.set_valign(Gtk.Align.FILL)
    row.append(bar)

    check = Gtk.CheckButton()
    check.set_active(bool(t.get("done")))
    check.set_valign(Gtk.Align.CENTER)
    check.connect("toggled", lambda b, tid=t["id"]: store.toggle_task(tid))
    row.append(check)

    text = vbox(2)
    text.set_hexpand(True)
    text.set_valign(Gtk.Align.CENTER)
    title = label("", ["row-title"], ellipsize=True)
    title.set_markup(f"<s>{esc(t['title'])}</s>" if t.get("done") else esc(t["title"]))
    text.append(title)

    meta = []
    overdue = False
    due = parse_dt(t.get("due"))
    if due:
        meta.append(due_label(due, now, store.settings["clock24"]))
        if not t.get("done"):
            rel, overdue = due_relative(due, now)
            meta.append(rel)
    if t.get("remind", -1) >= 0 and not t.get("done"):
        meta.append("pengingat aktif")
    if t.get("spent"):
        meta.append(f"fokus {t['spent']} mnt")
    if meta:
        m = label(" · ".join(meta), ["tiny"], ellipsize=True)
        if overdue:
            m.add_css_class("danger-text")
        text.append(m)
    if t.get("note") and not compact:
        text.append(label(t["note"], ["tiny"], ellipsize=True))
    row.append(text)

    if not compact:
        win = ctx.window
        row.append(button("Ubah", ["ghost"], lambda: TaskDialog(win, store, task=t).present()))
        row.append(button("Hapus", ["ghost", "danger"],
                          lambda: confirm(win, f"Hapus “{t['title']}”?", lambda: store.delete_task(t["id"]))))
    return row
