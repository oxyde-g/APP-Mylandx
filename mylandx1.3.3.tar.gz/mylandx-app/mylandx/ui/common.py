"""Widget bantu GTK4 yang dipakai di banyak halaman."""
import traceback
from datetime import date

import gi
gi.require_version("Gtk", "4.0")
from gi.repository import Gtk, GLib, Gio, Pango

from ..util import tanggal_pendek


def esc(s):
    return GLib.markup_escape_text(s or "", -1)


def clear(box):
    child = box.get_first_child()
    while child is not None:
        nxt = child.get_next_sibling()
        box.remove(child)
        child = nxt


def vbox(spacing=0, css=()):
    b = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=spacing)
    for c in css:
        b.add_css_class(c)
    return b


def hbox(spacing=0, css=()):
    b = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=spacing)
    for c in css:
        b.add_css_class(c)
    return b


def label(text="", css=(), xalign=0.0, wrap=False, ellipsize=False, selectable=False):
    l = Gtk.Label(label=text, xalign=xalign)
    for c in css:
        l.add_css_class(c)
    if wrap:
        l.set_wrap(True)
    if ellipsize:
        l.set_ellipsize(Pango.EllipsizeMode.END)
    if selectable:
        l.set_selectable(True)
    return l


def button(text, css=(), on_click=None, tooltip=None):
    b = Gtk.Button(label=text)
    for c in css:
        b.add_css_class(c)
    if on_click:
        b.connect("clicked", lambda *_: on_click())
    if tooltip:
        b.set_tooltip_text(tooltip)
    return b


def pad(widget, top=0, right=None, bottom=None, left=None):
    right = top if right is None else right
    bottom = top if bottom is None else bottom
    left = right if left is None else left
    widget.set_margin_top(top)
    widget.set_margin_end(right)
    widget.set_margin_bottom(bottom)
    widget.set_margin_start(left)
    return widget


def card(child=None, spacing=10):
    box = vbox(spacing, ["card"])
    if child is not None:
        box.append(child)
    return box


class Canvas(Gtk.DrawingArea):
    """DrawingArea yang memanggil fn(cr, w, h); error digambar tidak membuat app crash."""

    def __init__(self, fn, width=100, height=100, expand=False):
        super().__init__()
        self.fn = fn
        self.set_content_width(width)
        self.set_content_height(height)
        if expand:
            self.set_hexpand(True)
            self.set_vexpand(True)
        self.set_draw_func(self._draw)

    def _draw(self, area, cr, w, h):
        try:
            self.fn(cr, w, h)
        except Exception:
            traceback.print_exc()


class Chips(Gtk.Box):
    """Pilihan tunggal berbentuk chip."""

    def __init__(self, options, selected=0, on_change=None):
        super().__init__(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        self.on_change = on_change
        self.index = selected
        self._lock = True
        self.btns = []
        first = None
        for i, o in enumerate(options):
            b = Gtk.ToggleButton(label=o)
            b.add_css_class("chip")
            if first is None:
                first = b
            else:
                b.set_group(first)
            b.connect("toggled", self._toggled, i)
            self.append(b)
            self.btns.append(b)
        self.btns[selected].set_active(True)
        self._lock = False

    def _toggled(self, b, i):
        if b.get_active() and not self._lock:
            self.index = i
            if self.on_change:
                self.on_change(i)

    def set_index(self, i):
        self._lock = True
        self.btns[i].set_active(True)
        self.index = i
        self._lock = False


class TimePicker(Gtk.Box):
    def __init__(self, hhmm="07:00", big=False):
        super().__init__(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        h, m = (int(x) for x in hhmm.split(":"))
        self.h = Gtk.SpinButton.new_with_range(0, 23, 1)
        self.m = Gtk.SpinButton.new_with_range(0, 59, 1)
        for sp, v in ((self.h, h), (self.m, m)):
            sp.set_wrap(True)
            sp.set_numeric(True)
            sp.set_width_chars(2)
            sp.set_value(v)
            sp.connect("output", self._fmt)
            if big:
                sp.add_css_class("bigspin")
                sp.set_orientation(Gtk.Orientation.VERTICAL)
        self.append(self.h)
        colon = label(":", ["h1"])
        self.append(colon)
        self.append(self.m)

    @staticmethod
    def _fmt(spin):
        spin.set_text(f"{int(spin.get_value()):02d}")
        return True

    def get(self):
        return f"{self.h.get_value_as_int():02d}:{self.m.get_value_as_int():02d}"


class DatePicker(Gtk.MenuButton):
    def __init__(self, d=None):
        super().__init__()
        self.cal = Gtk.Calendar()
        pop = Gtk.Popover()
        pop.set_child(self.cal)
        self.set_popover(pop)
        self._date = d or date.today()
        self.cal.select_day(GLib.DateTime.new_local(self._date.year, self._date.month, self._date.day, 0, 0, 0))
        self.cal.connect("day-selected", self._sel)
        self._show()

    def _show(self):
        self.set_label(f"{tanggal_pendek(self._date)} {self._date.year}")

    def _sel(self, cal):
        dt = cal.get_date()
        self._date = date(dt.get_year(), dt.get_month(), dt.get_day_of_month())
        self._show()

    def get(self):
        return self._date


def switch_row(title, sub, active, on_toggle):
    """Baris pengaturan: judul + keterangan di kiri, Switch di kanan."""
    row = hbox(14)
    text = vbox(2)
    text.set_hexpand(True)
    text.append(label(title, ["h3"]))
    if sub:
        text.append(label(sub, ["tiny"], wrap=True))
    row.append(text)
    sw = Gtk.Switch()
    sw.set_valign(Gtk.Align.CENTER)
    sw.set_active(bool(active))
    sw.connect("notify::active", lambda s, _p: on_toggle(s.get_active()))
    row.append(sw)
    return row, sw


def open_uri(uri):
    try:
        Gio.AppInfo.launch_default_for_uri(uri, None)
    except Exception as e:  # noqa: BLE001
        print("mylandx: gagal membuka", uri, e)


def icon_button(name, size=20, on_click=None, toggle=False, css=("icon-btn",), tooltip=None, state_fn=None, white=False):
    """Tombol berisi ikon Cairo. state_fn() -> nama ikon (untuk ikon yang berubah, mis. play/pause)."""
    from .. import draw
    from ..theme import THEME
    b = Gtk.ToggleButton() if toggle else Gtk.Button()
    for c in css:
        b.add_css_class(c)

    def paint(cr, w, h):
        nm = state_fn() if state_fn else name
        if white:
            rgba = (1, 1, 1, 1)
        elif toggle:
            rgba = THEME.rgba("accent" if b.get_active() else "muted")
        else:
            rgba = THEME.rgba("text")
        draw.draw_icon(cr, nm, 0, 0, size, rgba)
    cv = Canvas(paint, size, size)
    b.set_child(cv)
    b.canvas = cv
    if on_click:
        b.connect("toggled" if toggle else "clicked", lambda *_: on_click())
    if tooltip:
        b.set_tooltip_text(tooltip)
    return b
