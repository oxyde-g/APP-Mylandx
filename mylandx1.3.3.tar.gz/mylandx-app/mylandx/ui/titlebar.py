import gi
gi.require_version("Gtk", "4.0")
from gi.repository import Gtk

from .. import draw
from .common import hbox, label, Canvas


class TitleBar(Gtk.WindowHandle):
    """Bilah judul sendiri: tiga bulatan merah/kuning/hijau ala macOS + judul. Bisa diseret untuk memindah jendela."""

    def __init__(self, win, title="mylandx"):
        super().__init__()
        self.win = win
        self.hover = False
        self.add_css_class("titlebar")
        row = hbox(0)
        self.set_child(row)
        self.lights = Canvas(self._draw, 62, 28)
        self.lights.set_margin_start(14)
        self.lights.set_valign(Gtk.Align.CENTER)
        row.append(self.lights)
        t = label(title, ["titlebar-title"], xalign=0.5)
        t.set_hexpand(True)
        row.append(t)
        sp = Gtk.Box()
        sp.set_size_request(76, 1)   # penyeimbang supaya judul tepat di tengah
        row.append(sp)
        click = Gtk.GestureClick()
        click.connect("released", self._released)
        self.lights.add_controller(click)
        motion = Gtk.EventControllerMotion()
        motion.connect("enter", lambda *_: self._set_hover(True))
        motion.connect("leave", lambda *_: self._set_hover(False))
        self.lights.add_controller(motion)
        win.connect("notify::is-active", lambda *_: self.lights.queue_draw())
        win.connect("notify::maximized", lambda *_: self.lights.queue_draw())
        self.lights.set_cursor_from_name("pointer")

    def _set_hover(self, v):
        self.hover = v
        self.lights.queue_draw()

    def _draw(self, cr, w, h):
        draw.draw_traffic(cr, w, h, self.hover, self.win.is_active(), self.win.is_maximized())

    def _released(self, gesture, n, x, y):
        which = draw.traffic_hit(x)
        if which == 0:
            self.win.close()
        elif which == 1:
            self.win.minimize()
        elif which == 2:
            if self.win.is_maximized():
                self.win.unmaximize()
            else:
                self.win.maximize()
