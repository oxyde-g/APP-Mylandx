from datetime import date, timedelta

import gi
gi.require_version("Gtk", "4.0")
from gi.repository import Gtk

from .. import draw, hijri, calendars
from ..util import BULAN, tanggal_panjang, shift_month, parse_dt
from .common import vbox, hbox, label, button, Canvas, clear
from .dialogs import TaskDialog
from .page import Page
from .taskrow import make_task_row


class CalendarPage(Page):
    def __init__(self, ctx):
        super().__init__(ctx, "Kalender", "Klik tanggal untuk melihat tugas; klik dua kali untuk menambah.")
        today = date.today()
        self.year, self.month = today.year, today.month
        self.selected = today
        self.hover = None
        self.marks = {}
        self.body.append(self.head)

        cols = hbox(18)
        left = vbox(12, ["card"])
        left.set_hexpand(True)
        nav = hbox(8)
        nav.append(button("‹", ["round-nav"], lambda: self.shift(-1), "Bulan sebelumnya"))
        mid = vbox(0)
        mid.set_hexpand(True)
        self.month_l = label("", ["h2"], xalign=0.5)
        self.hmonth_l = label("", ["tiny"], xalign=0.5)
        mid.append(self.month_l)
        mid.append(self.hmonth_l)
        nav.append(mid)
        nav.append(button("›", ["round-nav"], lambda: self.shift(1), "Bulan berikutnya"))
        nav.append(button("Hari ini", [], self.go_today))
        left.append(nav)

        self.grid = Canvas(self._draw, 560, 440, expand=True)
        self.grid.set_size_request(480, 400)
        click = Gtk.GestureClick()
        click.connect("pressed", self._pressed)
        self.grid.add_controller(click)
        motion = Gtk.EventControllerMotion()
        motion.connect("motion", self._motion)
        motion.connect("leave", self._leave)
        self.grid.add_controller(motion)
        self.grid.set_cursor_from_name("pointer")
        left.append(self.grid)
        legend = hbox(14)
        for cls, txt in (("dot-libur", "● Libur nasional"), ("dot-cuti", "● Cuti bersama"), ("dot-nasional", "● Hari nasional / internasional / Hijriyah")):
            legend.append(label(txt, ["tiny", cls]))
        left.append(legend)
        left.append(label("Angka kecil di bawah tanggal = tanggal Hijriyah.", ["tiny"]))
        cols.append(left)

        right = vbox(10, ["card"])
        right.set_size_request(330, -1)
        self.day_title = label("", ["h2"], wrap=True)
        self.day_hijri = label("", ["sub"], wrap=True)
        right.append(self.day_title)
        right.append(self.day_hijri)
        self.day_events = vbox(4)
        right.append(self.day_events)
        self.day_list = vbox(8)
        right.append(self.day_list)
        right.append(button("+ Tugas di tanggal ini", ["primary"], self._add))
        cols.append(right)
        self.body.append(cols)
        self.month_card = vbox(8, ["card"])
        self.body.append(self.month_card)
        self.refresh()

    # ----- interaksi
    def shift(self, delta):
        self.year, self.month = shift_month(self.year, self.month, delta)
        self.refresh()

    def go_today(self):
        t = date.today()
        self.year, self.month, self.selected = t.year, t.month, t
        self.refresh()

    def _add(self):
        TaskDialog(self.ctx.window, self.ctx.store, preset_date=self.selected).present()

    def _pressed(self, gesture, n_press, x, y):
        d = draw.calendar_hit(self.grid.get_width(), self.grid.get_height(), self.year, self.month, x, y)
        if not d:
            return
        self.selected = d
        if (d.year, d.month) != (self.year, self.month):
            self.year, self.month = d.year, d.month
        self.refresh()
        if n_press >= 2:
            self._add()

    def _motion(self, ctl, x, y):
        d = draw.calendar_hit(self.grid.get_width(), self.grid.get_height(), self.year, self.month, x, y)
        if d != self.hover:
            self.hover = d
            self.grid.queue_draw()

    def _leave(self, ctl):
        self.hover = None
        self.grid.queue_draw()

    def _draw(self, cr, w, h):
        draw.draw_calendar(cr, w, h, self.year, self.month, self.selected, self.hover, self.marks, koreksi=self.ctx.store.settings.get('hijri_koreksi', 0))

    def _event_row(self, e, with_type=False):
        r = hbox(8)
        r.append(label("●", ["tiny", f"dot-{e['jenis']}"]))
        txt = e["nama"] + (" (perkiraan)" if e["approx"] else "")
        if with_type:
            txt += f"  ·  {calendars.JENIS_LABEL[e['jenis']]}"
        r.append(label(txt, [], wrap=True))
        return r

    # ----- data
    def refresh(self):
        store = self.ctx.store
        self.month_l.set_text(f"{BULAN[self.month - 1]} {self.year}")
        self.marks = {}
        for t in store.tasks:
            due = parse_dt(t.get("due"))
            if due:
                tot, dn = self.marks.get(due.date(), (0, 0))
                self.marks[due.date()] = (tot + 1, dn + (1 if t.get("done") else 0))
        self.grid.queue_draw()

        kor = store.settings.get("hijri_koreksi", 0)
        first = date(self.year, self.month, 1)
        last = shift_month(self.year, self.month, 1)
        last = date(last[0], last[1], 1) - timedelta(days=1)
        h1, h2 = hijri.dari_masehi(first, kor), hijri.dari_masehi(last, kor)
        if (h1[0], h1[1]) == (h2[0], h2[1]):
            self.hmonth_l.set_text(f"{hijri.BULAN[h1[1] - 1]} {h1[0]} H")
        else:
            self.hmonth_l.set_text(f"{hijri.BULAN[h1[1] - 1]} {h1[0]} – {hijri.BULAN[h2[1] - 1]} {h2[0]} H")

        d = self.selected
        self.day_title.set_text(tanggal_panjang(d))
        self.day_hijri.set_text(hijri.teks(hijri.dari_masehi(d, kor)))
        clear(self.day_events)
        for e in calendars.events(d, kor):
            self.day_events.append(self._event_row(e))

        clear(self.month_card)
        self.month_card.append(label(f"Peristiwa bulan {BULAN[self.month - 1]} {self.year}", ["h2"]))
        n = 0
        x = first
        while x <= last:
            for e in calendars.events(x, kor):
                if e["minor"] and e["jenis"] != "hijri":
                    continue
                r = hbox(10)
                r.append(label(f"{x.day:02d}", ["h3"]))
                r.append(self._event_row(e, with_type=True))
                hh = hijri.dari_masehi(x, kor)
                small = label(hijri.teks_pendek(hh), ["tiny"], xalign=1.0)
                small.set_hexpand(True)
                r.append(small)
                self.month_card.append(r)
                n += 1
            x += timedelta(days=1)
        if not n:
            self.month_card.append(label("Tidak ada peristiwa penting bulan ini.", ["sub"]))
        clear(self.day_list)
        tasks = sorted(store.tasks_on(d), key=lambda t: (t.get("done"), t.get("due")))
        if not tasks:
            self.day_list.append(label("Tidak ada tugas di hari ini.", ["sub"], wrap=True))
        for t in tasks:
            self.day_list.append(make_task_row(self.ctx, t, compact=True))
