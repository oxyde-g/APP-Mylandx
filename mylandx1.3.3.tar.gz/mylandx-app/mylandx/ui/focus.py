import time
from datetime import date, timedelta

import gi
gi.require_version("Gtk", "4.0")
from gi.repository import Gtk, GLib

from .. import draw
from ..util import mmss, HARI_S
from .common import vbox, hbox, label, button, Canvas, Chips
from .page import Page

MODES = [("focus", "Fokus"), ("short", "Istirahat"), ("long", "Istirahat panjang")]


class FocusPage(Page):
    def __init__(self, ctx):
        super().__init__(ctx, "Fokus", "Timer belajar ala Pomodoro: fokus, istirahat, ulangi.")
        self.mode = "focus"
        self.running = False
        self.end = 0.0
        self.remaining = self._dur("focus")
        self.done_cycles = 0
        self._src = 0
        self.task_ids = [None]
        self._lock = False
        self.body.append(self.head)

        cols = hbox(18)
        # ---------- kiri: timer
        left = vbox(14, ["card"])
        left.set_hexpand(True)
        self.chips = Chips([m[1] for m in MODES], 0, self._pick_mode)
        self.chips.set_halign(Gtk.Align.CENTER)
        left.append(self.chips)
        self.ring = Canvas(self._draw_ring, 300, 300, expand=True)
        self.ring.set_size_request(300, 300)
        left.append(self.ring)

        ctrl = hbox(10)
        ctrl.set_halign(Gtk.Align.CENTER)
        self.start_btn = button("Mulai", ["primary"], self.toggle)
        self.start_btn.set_size_request(130, -1)
        ctrl.append(self.start_btn)
        ctrl.append(button("Ulang", [], self.reset))
        ctrl.append(button("Lewati", [], self.skip))
        left.append(ctrl)

        trow = hbox(8)
        trow.set_halign(Gtk.Align.CENTER)
        trow.append(label("Belajar untuk:", ["sub"]))
        self.task_dd = Gtk.DropDown.new_from_strings(["Tanpa tugas"])
        trow.append(self.task_dd)
        left.append(trow)

        drow = hbox(16)
        drow.set_halign(Gtk.Align.CENTER)
        drow.set_margin_top(4)
        self.spins = {}
        for key, name in (("focus", "Fokus"), ("short", "Istirahat"), ("long", "Panjang")):
            col = vbox(4)
            col.append(label(f"{name} (mnt)", ["tiny"], xalign=0.5))
            sp = Gtk.SpinButton.new_with_range(1, 180, 1)
            sp.set_value(ctx.store.settings[key])
            sp.connect("value-changed", self._dur_changed, key)
            col.append(sp)
            drow.append(col)
            self.spins[key] = sp
        left.append(drow)
        cols.append(left)

        # ---------- kanan: statistik
        right = vbox(16)
        right.set_size_request(340, -1)
        stat = vbox(4, ["card"])
        stat.append(label("Hari ini", ["tiny"]))
        self.today_min = label("0 mnt", ["stat"])
        self.today_sub = label("", ["tiny"])
        stat.append(self.today_min)
        stat.append(self.today_sub)
        right.append(stat)

        chart = vbox(8, ["card"])
        chart.append(label("7 hari terakhir (menit)", ["h3"]))
        self.bars = Canvas(self._draw_bars, 300, 150, expand=False)
        chart.append(self.bars)
        self.week_l = label("", ["tiny"])
        chart.append(self.week_l)
        right.append(chart)

        tip = vbox(4, ["card-flat"])
        tip.append(label("Tips", ["h3"]))
        tip.append(label("Setelah beberapa sesi fokus, ambil istirahat panjang. Sesi yang dihentikan di tengah tetap dicatat menitnya.", ["tiny"], wrap=True))
        right.append(tip)
        cols.append(right)
        self.body.append(cols)
        self.refresh()
        self._update_ring()

    # ---------- durasi / mode
    def _dur(self, mode):
        return float(self.ctx.store.settings[mode] * 60)

    def _dur_changed(self, spin, key):
        if self._lock:
            return
        self.ctx.store.set_setting(key, spin.get_value_as_int())
        if key == self.mode and not self.running:
            self.remaining = self._dur(self.mode)
        self._update_ring()

    def _pick_mode(self, i):
        if self._lock:
            return
        self._commit_partial()
        self.running = False
        self._stop_src()
        self.mode = MODES[i][0]
        self.remaining = self._dur(self.mode)
        self._after_change()

    def _set_mode(self, mode):
        self.mode = mode
        self.remaining = self._dur(mode)
        self._lock = True
        self.chips.set_index([m[0] for m in MODES].index(mode))
        self._lock = False

    def _after_change(self):
        self.start_btn.set_label("Jeda" if self.running else "Mulai")
        self._update_ring()

    # ---------- kontrol
    def toggle(self):
        if self.running:
            self.remaining = max(0.0, self.end - time.monotonic())
            self.running = False
            self._stop_src()
        else:
            self.end = time.monotonic() + self.remaining
            self.running = True
            if not self._src:
                self._src = GLib.timeout_add(200, self._tick)
        self._after_change()

    def reset(self):
        self._commit_partial()
        self.running = False
        self._stop_src()
        self.remaining = self._dur(self.mode)
        self._after_change()

    def skip(self):
        self._commit_partial()
        self.running = False
        self._stop_src()
        self._advance(completed=False)
        self._after_change()

    def start_now(self):
        """Dipanggil dari Beranda: ke mode fokus dan langsung jalan."""
        if not self.running:
            if self.mode != "focus":
                self._set_mode("focus")
            self.toggle()

    def _stop_src(self):
        if self._src:
            GLib.source_remove(self._src)
            self._src = 0

    def _elapsed(self):
        rem = max(0.0, self.end - time.monotonic()) if self.running else self.remaining
        return self._dur(self.mode) - rem

    def _selected_task(self):
        i = self.task_dd.get_selected()
        return self.task_ids[i] if 0 <= i < len(self.task_ids) else None

    def _commit_partial(self):
        """Catat menit fokus yang sudah berjalan bila sesi dihentikan di tengah."""
        if self.mode != "focus":
            return
        mins = int(self._elapsed() // 60)
        if mins >= 1:
            self.ctx.store.add_focus(mins, 0, self._selected_task())

    def _advance(self, completed):
        if self.mode == "focus":
            if completed:
                self.done_cycles += 1
            cycles = max(1, self.ctx.store.settings["cycles"])
            nxt = "long" if (self.done_cycles and self.done_cycles % cycles == 0 and completed) else "short"
        else:
            nxt = "focus"
        self._set_mode(nxt)

    def _tick(self):
        rem = self.end - time.monotonic()
        if rem <= 0:
            self._finish()
            return False
        self.remaining = rem
        self._update_ring()
        return True

    def _finish(self):
        self._src = 0
        self.running = False
        ctx = self.ctx
        was = self.mode
        if was == "focus":
            mins = int(self._dur("focus") // 60)
            ctx.store.add_focus(mins, 1, self._selected_task())
        self._advance(completed=True)
        ctx.sound.once("ding")
        if was == "focus":
            ctx.notifier.send("Sesi fokus selesai", "Waktunya istirahat sebentar." if self.mode == "short" else "Kerja bagus! Ambil istirahat panjang.", urgent=True, nid="focus")
        else:
            ctx.notifier.send("Istirahat selesai", "Yuk lanjut fokus.", urgent=True, nid="focus")
        if ctx.store.settings["auto_next"]:
            self.toggle()
        else:
            self._after_change()

    # ---------- gambar
    def _ring_sub(self):
        if self.mode == "focus":
            cycles = max(1, self.ctx.store.settings["cycles"])
            return f"Fokus · sesi {self.done_cycles % cycles + 1} dari {cycles}"
        return "Istirahat panjang" if self.mode == "long" else "Istirahat"

    def _draw_ring(self, cr, w, h):
        total = self._dur(self.mode)
        rem = max(0.0, self.end - time.monotonic()) if self.running else self.remaining
        draw.draw_ring(cr, w, h, rem / total if total else 0, mmss(rem), self._ring_sub(),
                       "accent" if self.mode == "focus" else "ok")

    def _draw_bars(self, cr, w, h):
        today = date.today()
        items = []
        for i in range(6, -1, -1):
            d = today - timedelta(days=i)
            items.append((HARI_S[d.weekday()], self.ctx.store.focus_on(d)["minutes"], i == 0))
        draw.draw_bars(cr, w, h, items)

    def _update_ring(self):
        self.ring.queue_draw()
        rem = max(0.0, self.end - time.monotonic()) if self.running else self.remaining
        win = self.ctx.window
        if win is not None:
            title = f"{mmss(rem)} · {'Fokus' if self.mode == 'focus' else 'Istirahat'} — mylandx" if self.running else "mylandx"
            if title != getattr(self, "_title", None):
                self._title = title
                win.set_title(title)

    # ---------- refresh dari store
    def refresh(self):
        store = self.ctx.store
        rec = store.focus_on(date.today())
        self.today_min.set_text(f"{rec['minutes']} mnt")
        self.today_sub.set_text(f"{rec['count']} sesi selesai")
        week = sum(store.focus_on(date.today() - timedelta(days=i))["minutes"] for i in range(7))
        self.week_l.set_text(f"Total minggu ini: {week // 60} jam {week % 60} menit")
        self.bars.queue_draw()

        # daftar tugas untuk dropdown (pertahankan pilihan)
        cur = self._selected_task()
        act = [t for t in store.tasks if not t.get("done")]
        self.task_ids = [None] + [t["id"] for t in act]
        model = Gtk.StringList.new(["Tanpa tugas"] + [t["title"] for t in act])
        self._lock = True
        self.task_dd.set_model(model)
        self.task_dd.set_selected(self.task_ids.index(cur) if cur in self.task_ids else 0)
        self._lock = False
