import gi
gi.require_version("Gtk", "4.0")
from gi.repository import Gtk, Gio

from ..theme import ACCENTS
from .. import __version__
from .. import prayer as prayer_mod, world
from .common import vbox, hbox, label, button, Chips, switch_row
from .page import Page


class SettingsPage(Page):
    def __init__(self, ctx):
        super().__init__(ctx, "Pengaturan", "Atur tampilan dan perilaku mylandx.")
        st = ctx.store.settings
        store = ctx.store
        self.body.append(self.head)

        # --- tampilan
        c = vbox(14, ["card"])
        c.append(label("Tampilan", ["h2"]))
        row = hbox(12)
        t = label("Tema", ["h3"])
        t.set_hexpand(True)
        row.append(t)
        self.theme_chips = Chips(["Gelap", "Terang"], 0 if st["theme"] == "dark" else 1,
                                 lambda i: store.set_setting("theme", "dark" if i == 0 else "light"))
        row.append(self.theme_chips)
        c.append(row)

        row = hbox(12)
        t = label("Warna aksen", ["h3"])
        t.set_hexpand(True)
        row.append(t)
        self.swatches = []
        first = None
        for name, hexv in ACCENTS:
            b = Gtk.ToggleButton()
            b.add_css_class("swatch")
            b.set_tooltip_text(name)
            if first is None:
                first = b
            else:
                b.set_group(first)
            b.set_active(hexv.lower() == st["accent"].lower())
            b.connect("toggled", lambda btn, h=hexv: btn.get_active() and store.set_setting("accent", h))
            row.append(b)
            self.swatches.append((b, hexv))
        c.append(row)
        self.body.append(c)
        self._swatch_css = Gtk.CssProvider()
        self._apply_swatch_css()

        # --- umum
        c = vbox(16, ["card"])
        c.append(label("Umum", ["h2"]))
        self.sw = {}
        for key, title, sub in (
            ("clock24", "Format 24 jam", "Matikan untuk tampilan AM/PM."),
            ("sound", "Suara alarm & timer", "Bunyi saat alarm berdering atau sesi fokus selesai."),
            ("notif", "Notifikasi desktop", "Pengingat tugas, alarm, dan timer muncul sebagai notifikasi."),
            ("auto_next", "Lanjut otomatis di Fokus", "Setelah sesi selesai, sesi berikutnya langsung berjalan."),
            ("background", "Tetap berjalan di latar belakang", "Menutup jendela tidak menghentikan alarm. Buka lagi lewat menu aplikasi, atau klik “Keluar” di sidebar untuk menutup total."),
        ):
            r, sw = switch_row(title, sub, st[key], lambda v, k=key: store.set_setting(k, v))
            c.append(r)
            self.sw[key] = sw
        r, self.autostart = switch_row("Mulai otomatis saat login", "Jalan diam-diam di latar belakang begitu kamu login.",
                                       ctx.autostart_enabled(), lambda v: ctx.set_autostart(v))
        c.append(r)

        row = hbox(12)
        t = vbox(2)
        t.set_hexpand(True)
        t.append(label("Sesi fokus sebelum istirahat panjang", ["h3"]))
        row.append(t)
        self.cycles = Gtk.SpinButton.new_with_range(2, 10, 1)
        self.cycles.set_value(st["cycles"])
        self.cycles.connect("value-changed", lambda s: store.set_setting("cycles", s.get_value_as_int()))
        row.append(self.cycles)
        c.append(row)
        self.body.append(c)

        # --- sholat
        c = vbox(16, ["card"])
        c.append(label("Waktu sholat & adzan", ["h2"]))
        r, self.sw_prayer = switch_row("Notifikasi waktu sholat", "Muncul notifikasi dan adzan saat waktu 5 sholat tiba.",
                                       st.get("prayer", True), lambda v: store.set_setting("prayer", v))
        c.append(r)
        # --- lokasi: negara -> kota (semua negara) atau koordinat manual
        negs = sorted(world.NEGARA.items(), key=lambda kv: (kv[0] != "ID", kv[1]))
        self.neg_codes = [c for c, _ in negs]
        self.neg_dd = Gtk.DropDown.new_from_strings([n for _, n in negs])
        self._searchable(self.neg_dd)
        self.city_dd = Gtk.DropDown.new_from_strings(["—"])
        self._searchable(self.city_dd)
        self.city_names = []
        self._loc_lock = False
        for title, dd in (("Negara", self.neg_dd), ("Kota", self.city_dd)):
            row = hbox(12)
            t = label(title, ["h3"])
            t.set_hexpand(True)
            row.append(t)
            dd.set_size_request(240, -1)
            row.append(dd)
            c.append(row)
        self.manual = vbox(8)
        self.manual.append(label("Kota tidak ada di daftar? Isi koordinatnya (cari di peta; contoh Bandung: -6.9175, 107.6191). "
                                 "Zona waktu boleh dikosongkan, dipilih otomatis dari kota terdekat.", ["tiny"], wrap=True))
        self.m_nama, self.m_lat, self.m_lng, self.m_tz = (Gtk.Entry() for _ in range(4))
        for e, ph in ((self.m_nama, "Nama lokasi"), (self.m_lat, "Lintang (-90…90)"), (self.m_lng, "Bujur (-180…180)"),
                      (self.m_tz, "Zona waktu, mis. Asia/Jakarta (opsional)")):
            e.set_placeholder_text(ph)
            self.manual.append(e)
        self.m_err = label("", ["tiny", "danger-text"], wrap=True)
        self.manual.append(self.m_err)
        self.manual.append(button("Terapkan koordinat", ["primary"], self._apply_manual))
        c.append(self.manual)
        self._load_location()
        self.neg_dd.connect("notify::selected", self._neg_changed)
        self.city_dd.connect("notify::selected", self._city_changed)

        row = hbox(12)
        t = vbox(2)
        t.set_hexpand(True)
        t.append(label("Mazhab Ashar", ["h3"]))
        t.append(label("Standar (Syafi'i, Maliki, Hanbali) atau Hanafi (bayangan 2x).", ["tiny"], wrap=True))
        row.append(t)
        self.asr = Chips(["Standar", "Hanafi"], 1 if st.get("asr_hanafi") else 0,
                         lambda i: store.set_setting("asr_hanafi", i == 1))
        row.append(self.asr)
        c.append(row)

        row = hbox(12)
        t = vbox(2)
        t.set_hexpand(True)
        t.append(label("Suara", ["h3"]))
        t.append(label("Adzan memakai file audio milikmu (mp3/ogg/wav). Tanpa file, dibunyikan lonceng.", ["tiny"], wrap=True))
        row.append(t)
        modes = ["adzan", "chime", "senyap"]
        self.mode = Chips(["Adzan", "Lonceng", "Senyap"], modes.index(st.get("adzan_mode", "adzan")) if st.get("adzan_mode", "adzan") in modes else 0,
                          lambda i: store.set_setting("adzan_mode", modes[i]))
        row.append(self.mode)
        c.append(row)

        self.file_labels = {}
        for key, title in (("adzan_file", "File adzan"), ("adzan_subuh_file", "File adzan Subuh (opsional)")):
            row = hbox(10)
            t = vbox(2)
            t.set_hexpand(True)
            t.append(label(title, ["h3"]))
            fl = label("", ["tiny"], ellipsize=True)
            t.append(fl)
            self.file_labels[key] = fl
            row.append(t)
            row.append(button("Pilih…", [], lambda k=key: self._pick(k)))
            row.append(button("Hapus", ["ghost"], lambda k=key: store.set_setting(k, "")))
            c.append(row)

        row = hbox(12)
        t = label("Ingatkan sebelum waktu sholat", ["h3"])
        t.set_hexpand(True)
        row.append(t)
        rem = [0, 5, 10, 15]
        cur = st.get("prayer_remind", 0)
        self.remind = Chips(["Mati", "5 mnt", "10 mnt", "15 mnt"], rem.index(cur) if cur in rem else 0,
                            lambda i: store.set_setting("prayer_remind", rem[i]))
        row.append(self.remind)
        c.append(row)

        row = hbox(12)
        t = vbox(2)
        t.set_hexpand(True)
        t.append(label("Koreksi tanggal Hijriyah", ["h3"]))
        t.append(label("Awal bulan Hijriyah bisa berbeda sehari tergantung rukyat. Geser jika tanggalnya meleset dari pengumuman.", ["tiny"], wrap=True))
        row.append(t)
        kor = [-1, 0, 1]
        cur = st.get("hijri_koreksi", 0)
        self.kor = Chips(["−1 hari", "0", "+1 hari"], kor.index(cur) if cur in kor else 1,
                         lambda i: store.set_setting("hijri_koreksi", kor[i]))
        row.append(self.kor)
        c.append(row)

        r, self.sw_notice = switch_row("Pemberitahuan hari penting di Beranda", "Tampil di dekat jam: libur nasional, hari internasional, dan peristiwa Hijriyah.",
                                       st.get("home_notice", True), lambda v: store.set_setting("home_notice", v))
        c.append(r)
        self.body.append(c)
        self._files()

        # --- data
        c = vbox(10, ["card"])
        c.append(label("Data", ["h2"]))
        c.append(label(f"mylandx v{__version__}", ["tiny"]))
        c.append(label(f"Semua data tersimpan lokal di:\n{store.dir}", ["sub"], wrap=True, selectable=True))
        c.append(button("Buka folder data", [], self._open_dir))
        self.body.append(c)

    # ---- lokasi sholat
    @staticmethod
    def _searchable(dd):
        try:
            dd.set_enable_search(True)
            dd.set_expression(Gtk.PropertyExpression.new(Gtk.StringObject, None, "string"))
        except Exception:
            pass

    def _city_list(self, code):
        return sorted(world.KOTA.get(code, []), key=lambda c: c[0])

    def _fill_cities(self, code, select=None, manual=False):
        names = [c[0] for c in self._city_list(code)]
        self.city_names = names
        self._loc_lock = True
        self.city_dd.set_model(Gtk.StringList.new(names + ["✎ Koordinat manual…"]))
        if manual:
            self.city_dd.set_selected(len(names))
        else:
            self.city_dd.set_selected(names.index(select) if select in names else 0)
        self._loc_lock = False
        self.manual.set_visible(manual)

    def _load_location(self):
        st = self.ctx.store.settings
        code = st.get("negara", "ID")
        if code not in world.KOTA:
            code = "ID"
        self._loc_lock = True
        self.neg_dd.set_selected(self.neg_codes.index(code))
        self._loc_lock = False
        m = st.get("kota_manual")
        self._fill_cities(code, st.get("kota"), manual=isinstance(m, dict))
        if isinstance(m, dict):
            self.m_nama.set_text(str(m.get("nama", "")))
            self.m_lat.set_text(str(m.get("lat", "")))
            self.m_lng.set_text(str(m.get("lng", "")))
            self.m_tz.set_text(str(m.get("tz", "")))

    def _neg_changed(self, dd, _p):
        if self._loc_lock:
            return
        code = self.neg_codes[dd.get_selected()]
        cities = self._city_list(code)
        first = cities[0][0]
        self._fill_cities(code, first)
        st = self.ctx.store
        st.set_setting("negara", code)
        st.set_setting("kota_manual", None)
        st.set_setting("kota", first)

    def _city_changed(self, dd, _p):
        if self._loc_lock:
            return
        i = dd.get_selected()
        st = self.ctx.store
        if i >= len(self.city_names):          # pilihan "Koordinat manual"
            self.manual.set_visible(True)
            return
        self.manual.set_visible(False)
        st.set_setting("kota_manual", None)
        st.set_setting("kota", self.city_names[i])

    def _apply_manual(self):
        try:
            lat, lng = float(self.m_lat.get_text().replace(",", ".")), float(self.m_lng.get_text().replace(",", "."))
        except ValueError:
            self.m_err.set_text("Lintang dan bujur harus berupa angka, mis. -6.9175 dan 107.6191.")
            return
        if not (-90 <= lat <= 90 and -180 <= lng <= 180):
            self.m_err.set_text("Lintang harus −90…90 dan bujur −180…180.")
            return
        code = self.neg_codes[self.neg_dd.get_selected()]
        tz = self.m_tz.get_text().strip() or world.tz_terdekat(lat, lng, code)
        try:
            from zoneinfo import ZoneInfo
            ZoneInfo(tz)
        except Exception:
            self.m_err.set_text(f"Zona waktu “{tz}” tidak dikenal. Contoh: Asia/Jakarta, Europe/London.")
            return
        self.m_err.set_text("")
        nama = self.m_nama.get_text().strip() or "Lokasi saya"
        self.ctx.store.set_setting("negara", code)
        self.ctx.store.set_setting("kota_manual", dict(nama=nama, lat=lat, lng=lng, tz=tz))

    def _pick(self, key):
        dlg = Gtk.FileDialog()
        dlg.set_title("Pilih file audio adzan")
        flt = Gtk.FileFilter()
        flt.set_name("Audio")
        for pat in ("*.mp3", "*.ogg", "*.oga", "*.opus", "*.wav", "*.flac", "*.m4a", "*.aac"):
            flt.add_pattern(pat)
        fl = Gio.ListStore.new(Gtk.FileFilter)
        fl.append(flt)
        dlg.set_filters(fl)

        def done(d, res):
            try:
                f = d.open_finish(res)
            except Exception:
                return
            if f and f.get_path():
                self.ctx.store.set_setting(key, f.get_path())

        dlg.open(self.ctx.window, None, done)

    def _files(self):
        import os
        st = self.ctx.store.settings
        for key, fl in self.file_labels.items():
            p = st.get(key, "")
            if not p:
                fl.set_text("belum dipilih")
            elif not os.path.isfile(p):
                fl.set_text(f"file tidak ditemukan: {os.path.basename(p)}")
            else:
                fl.set_text(p)

    def _open_dir(self):
        try:
            Gio.AppInfo.launch_default_for_uri(f"file://{self.ctx.store.dir}", None)
        except Exception as e:
            print("mylandx: gagal membuka folder:", e)

    def _apply_swatch_css(self):
        css = "".join(f"button.swatch.sw{i} {{ background: {h}; }}\n" for i, (_, h) in enumerate(self.swatches))
        for i, (b, _) in enumerate(self.swatches):
            b.add_css_class(f"sw{i}")
        try:
            self._swatch_css.load_from_string(css)
        except AttributeError:
            self._swatch_css.load_from_data(css.encode())
        from gi.repository import Gdk
        Gtk.StyleContext.add_provider_for_display(Gdk.Display.get_default(), self._swatch_css, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION + 1)

    def refresh(self):
        st = self.ctx.store.settings
        self._files()
        for key, sw in self.sw.items():
            if sw.get_active() != bool(st[key]):
                sw.set_active(bool(st[key]))
