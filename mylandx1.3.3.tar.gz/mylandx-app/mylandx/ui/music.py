import os

import gi
gi.require_version("Gtk", "4.0")
from gi.repository import Gtk, Gio, GLib

from .. import draw, music
from .common import vbox, hbox, label, button, Canvas, Chips, clear
from .dialogs import confirm, TextPrompt, AlbumPickDialog
from .page import Page

MAX_ROWS = 300
ALL, FAV = "all", "fav"


class MusicPage(Page):
    """Pemutar musik lokal: daftar lagu, favorit, dan album buatan sendiri."""

    def __init__(self, ctx):
        super().__init__(ctx, "Musik", "Lagu dari komputermu. Kelompokkan ke album sesukamu.")
        self.view = ALL
        self.results = []
        self._last = None
        self._sig = None
        self._flash = ""
        self.body.append(self.head)

        c = vbox(12, ["card"])
        row = hbox(8)
        self.entry = Gtk.Entry(placeholder_text="Cari di daftar ini…")
        self.entry.set_hexpand(True)
        self.entry.connect("changed", lambda *_: self._typed())
        row.append(self.entry)
        row.append(button("Tambah file…", [], self._add_files))
        row.append(button("Tambah folder…", [], self._add_folder))
        c.append(row)

        vrow = hbox(8)
        self.chips_box = hbox(0)
        sw = Gtk.ScrolledWindow()
        sw.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.NEVER)
        sw.set_hexpand(True)
        sw.set_child(self.chips_box)
        vrow.append(sw)
        vrow.append(button("+ Album", ["primary"], self._new_album))
        c.append(vrow)

        self.actions = hbox(8)
        self.play_all = button("Putar semua", ["primary"], self._play_all)
        self.rename_btn = button("Ubah nama album", [], self._rename_album)
        self.del_album_btn = button("Hapus album", ["ghost", "danger"], self._delete_album)
        self.clear_btn = button("Kosongkan daftar", ["ghost", "danger"], self._clear_all)
        for w in (self.play_all, self.rename_btn, self.del_album_btn, self.clear_btn):
            self.actions.append(w)
        c.append(self.actions)
        self.body.append(c)

        self.status = label("", ["sub"], wrap=True)
        self.body.append(self.status)
        self.list = vbox(8)
        self.body.append(self.list)

        ctx.player.listeners.append(self._player_changed)
        self.refresh()

    # ---------------- data tampilan
    def _fav_tracks(self):
        st = self.ctx.store
        return [t for t in st.library if st.is_fav(t["id"])]

    def _source_tracks(self):
        st = self.ctx.store
        if self.view == ALL:
            return st.library
        if self.view == FAV:
            return self._fav_tracks()
        return st.album_tracks(self.view)

    def _rebuild_chips(self):
        st = self.ctx.store
        ids = [ALL, FAV] + [a["id"] for a in st.albums]
        names = [f"Semua lagu ({len(st.library)})", f"Favorit ({len(self._fav_tracks())})"] + \
                [f"{a['name']} ({len(st.album_tracks(a['id']))})" for a in st.albums]
        if self.view not in ids:
            self.view = ALL
        sig = (tuple(ids), tuple(names), self.view)
        if sig == self._sig:
            return
        self._sig = sig
        clear(self.chips_box)
        self.chips = Chips(names, ids.index(self.view), lambda i: self._pick(ids[i]))
        self.chips_box.append(self.chips)

    def _typed(self):
        self._flash = ""
        self.search()

    def _pick(self, view):
        self.view = view
        self._flash = ""
        self._sig = None
        self.refresh()

    def _sync_chrome(self):
        album = self.view not in (ALL, FAV)
        self.rename_btn.set_visible(album)
        self.del_album_btn.set_visible(album)
        self.clear_btn.set_visible(self.view == ALL and bool(self.ctx.store.library))
        self.play_all.set_visible(bool(self.results))

    def refresh(self):
        self._rebuild_chips()
        self.search()

    def search(self):
        q = self.entry.get_text().strip()
        res = [t for t in self._source_tracks() if music.matches(t, q)]
        if q:
            empty = "Tidak ada yang cocok."
        elif self.view == ALL:
            empty = "Belum ada lagu. Klik “Tambah file…” atau “Tambah folder…” untuk memasukkan musikmu."
        elif self.view == FAV:
            empty = "Belum ada favorit. Tekan “Suka” di lagu mana pun."
        else:
            empty = "Album ini masih kosong. Di daftar “Semua lagu”, tekan “Album…” di lagu untuk memasukkannya ke sini."
        self._show(res, empty)

    def _show(self, tracks, empty_text):
        self.results = tracks
        self.status.set_text(self._flash or ("" if tracks else empty_text))
        if len(tracks) > MAX_ROWS and not self._flash:
            self.status.set_text(f"Menampilkan {MAX_ROWS} dari {len(tracks)} lagu — pakai kolom cari untuk mempersempit.")
        self._sync_chrome()
        self._render()

    def _render(self):
        clear(self.list)
        cur = self.ctx.player.current
        cur_id = cur["id"] if cur else None
        for i, t in enumerate(self.results[:MAX_ROWS]):
            self.list.append(self._row(i, t, t["id"] == cur_id))

    def _row(self, i, t, playing):
        ctx, st = self.ctx, self.ctx.store
        missing = bool(t.get("path")) and not os.path.exists(t["path"])
        row = hbox(12, ["row"])
        if playing:
            row.add_css_class("row-sel")
        cv = Canvas(lambda cr, w, h, t=t: draw.draw_cover(cr, w, h, t["id"], t["title"]), 46, 46)
        cv.set_valign(Gtk.Align.CENTER)
        row.append(cv)
        info = vbox(2)
        info.set_hexpand(True)
        info.set_valign(Gtk.Align.CENTER)
        title = label(t["title"], ["row-title"], ellipsize=True)
        if playing:
            title.add_css_class("accent")
        info.append(title)
        sub = label("File tidak ditemukan (dipindah atau dihapus?)" if missing else
                    t["artist"] + (f" · {t['album']}" if t.get("album") else ""), ["tiny"], ellipsize=True)
        if missing:
            sub.add_css_class("danger-text")
        info.append(sub)
        row.append(info)
        fav = st.is_fav(t["id"])
        row.append(button("Disukai" if fav else "Suka", ["ghost"] + (["accent"] if fav else []), lambda t=t: st.toggle_fav(t)))
        row.append(button("Album…", ["ghost"], lambda t=t: AlbumPickDialog(ctx.window, st, t).present(), "Masukkan ke album"))
        if self.view in (ALL, FAV):
            row.append(button("Hapus", ["ghost", "danger"], lambda t=t: confirm(
                ctx.window, f"Hapus “{t['title']}” dari daftar?\n(File aslinya di komputer tidak ikut terhapus.)",
                lambda: st.remove_track(t["id"])), "Hapus dari daftar lagu"))
        else:
            row.append(button("Keluarkan", ["ghost", "danger"], lambda t=t: st.album_remove(self.view, t["id"]),
                              "Keluarkan dari album ini (lagu tetap ada di daftar)"))
        play = button("Putar", ["primary"], lambda i=i: ctx.player.play_queue(self.results[:MAX_ROWS], i))
        play.set_sensitive(not missing)
        row.append(play)
        return row

    def _player_changed(self):
        p = self.ctx.player
        key = (p.current["id"] if p.current else None, p.state)
        if key != self._last:
            self._last = key
            if self.results:
                self._render()

    # ---------------- aksi
    def _play_all(self):
        if self.results:
            self.ctx.player.play_queue(self.results[:MAX_ROWS], 0)

    def _new_album(self):
        def ok(name):
            al = self.ctx.store.add_album(name)
            self.view = al["id"]
            self._sig = None
            self.refresh()
        TextPrompt(self.ctx.window, "Album baru", "Nama album", "", ok, "Buat").present()

    def _rename_album(self):
        al = self.ctx.store.get_album(self.view)
        if al:
            TextPrompt(self.ctx.window, "Ubah nama album", "Nama album", al["name"],
                       lambda name: self.ctx.store.rename_album(al["id"], name)).present()

    def _delete_album(self):
        al = self.ctx.store.get_album(self.view)
        if al:
            confirm(self.ctx.window, f"Hapus album “{al['name']}”?\n(Lagu-lagunya tetap ada di daftar.)",
                    lambda: self._do_delete_album(al["id"]))

    def _do_delete_album(self, aid):
        self.ctx.store.delete_album(aid)
        self.view = ALL
        self._sig = None
        self.refresh()

    def _clear_all(self):
        confirm(self.ctx.window, "Kosongkan seluruh daftar lagu?\n(File aslinya di komputer tidak ikut terhapus.)",
                lambda: self.ctx.store.clear_library(), "Kosongkan")

    # ---------------- tambah file lokal
    def _file_dialog(self, folder):
        dlg = Gtk.FileDialog()
        dlg.set_title("Pilih folder musik" if folder else "Pilih lagu")
        if not folder:
            flt = Gtk.FileFilter()
            flt.set_name("File audio")
            for ext in music.AUDIO_EXT:
                flt.add_pattern("*" + ext)
                flt.add_pattern("*" + ext.upper())
            filters = Gio.ListStore.new(Gtk.FileFilter)
            filters.append(flt)
            dlg.set_filters(filters)

        def done(d, res):
            try:
                if folder:
                    paths = [d.select_folder_finish(res).get_path()]
                else:
                    files = d.open_multiple_finish(res)
                    paths = [files.get_item(i).get_path() for i in range(files.get_n_items())]
            except GLib.Error:
                return  # dibatalkan
            tracks = music.scan_paths([p for p in paths if p])
            self.add_tracks(tracks)
        if folder:
            dlg.select_folder(self.ctx.window, None, done)
        else:
            dlg.open_multiple(self.ctx.window, None, done)

    def add_tracks(self, tracks):
        st = self.ctx.store
        added = st.add_library(tracks)
        if self.view not in (ALL, FAV):  # sedang membuka album: lagu baru ikut masuk album ini
            st.album_add(self.view, [t["id"] for t in tracks])
        self._flash = f"{added} lagu baru ditambahkan" + (f" ({len(tracks) - added} sudah ada)." if len(tracks) > added else ".")
        self.status.set_text(self._flash)

    def _add_files(self):
        self._file_dialog(False)

    def _add_folder(self):
        self._file_dialog(True)
