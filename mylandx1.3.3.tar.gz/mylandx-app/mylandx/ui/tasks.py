from datetime import datetime, date

import gi
gi.require_version("Gtk", "4.0")
from gi.repository import Gtk

from ..util import parse_dt
from .common import vbox, hbox, label, button, clear, Chips
from .dialogs import TaskDialog
from .page import Page
from .taskrow import make_task_row

FILTERS = ["Aktif", "Hari ini", "Selesai", "Semua"]


class TasksPage(Page):
    def __init__(self, ctx):
        super().__init__(ctx, "Tugas", "")
        head = hbox(12)
        self.head.set_hexpand(True)
        head.append(self.head)
        head.append(button("+ Tugas baru", ["primary"], lambda: TaskDialog(ctx.window, ctx.store).present()))
        self.head.set_valign(Gtk.Align.CENTER)
        self.body.append(head)

        add = hbox(8, ["card"])
        self.entry = Gtk.Entry(placeholder_text="Tulis tugas cepat lalu tekan Enter…")
        self.entry.set_hexpand(True)
        self.entry.connect("activate", lambda *_: self._quick())
        add.append(self.entry)
        add.append(button("Tambah", ["primary"], self._quick))
        add.append(button("Detail…", [], lambda: self._detail()))
        self.body.append(add)

        self.filter = Chips(FILTERS, 0, lambda i: self.refresh())
        self.body.append(self.filter)

        self.list = vbox(8)
        self.body.append(self.list)
        self.refresh()

    def _quick(self):
        text = self.entry.get_text().strip()
        if not text:
            return
        self.ctx.store.add_task(title=text)
        self.entry.set_text("")

    def _detail(self):
        text = self.entry.get_text().strip()
        self.entry.set_text("")
        TaskDialog(self.ctx.window, self.ctx.store, title=text).present()

    def refresh(self):
        store = self.ctx.store
        now = datetime.now()
        tasks = store.tasks
        active = [t for t in tasks if not t.get("done")]
        late = [t for t in active if parse_dt(t.get("due")) and parse_dt(t["due"]) < now]
        done = [t for t in tasks if t.get("done")]
        self.sub.set_text(f"{len(active)} aktif · {len(late)} terlambat · {len(done)} selesai")

        f = self.filter.index
        if f == 0:
            shown = active
        elif f == 1:
            shown = [t for t in active if parse_dt(t.get("due")) and parse_dt(t["due"]).date() <= date.today()]
        elif f == 2:
            shown = sorted(done, key=lambda t: t.get("done_at") or "", reverse=True)
        else:
            shown = tasks

        def key(t):
            d = parse_dt(t.get("due"))
            return (bool(t.get("done")), d is None, d or datetime.max, -t.get("priority", 1))
        if f != 2:
            shown = sorted(shown, key=key)

        clear(self.list)
        if not shown:
            msg = {0: "Belum ada tugas aktif. Ketik di atas lalu tekan Enter.",
                   1: "Tidak ada tugas yang jatuh tempo hari ini.",
                   2: "Belum ada tugas yang selesai.",
                   3: "Belum ada tugas sama sekali."}[f]
            e = label(msg, ["sub"], xalign=0.5)
            e.set_margin_top(40)
            self.list.append(e)
        for t in shown:
            self.list.append(make_task_row(self.ctx, t))
