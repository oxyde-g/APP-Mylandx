import gi
gi.require_version("Gtk", "4.0")
from gi.repository import Gtk

from .common import vbox, label, pad


class Page(Gtk.ScrolledWindow):
    """Halaman bergulir dengan header (judul + subjudul)."""
    title = ""

    def __init__(self, ctx, title, subtitle=""):
        super().__init__()
        self.ctx = ctx
        self.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        self.set_hexpand(True)
        self.set_vexpand(True)
        self.body = vbox(18)
        pad(self.body, 26, 30, 26, 30)
        self.set_child(self.body)
        self.head = vbox(2)
        self.h1 = label(title, ["h1"])
        self.sub = label(subtitle, ["sub"])
        self.head.append(self.h1)
        self.head.append(self.sub)

    def refresh(self):
        pass
