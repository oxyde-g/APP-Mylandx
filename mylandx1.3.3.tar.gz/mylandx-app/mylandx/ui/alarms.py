from datetime import datetime

import gi
gi.require_version("Gtk", "4.0")
from gi.repository import Gtk

from ..util import fmt_hhmm, days_text, next_alarm, durasi
from .common import vbox, hbox, label, button, clear
from .dialogs import AlarmDialog, confirm
from .page import Page


class AlarmsPage(Page):
    def __init__(self, ctx):
        super().__init__(ctx, "Alarm", "")
        head = hbox(12)
        self.head.set_hexpand(True)
        self.head.set_valign(Gtk.Align.CENTER)
        head.append(self.head)
        head.append(button("+ Alarm baru", ["primary"], lambda: AlarmDialog(ctx.window, ctx.store).present()))
        self.body.append(head)
        self.list = vbox(10)
        self.body.append(self.list)
        self.refresh()

    def refresh(self):
        store = self.ctx.store
        now = datetime.now()
        nxt = next_alarm(store.alarms, now)
        self.sub.set_text(f"Berikutnya dalam {durasi((nxt[0] - now).total_seconds())}" if nxt else "Belum ada alarm yang aktif")
        clear(self.list)
        if not store.alarms:
            e = label("Belum ada alarm. Klik “+ Alarm baru”.", ["sub"], xalign=0.5)
            e.set_margin_top(40)
            self.list.append(e)
        for a in sorted(store.alarms, key=lambda x: x["time"]):
            self.list.append(self._card(a, nxt))

    def _toggled(self, sw, _pspec, aid):
        a = self.ctx.store.get_alarm(aid)
        if a and sw.get_active() != bool(a["enabled"]):
            self.ctx.store.update_alarm(aid, enabled=sw.get_active())

    def _card(self, a, nxt):
        store = self.ctx.store
        now = datetime.now()
        row = hbox(16, ["row"])
        t = label(fmt_hhmm(a["time"], store.settings["clock24"]), ["alarm-time"])
        t.set_valign(Gtk.Align.CENTER)
        if not a.get("enabled"):
            t.add_css_class("muted")
        row.append(t)
        info = vbox(2)
        info.set_hexpand(True)
        info.set_valign(Gtk.Align.CENTER)
        info.append(label(a.get("label") or "Alarm", ["row-title"], ellipsize=True))
        meta = days_text(a.get("days", []))
        if a.get("enabled") and nxt and nxt[1]["id"] == a["id"]:
            meta += f" · berikutnya, {durasi((nxt[0] - now).total_seconds())} lagi"
        info.append(label(meta, ["tiny"], ellipsize=True))
        row.append(info)
        sw = Gtk.Switch()
        sw.set_valign(Gtk.Align.CENTER)
        sw.set_active(bool(a.get("enabled")))
        sw.connect("notify::active", self._toggled, a["id"])
        row.append(sw)
        row.append(button("Ubah", ["ghost"], lambda: AlarmDialog(self.ctx.window, store, a).present()))
        row.append(button("Hapus", ["ghost", "danger"],
                          lambda: confirm(self.ctx.window, f"Hapus alarm {a['time']}?", lambda: store.delete_alarm(a["id"]))))
        return row
