from datetime import datetime, timedelta

import gi
gi.require_version("Gtk", "4.0")
from gi.repository import Gtk

from .. import prayer, hijri, calendars, world
from ..util import tanggal_panjang, durasi
from .common import vbox, hbox, label, button, clear
from .page import Page


class PrayerPage(Page):
    def __init__(self, ctx):
        super().__init__(ctx, "Waktu Sholat", "")
        self.body.append(self.head)
        self.rows = {}
        self._lock = False

        top = vbox(4, ["card"])
        self.next_l = label("", ["sub"])
        self.next_name = label("", ["h1"])
        self.next_in = label("", ["h3", "accent"])
        for w in (self.next_l, self.next_name, self.next_in):
            top.append(w)
        self.hijri_l = label("", ["sub"])
        self.hijri_l.set_margin_top(6)
        top.append(self.hijri_l)
        self.body.append(top)

        self.list = vbox(8)
        for k, nama in zip(prayer.KEYS, prayer.NAMA):
            row = hbox(14, ["prayer-row"])
            n = label(nama, ["prayer-name"])
            n.set_hexpand(True)
            n.set_xalign(0)
            t = label("", ["prayer-time"])
            sw = Gtk.Switch()
            sw.set_valign(Gtk.Align.CENTER)
            sw.set_tooltip_text("Bunyikan notifikasi & adzan")
            sw.connect("notify::active", lambda s, _p, key=k: self._toggle(key, s.get_active()))
            row.append(n)
            row.append(t)
            row.append(sw)
            self.list.append(row)
            self.rows[k] = (row, t, sw)
        self.body.append(self.list)

        info = vbox(6, ["card"])
        self.sun_l = label("", ["sub"])
        info.append(self.sun_l)
        self.where_l = label("", ["tiny"], wrap=True)
        info.append(self.where_l)
        info.append(button("Tes notifikasi & adzan", [], self._test))
        self.body.append(info)
        self.refresh()

    def _toggle(self, key, on):
        if self._lock:
            return
        cur = dict(self.ctx.store.settings.get("prayer_on", {}))
        cur[key] = on
        self.ctx.store.set_setting("prayer_on", cur)

    def _test(self):
        k, when, cn = self.ctx.engine.next_prayer()
        self.ctx.engine.fire_prayer(k or "dzuhur", when or cn, test=True)

    def refresh(self):
        st = self.ctx.store.settings
        eng = self.ctx.engine
        lok = eng.lokasi()
        now = datetime.now()
        k, when, cn = eng.next_prayer(now)
        times = eng.prayer_times(cn.date())
        negara = world.NEGARA.get(lok.negara, lok.negara)
        beda = abs(cn - now) > timedelta(minutes=1)
        self.sub.set_text(f"{tanggal_panjang(cn.date())} · {lok.nama}, {negara}" + (f" · waktu setempat {cn:%H:%M}" if beda else ""))
        self.hijri_l.set_text(hijri.teks(hijri.dari_masehi(cn.date(), st.get("hijri_koreksi", 0))))
        if k:
            nama = prayer.NAMA[prayer.KEYS.index(k)]
            self.next_l.set_text("Sholat berikutnya" + (" (waktu setempat)" if beda else ""))
            self.next_name.set_text(f"{nama} · {when:%H:%M}")
            self.next_in.set_text(f"{durasi((when - cn).total_seconds())} lagi")
        else:
            self.next_l.set_text("Sholat berikutnya")
            self.next_name.set_text("—")
            self.next_in.set_text("waktu tidak terdefinisi di lokasi ini")
        on = st.get("prayer_on", {})
        self._lock = True
        for key, (row, t, sw) in self.rows.items():
            w = times.get(key)
            t.set_text(f"{w:%H:%M}" if w else "—")
            row.remove_css_class("prayer-next")
            row.remove_css_class("prayer-past")
            if key == k and when and when.date() == cn.date():
                row.add_css_class("prayer-next")
            elif w and w < cn:
                row.add_css_class("prayer-past")
            sw.set_active(bool(on.get(key, True)))
        self._lock = False
        if "terbit" in times:
            self.sun_l.set_text(f"Terbit {times['terbit']:%H:%M} · Subuh berakhir saat matahari terbit")
        else:
            self.sun_l.set_text("Matahari tidak terbit/terbenam normal di lokasi ini hari ini.")
        status = "aktif" if st.get("prayer", True) else "dimatikan (Pengaturan → Sholat)"
        mode = {"adzan": "adzan", "chime": "bunyi lonceng", "senyap": "senyap"}.get(st.get("adzan_mode"), "adzan")
        self.where_l.set_text(f"Notifikasi sholat {status} · suara: {mode}. Metode: {lok.metode[0]}"
                              f"{' · Ashar Hanafi' if st.get('asr_hanafi') else ''}. Zona waktu {lok.tz}. "
                              "Ganti negara/kota di Pengaturan. Selisih dengan jadwal resmi setempat bisa 1–3 menit.")
