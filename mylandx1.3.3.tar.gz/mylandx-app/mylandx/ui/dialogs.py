"""Dialog: tugas, alarm, alarm berbunyi, konfirmasi."""
from datetime import datetime, date, timedelta

import gi
gi.require_version("Gtk", "4.0")
gi.require_version("Gdk", "4.0")
from gi.repository import Gtk, Gdk, GLib

from .common import vbox, hbox, label, button, pad, clear, Chips, TimePicker, DatePicker
from ..util import HARI_S, parse_dt, days_text

REMIND = [("Tanpa pengingat", -1), ("Tepat waktu", 0), ("10 menit sebelumnya", 10),
          ("30 menit sebelumnya", 30), ("1 jam sebelumnya", 60), ("1 hari sebelumnya", 1440)]


class Modal(Gtk.Window):
    def __init__(self, parent, title, width=440):
        super().__init__()
        self.add_css_class("dialog-win")
        self.set_title(title)
        if parent is not None:
            self.set_transient_for(parent)
            self.set_modal(True)
        self.set_default_size(width, -1)
        self.set_resizable(False)
        self.body = vbox(14)
        pad(self.body, 22)
        self.set_child(self.body)
        key = Gtk.EventControllerKey()
        key.connect("key-pressed", self._key)
        self.add_controller(key)

    def _key(self, ctl, keyval, keycode, state):
        if keyval == Gdk.KEY_Escape:
            self.close()
            return True
        return False

    def field(self, title, widget):
        box = vbox(6)
        box.append(label(title, ["tiny"]))
        box.append(widget)
        self.body.append(box)
        return box

    def footer(self, save_text="Simpan", on_save=None, extra=None):
        row = hbox(8)
        row.set_margin_top(6)
        spacer = Gtk.Box()
        spacer.set_hexpand(True)
        if extra is not None:
            row.append(extra)
        row.append(spacer)
        row.append(button("Batal", ["ghost"], self.close))
        save = button(save_text, ["primary"], on_save)
        row.append(save)
        self.body.append(row)
        return save


def confirm(parent, message, on_yes, yes_label="Hapus"):
    d = Modal(parent, "Konfirmasi", 360)
    d.body.append(label(message, ["h2"], wrap=True))

    def yes():
        d.close()
        on_yes()
    d.footer(yes_label, yes)
    d.present()


class TaskDialog(Modal):
    def __init__(self, parent, store, task=None, preset_date=None, title=""):
        super().__init__(parent, "Ubah tugas" if task else "Tugas baru", 460)
        self.store, self.task = store, task
        self.title_e = Gtk.Entry(placeholder_text="Misal: Kerjakan laporan Basis Data 2")
        self.title_e.set_text(task["title"] if task else title)
        self.title_e.connect("activate", lambda *_: self.save())
        self.field("Judul", self.title_e)
        self.note_e = Gtk.Entry(placeholder_text="Catatan (opsional)")
        self.note_e.set_text(task.get("note", "") if task else "")
        self.field("Catatan", self.note_e)

        due = parse_dt(task["due"]) if task else None
        if not task and preset_date:
            hour = min(23, datetime.now().hour + 1) if preset_date == date.today() else 9
            due = datetime.combine(preset_date, datetime.min.time()).replace(hour=hour)
        has_due = bool(due)
        due = due or (datetime.now() + timedelta(hours=1)).replace(minute=0, second=0, microsecond=0)

        row = hbox(10)
        self.due_sw = Gtk.Switch()
        self.due_sw.set_valign(Gtk.Align.CENTER)
        self.due_sw.set_active(has_due)
        self.due_date = DatePicker(due.date())
        self.due_time = TimePicker(due.strftime("%H:%M"))
        row.append(self.due_sw)
        row.append(label("Tenggat", ["h3"]))
        sp = Gtk.Box()
        sp.set_hexpand(True)
        row.append(sp)
        row.append(self.due_date)
        row.append(self.due_time)
        self.body.append(row)

        self.prio = Chips(["Rendah", "Sedang", "Tinggi"], task.get("priority", 1) if task else 1)
        self.field("Prioritas", self.prio)

        self.remind = Gtk.DropDown.new_from_strings([r[0] for r in REMIND])
        cur = task.get("remind", -1) if task else (2 if has_due else -1)
        self.remind.set_selected(next((i for i, r in enumerate(REMIND) if r[1] == cur), 0))
        self.field("Pengingat", self.remind)

        self.due_sw.connect("notify::active", lambda *_: self._sync())
        self._sync()
        self.footer("Simpan", self.save)
        self.title_e.grab_focus()

    def _sync(self):
        on = self.due_sw.get_active()
        self.due_date.set_sensitive(on)
        self.due_time.set_sensitive(on)
        self.remind.set_sensitive(on)

    def save(self):
        title = self.title_e.get_text().strip()
        if not title:
            self.title_e.add_css_class("danger-text")
            self.title_e.grab_focus()
            return
        due = None
        remind = -1
        if self.due_sw.get_active():
            hh, mm = (int(x) for x in self.due_time.get().split(":"))
            due = datetime.combine(self.due_date.get(), datetime.min.time()).replace(hour=hh, minute=mm).isoformat()
            remind = REMIND[self.remind.get_selected()][1]
        data = dict(title=title, note=self.note_e.get_text().strip(), due=due,
                    priority=self.prio.index, remind=remind)
        if self.task:
            self.store.update_task(self.task["id"], **data)
        else:
            self.store.add_task(**data)
        self.close()


class AlarmDialog(Modal):
    def __init__(self, parent, store, alarm=None):
        super().__init__(parent, "Ubah alarm" if alarm else "Alarm baru", 440)
        self.store, self.alarm = store, alarm
        self.time = TimePicker(alarm["time"] if alarm else (datetime.now() + timedelta(minutes=1)).strftime("%H:%M"), big=True)
        self.time.set_halign(Gtk.Align.CENTER)
        self.body.append(self.time)
        self.label_e = Gtk.Entry(placeholder_text="Misal: Bangun pagi / Kuliah Basis Data")
        self.label_e.set_text(alarm.get("label", "") if alarm else "")
        self.field("Nama alarm", self.label_e)

        days = set(alarm.get("days", [])) if alarm else set()
        self.day_btns = []
        drow = hbox(6)
        drow.set_homogeneous(True)
        for i, n in enumerate(HARI_S):
            b = Gtk.ToggleButton(label=n)
            b.add_css_class("day")
            b.set_active(i in days)
            drow.append(b)
            self.day_btns.append(b)
        self.field("Ulangi (kosongkan = sekali saja)", drow)

        presets = hbox(6)
        for text, ds in (("Sekali", []), ("Hari kerja", [0, 1, 2, 3, 4]), ("Akhir pekan", [5, 6]), ("Tiap hari", list(range(7)))):
            presets.append(button(text, ["ghost"], lambda ds=ds: self._preset(ds)))
        self.body.append(presets)
        self.footer("Simpan", self.save)

    def _preset(self, ds):
        for i, b in enumerate(self.day_btns):
            b.set_active(i in ds)

    def save(self):
        days = [i for i, b in enumerate(self.day_btns) if b.get_active()]
        data = dict(time=self.time.get(), label=self.label_e.get_text().strip(), days=days, enabled=True, last_fired="")
        if self.alarm:
            self.store.update_alarm(self.alarm["id"], **data)
        else:
            self.store.add_alarm(**data)
        self.close()


class RingDialog(Modal):
    """Jendela saat alarm berbunyi."""

    def __init__(self, ctx, alarm):
        super().__init__(None, "Alarm", 400)
        self.ctx, self.alarm = ctx, alarm
        self._stopped = False
        self.body.set_halign(Gtk.Align.FILL)
        t = label(alarm["time"], ["digital"], xalign=0.5)
        self.body.append(t)
        self.body.append(label(alarm.get("label") or "Alarm", ["h1"], xalign=0.5, wrap=True))
        self.body.append(label(days_text(alarm.get("days", [])), ["sub"], xalign=0.5))
        row = hbox(10)
        row.set_homogeneous(True)
        row.set_margin_top(10)
        row.append(button("Tunda 5 menit", [], self.snooze))
        row.append(button("Matikan", ["primary"], self.stop))
        self.body.append(row)
        self.connect("close-request", self._on_close)
        if getattr(ctx, "player", None):
            ctx.player.hold()
        ctx.sound.start_loop()
        self._auto = GLib.timeout_add_seconds(300, self._auto_close)  # berhenti sendiri setelah 5 menit

    def _auto_close(self):
        self._auto = 0
        self.close()
        return False

    def _release(self):
        if not self._stopped:
            self._stopped = True
            self.ctx.sound.stop_loop()
            if getattr(self.ctx, "player", None):
                self.ctx.player.release()

    def _on_close(self, *_):
        if self._auto:
            GLib.source_remove(self._auto)
            self._auto = 0
        self._release()
        return False

    def stop(self):
        self.close()

    def snooze(self):
        self.ctx.engine.snooze(self.alarm, 5)
        self.close()


class TextPrompt(Modal):
    """Dialog kecil: satu isian teks (nama album, dll.)."""

    def __init__(self, parent, title, prompt, initial, on_ok, ok_text="Simpan"):
        super().__init__(parent, title, 380)
        self.on_ok = on_ok
        self.entry = Gtk.Entry(placeholder_text=prompt)
        self.entry.set_text(initial)
        self.entry.connect("activate", lambda *_: self._ok())
        self.field(prompt, self.entry)
        self.footer(ok_text, self._ok)
        self.entry.grab_focus()

    def _ok(self):
        text = self.entry.get_text().strip()
        if text:
            self.close()
            self.on_ok(text)


class AlbumPickDialog(Modal):
    """Centang album mana saja yang berisi lagu ini, atau buat album baru."""

    def __init__(self, parent, store, track):
        super().__init__(parent, "Masukkan ke album", 400)
        self.store, self.track = store, track
        self.body.append(label(track["title"], ["h3"], ellipsize=True))
        self.box = vbox(6)
        self.body.append(self.box)
        row = hbox(8)
        self.entry = Gtk.Entry(placeholder_text="Nama album baru")
        self.entry.set_hexpand(True)
        self.entry.connect("activate", lambda *_: self._create())
        row.append(self.entry)
        row.append(button("Buat", ["primary"], self._create))
        self.body.append(row)
        done = hbox(0)
        done.set_halign(Gtk.Align.END)
        done.append(button("Selesai", [], self.close))
        self.body.append(done)
        self._build()

    def _build(self):
        clear(self.box)
        if not self.store.albums:
            self.box.append(label("Belum ada album. Buat yang pertama di bawah.", ["sub"], wrap=True))
        for a in self.store.albums:
            cb = Gtk.CheckButton(label=a["name"])
            cb.set_active(self.track["id"] in a["tracks"])
            cb.connect("toggled", self._toggled, a["id"])
            self.box.append(cb)

    def _toggled(self, cb, aid):
        if cb.get_active():
            self.store.album_add(aid, [self.track["id"]])
        else:
            self.store.album_remove(aid, self.track["id"])

    def _create(self):
        name = self.entry.get_text().strip()
        if not name:
            return
        al = self.store.add_album(name)
        self.store.album_add(al["id"], [self.track["id"]])
        self.entry.set_text("")
        self._build()


class PrayerDialog(Modal):
    """Muncul saat waktu sholat tiba (adzan diputar jika ada file)."""

    def __init__(self, ctx, key, when):
        from .. import prayer
        nama = prayer.NAMA[prayer.KEYS.index(key)]
        super().__init__(None, "Waktu sholat", 380)
        self.ctx = ctx
        self._released = False
        self.body.set_halign(Gtk.Align.FILL)
        self.body.append(label("Waktu sholat", ["sub"], xalign=0.5))
        self.body.append(label(nama, ["digital"], xalign=0.5))
        kota = ctx.store.settings.get("kota", "Jakarta")
        self.body.append(label(f"{when:%H:%M} · {kota}", ["sub"], xalign=0.5))
        self.body.append(label("Yuk, tunaikan sholat. Semoga dimudahkan.", ["sub"], xalign=0.5, wrap=True))
        row = hbox(10)
        row.set_margin_top(10)
        row.set_homogeneous(True)
        row.append(button("Hentikan adzan", [], self._stop_sound))
        row.append(button("Tutup", ["primary"], self.close))
        self.body.append(row)
        if getattr(ctx, "player", None):
            ctx.player.hold()
        self.connect("close-request", self._on_close)
        self._auto = GLib.timeout_add_seconds(600, self._auto_close)

    def _auto_close(self):
        self._auto = 0
        self.close()
        return False

    def _stop_sound(self):
        self.ctx.sound.stop_file()

    def _on_close(self, *_):
        if self._auto:
            GLib.source_remove(self._auto)
            self._auto = 0
        if not self._released:
            self._released = True
            self.ctx.sound.stop_file()
            if getattr(self.ctx, "player", None):
                self.ctx.player.release()
        return False
