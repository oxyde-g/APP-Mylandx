"""Semua gambar kustom (Cairo): ikon, logo, jam analog, ring timer, grafik, kalender.
Fungsi murni: menerima konteks cairo + ukuran, jadi bisa dites tanpa GTK."""
import colorsys
import math
from datetime import datetime, date

import cairo

from .theme import THEME
from . import calendars, hijri
from .util import HARI_S, month_grid

TAU = math.pi * 2


def col(cr, key, alpha=1.0):
    if key == "white":
        cr.set_source_rgba(1, 1, 1, alpha)
    else:
        cr.set_source_rgba(*THEME.rgba(key, alpha))


def rrect(cr, x, y, w, h, r):
    r = max(0.0, min(r, w / 2, h / 2))
    cr.new_sub_path()
    cr.arc(x + w - r, y + r, r, -math.pi / 2, 0)
    cr.arc(x + w - r, y + h - r, r, 0, math.pi / 2)
    cr.arc(x + r, y + h - r, r, math.pi / 2, math.pi)
    cr.arc(x + r, y + r, r, math.pi, 1.5 * math.pi)
    cr.close_path()


def text(cr, s, x, y, size, key="text", alpha=1.0, bold=False, align="left", valign="middle"):
    """Gambar teks. y = titik tengah vertikal (valign=middle) atau baseline."""
    cr.select_font_face("Sans", cairo.FONT_SLANT_NORMAL,
                        cairo.FONT_WEIGHT_BOLD if bold else cairo.FONT_WEIGHT_NORMAL)
    cr.set_font_size(size)
    ext = cr.text_extents(s)
    fe = cr.font_extents()
    if align == "center":
        x -= ext.x_advance / 2
    elif align == "right":
        x -= ext.x_advance
    base = y + (fe[0] - fe[1]) / 2 if valign == "middle" else y
    col(cr, key, alpha)
    cr.move_to(x, base)
    cr.show_text(s)


def _crescent(cr, x1, y1, r1, x2, y2, r2, n=40):
    """Jalur bulan sabit = lingkaran 1 dikurangi lingkaran 2 (hanya line_to, tanpa arc terbalik)."""
    dx, dy = x2 - x1, y2 - y1
    d = math.hypot(dx, dy)
    a = (r1 * r1 - r2 * r2 + d * d) / (2 * d)
    h = math.sqrt(max(0.0, r1 * r1 - a * a))
    base = math.atan2(dy, dx)
    t = math.atan2(h, a)                 # sudut titik potong dari arah pusat-2 (lingkaran 1)
    u = math.atan2(h, d - a)             # sudut titik potong dari arah pusat-1 (lingkaran 2)
    pts = []
    for i in range(n + 1):               # busur luar lingkaran 1, sisi yang menjauhi pusat-2
        th = base + t + (TAU - 2 * t) * i / n
        pts.append((x1 + r1 * math.cos(th), y1 + r1 * math.sin(th)))
    for i in range(n + 1):               # busur dalam: bagian lingkaran 2 yang berada di dalam lingkaran 1
        th = base + math.pi + u - 2 * u * i / n
        pts.append((x2 + r2 * math.cos(th), y2 + r2 * math.sin(th)))
    cr.move_to(*pts[0])
    for p in pts[1:]:
        cr.line_to(*p)
    cr.close_path()


# ------------------------------------------------------------------ ikon (grid 24x24)
def draw_icon(cr, name, x, y, size, rgba):
    cr.save()
    cr.translate(x, y)
    cr.scale(size / 24.0, size / 24.0)
    cr.set_source_rgba(*rgba)
    cr.set_line_width(1.9)
    cr.set_line_cap(cairo.LINE_CAP_ROUND)
    cr.set_line_join(cairo.LINE_JOIN_ROUND)
    if name == "home":
        cr.move_to(3, 11.5); cr.line_to(12, 3.5); cr.line_to(21, 11.5)
        cr.move_to(5.5, 10); cr.line_to(5.5, 20); cr.line_to(18.5, 20); cr.line_to(18.5, 10)
        cr.move_to(10, 20); cr.line_to(10, 14.5); cr.line_to(14, 14.5); cr.line_to(14, 20)
        cr.stroke()
    elif name == "tasks":
        rrect(cr, 4, 4, 16, 16, 4.5); cr.stroke()
        cr.move_to(8.3, 12.3); cr.line_to(11, 15); cr.line_to(16, 9.3); cr.stroke()
    elif name == "focus":
        cr.arc(12, 13.2, 7.6, 0, TAU); cr.stroke()
        cr.move_to(12, 13.2); cr.line_to(12, 8.8); cr.stroke()
        cr.move_to(9.5, 3.2); cr.line_to(14.5, 3.2); cr.stroke()
        cr.move_to(18.2, 6.2); cr.line_to(19.4, 5); cr.stroke()
    elif name == "alarm":
        cr.move_to(6, 17); cr.line_to(6, 11)
        cr.arc(12, 11, 6, math.pi, TAU)
        cr.line_to(18, 17); cr.stroke()
        cr.move_to(4.5, 17.2); cr.line_to(19.5, 17.2); cr.stroke()
        cr.move_to(10, 20.3); cr.line_to(14, 20.3); cr.stroke()
        cr.move_to(12, 3.6); cr.line_to(12, 5); cr.stroke()
    elif name == "calendar":
        rrect(cr, 4, 5.5, 16, 14.5, 3.5); cr.stroke()
        cr.move_to(4, 10.3); cr.line_to(20, 10.3); cr.stroke()
        cr.move_to(8.5, 3.3); cr.line_to(8.5, 7.3); cr.stroke()
        cr.move_to(15.5, 3.3); cr.line_to(15.5, 7.3); cr.stroke()
    elif name == "settings":
        for yy, kx in ((7, 15.5), (12, 8.5), (17, 14)):
            cr.move_to(4, yy); cr.line_to(20, yy); cr.stroke()
            cr.arc(kx, yy, 2.3, 0, TAU)
            cr.set_source_rgba(*THEME.rgba("side"))
            cr.fill_preserve()
            cr.set_source_rgba(*rgba)
            cr.stroke()
    elif name == "notes":
        rrect(cr, 5, 3.5, 14, 17, 3.5); cr.stroke()
        for yy, x2 in ((9, 15), (13, 15), (17, 11.5)):
            cr.move_to(8.5, yy); cr.line_to(x2, yy); cr.stroke()
    elif name == "music":
        cr.arc(7.5, 17.5, 3, 0, TAU); cr.stroke()
        cr.arc(16.5, 15.5, 3, 0, TAU); cr.stroke()
        cr.move_to(10.5, 17.5); cr.line_to(10.5, 6); cr.line_to(19.5, 4); cr.line_to(19.5, 15.5); cr.stroke()
    elif name == "play":
        cr.move_to(8, 5); cr.line_to(19, 12); cr.line_to(8, 19); cr.close_path(); cr.fill()
    elif name == "pause":
        rrect(cr, 6.5, 5, 4, 14, 1.5); cr.fill()
        rrect(cr, 13.5, 5, 4, 14, 1.5); cr.fill()
    elif name == "next":
        cr.move_to(6, 6); cr.line_to(16, 12); cr.line_to(6, 18); cr.close_path(); cr.fill()
        rrect(cr, 17, 6, 2.6, 12, 1.2); cr.fill()
    elif name == "prev":
        cr.move_to(18, 6); cr.line_to(8, 12); cr.line_to(18, 18); cr.close_path(); cr.fill()
        rrect(cr, 4.4, 6, 2.6, 12, 1.2); cr.fill()
    elif name in ("heart", "heart_fill"):
        cr.move_to(12, 20)
        cr.curve_to(5, 15, 3, 11, 3, 8.5)
        cr.curve_to(3, 5.8, 5.2, 4, 7.5, 4)
        cr.curve_to(9.4, 4, 11, 5, 12, 6.7)
        cr.curve_to(13, 5, 14.6, 4, 16.5, 4)
        cr.curve_to(18.8, 4, 21, 5.8, 21, 8.5)
        cr.curve_to(21, 11, 19, 15, 12, 20)
        cr.close_path()
        cr.fill() if name == "heart_fill" else cr.stroke()
    elif name == "shuffle":
        cr.move_to(4, 7); cr.line_to(9, 7); cr.line_to(15, 17); cr.line_to(19, 17); cr.stroke()
        cr.move_to(4, 17); cr.line_to(9, 17); cr.line_to(15, 7); cr.line_to(19, 7); cr.stroke()
        cr.move_to(17, 4.8); cr.line_to(20, 7); cr.line_to(17, 9.2); cr.stroke()
        cr.move_to(17, 14.8); cr.line_to(20, 17); cr.line_to(17, 19.2); cr.stroke()
    elif name == "repeat":
        rrect(cr, 4, 7, 16, 10.5, 5); cr.stroke()
        cr.move_to(16.5, 3.8); cr.line_to(19.5, 7); cr.line_to(16.5, 10.2); cr.stroke()
    elif name == "close":
        cr.move_to(6.5, 6.5); cr.line_to(17.5, 17.5); cr.stroke()
        cr.move_to(17.5, 6.5); cr.line_to(6.5, 17.5); cr.stroke()
    elif name == "prayer":   # bulan sabit + bintang kecil
        _crescent(cr, 11, 12.5, 7.6, 14.6, 10.4, 6.2)
        cr.stroke()
        cr.move_to(18.6, 3.8); cr.line_to(18.6, 8.0); cr.move_to(16.5, 5.9); cr.line_to(20.7, 5.9); cr.stroke()
    elif name == "clock":
        cr.arc(12, 12, 8.5, 0, TAU); cr.stroke()
        cr.move_to(12, 7); cr.line_to(12, 12); cr.line_to(15.5, 14); cr.stroke()
    cr.restore()


def draw_logo(cr, x, y, size):
    """Logo: kotak membulat gradasi aksen + jam dengan centang."""
    cr.save()
    cr.translate(x, y)
    s = size / 100.0
    cr.scale(s, s)
    g = cairo.LinearGradient(0, 0, 100, 100)
    r, gg, b, _ = THEME.rgba("accent")
    g.add_color_stop_rgb(0, min(1, r + 0.18), min(1, gg + 0.18), min(1, b + 0.18))
    g.add_color_stop_rgb(1, r * 0.72, gg * 0.72, b * 0.9)
    cr.set_source(g)
    rrect(cr, 0, 0, 100, 100, 28)
    cr.fill()
    cr.set_source_rgba(1, 1, 1, 1)
    cr.set_line_width(8)
    cr.set_line_cap(cairo.LINE_CAP_ROUND)
    cr.set_line_join(cairo.LINE_JOIN_ROUND)
    cr.arc(50, 52, 28, 0, TAU)
    cr.stroke()
    cr.move_to(38, 52); cr.line_to(47, 61); cr.line_to(64, 41)
    cr.stroke()
    cr.move_to(42, 15); cr.line_to(58, 15)
    cr.stroke()
    cr.restore()


# ------------------------------------------------------------------ jam analog
def draw_analog_clock(cr, w, h, now=None):
    now = now or datetime.now()
    cx, cy = w / 2, h / 2
    R = min(w, h) / 2 - 4
    cr.arc(cx, cy, R, 0, TAU)
    col(cr, "surface2"); cr.fill_preserve()
    col(cr, "border"); cr.set_line_width(2); cr.stroke()
    cr.set_line_cap(cairo.LINE_CAP_ROUND)
    for i in range(60):
        a = i * TAU / 60 - math.pi / 2
        big = i % 5 == 0
        r1 = R - (14 if big else 8)
        r2 = R - 5
        cr.move_to(cx + r1 * math.cos(a), cy + r1 * math.sin(a))
        cr.line_to(cx + r2 * math.cos(a), cy + r2 * math.sin(a))
        cr.set_line_width(2.4 if big else 1)
        col(cr, "text" if big else "muted", 0.9 if big else 0.5)
        cr.stroke()

    def hand(angle, length, width, key, alpha=1.0, tail=0.0):
        a = angle - math.pi / 2
        cr.move_to(cx - tail * math.cos(a), cy - tail * math.sin(a))
        cr.line_to(cx + length * math.cos(a), cy + length * math.sin(a))
        cr.set_line_width(width)
        col(cr, key, alpha)
        cr.stroke()

    sec = now.second + now.microsecond / 1e6
    hand(((now.hour % 12) + now.minute / 60) * TAU / 12, R * 0.5, 5.5, "text")
    hand((now.minute + sec / 60) * TAU / 60, R * 0.74, 3.8, "text")
    hand(sec * TAU / 60, R * 0.82, 1.8, "accent", tail=R * 0.14)
    cr.arc(cx, cy, 6, 0, TAU)
    col(cr, "accent"); cr.fill()
    cr.arc(cx, cy, 2.4, 0, TAU)
    col(cr, "surface2"); cr.fill()


# ------------------------------------------------------------------ ring timer
def draw_ring(cr, w, h, progress, main, sub, key="accent"):
    cx, cy = w / 2, h / 2
    th = 16
    R = min(w, h) / 2 - th
    cr.set_line_cap(cairo.LINE_CAP_ROUND)
    cr.set_line_width(th)
    cr.arc(cx, cy, R, 0, TAU)
    col(cr, "surface2"); cr.stroke()
    progress = max(0.0, min(1.0, progress))
    if progress > 0.002:
        cr.set_line_width(th)
        cr.arc(cx, cy, R, -math.pi / 2, -math.pi / 2 + TAU * progress)
        col(cr, key); cr.stroke()
    text(cr, main, cx, cy - R * 0.06, R * 0.44, "text", bold=True, align="center")
    text(cr, sub, cx, cy + R * 0.36, max(12, R * 0.12), "muted", align="center")


# ------------------------------------------------------------------ grafik batang
def draw_bars(cr, w, h, items):
    """items: [(label, nilai, apakah_hari_ini)]"""
    n = len(items)
    if not n:
        return
    top, bottom = 22, 24
    ch = h - top - bottom
    mx = max(60, max(v for _, v, _ in items))
    slot = w / n
    bw = min(34, slot * 0.55)
    for i, (label, v, today) in enumerate(items):
        x = i * slot + (slot - bw) / 2
        bh = max(5.0, ch * v / mx) if v > 0 else 5.0
        y = top + ch - bh
        rrect(cr, x, y, bw, bh, min(9, bw / 2))
        if v > 0:
            col(cr, "accent", 1.0 if today else 0.5)
        else:
            col(cr, "surface2")
        cr.fill()
        if v > 0:
            text(cr, str(v), x + bw / 2, y - 9, 11, "text", align="center")
        text(cr, label, x + bw / 2, h - 9, 11, "accent" if today else "muted", bold=today, align="center")


# ------------------------------------------------------------------ kalender
HEADER_H = 30


def calendar_cells(w, h, year, month):
    """[(date, x, y, cw, ch)] untuk 42 sel."""
    cw = w / 7.0
    ch = (h - HEADER_H) / 6.0
    cells = []
    for i, d in enumerate(month_grid(year, month)):
        cells.append((d, (i % 7) * cw, HEADER_H + (i // 7) * ch, cw, ch))
    return cells


def calendar_hit(w, h, year, month, x, y):
    if y < HEADER_H or x < 0 or x >= w or y >= h:
        return None
    for d, cx, cy, cw, ch in calendar_cells(w, h, year, month):
        if cx <= x < cx + cw and cy <= y < cy + ch:
            return d
    return None


MARK_KEY = {"libur": "danger", "cuti": "warn", "event": "accent"}


def draw_calendar(cr, w, h, year, month, selected, hover, marks, today=None, koreksi=0):
    """marks: {date: (total, selesai)}. Angka kecil = tanggal Hijriyah; titik kanan-atas = ada peristiwa."""
    today = today or date.today()
    cw = w / 7.0
    for i, name in enumerate(HARI_S):
        text(cr, name, i * cw + cw / 2, HEADER_H / 2, 12, "danger" if i == 6 else "muted", bold=True, align="center")
    for d, x, y, cw, ch in calendar_cells(w, h, year, month):
        inm = d.month == month
        pad = 3
        bx, by, bw, bh = x + pad, y + pad, cw - pad * 2, ch - pad * 2
        if d == selected:
            rrect(cr, bx, by, bw, bh, 14)
            col(cr, "accent", 0.14); cr.fill_preserve()
            col(cr, "accent", 0.9); cr.set_line_width(1.6); cr.stroke()
        elif d == hover:
            rrect(cr, bx, by, bw, bh, 14)
            col(cr, "surface2"); cr.fill()
        merah = calendars.is_libur(d)
        red = d.weekday() == 6 or merah
        alpha = 1.0 if inm else 0.32
        big = ch > 44
        cxn, cyn = x + cw / 2, y + ch / 2 - (7 if big else 0)
        if d == today:
            cr.arc(cxn, cyn, min(15, ch / 3.1), 0, TAU)
            col(cr, "accent"); cr.fill()
            text(cr, str(d.day), cxn, cyn, 14, "white", bold=True, align="center")
        else:
            text(cr, str(d.day), cxn, cyn, 14, "danger" if red else "text", alpha, bold=merah and inm, align="center")
        if big:
            hy, hm, hd = hijri.dari_masehi(d, koreksi)
            label = hijri.BULAN[hm - 1][:3] if hd == 1 else str(hd)
            text(cr, label, cxn, cyn + 15, 9.5, "muted", alpha * (0.95 if hd == 1 else 0.8), bold=hd == 1, align="center")
        mk = calendars.ada_penanda(d, koreksi)
        if mk:
            cr.arc(x + cw - 11, y + 11, 3.2, 0, TAU)
            col(cr, MARK_KEY[mk], alpha); cr.fill()
        tot, dn = marks.get(d, (0, 0))
        if tot and big:
            k = min(3, tot)
            for j in range(k):
                px = cxn + (j - (k - 1) / 2) * 9
                cr.arc(px, cyn + 28, 3, 0, TAU)
                if dn >= tot:
                    col(cr, "ok", alpha)
                else:
                    col(cr, "accent", alpha)
                cr.fill()


def draw_traffic(cr, w, h, hover=False, active=True, maxed=False):
    """Tiga tombol bulat ala macOS: merah (tutup), kuning (minimize), hijau (perbesar)."""
    r, gap = 6.5, 8
    colors = [(1.0, 0.373, 0.341), (0.996, 0.737, 0.18), (0.157, 0.788, 0.255)]
    edges = [(0.88, 0.26, 0.23), (0.87, 0.62, 0.08), (0.10, 0.65, 0.17)]
    cy = h / 2
    for i in range(3):
        cx = r + 1 + i * (2 * r + gap)
        cr.arc(cx, cy, r, 0, TAU)
        if active or hover:
            cr.set_source_rgb(*colors[i])
            cr.fill_preserve()
            cr.set_source_rgba(*edges[i], 0.9)
            cr.set_line_width(0.8)
            cr.stroke()
        else:
            col(cr, "border")
            cr.fill()
        if hover:
            cr.set_source_rgba(0, 0, 0, 0.58)
            cr.set_line_width(1.4)
            cr.set_line_cap(cairo.LINE_CAP_ROUND)
            if i == 0:
                cr.move_to(cx - 2.4, cy - 2.4); cr.line_to(cx + 2.4, cy + 2.4)
                cr.move_to(cx + 2.4, cy - 2.4); cr.line_to(cx - 2.4, cy + 2.4); cr.stroke()
            elif i == 1:
                cr.move_to(cx - 2.8, cy); cr.line_to(cx + 2.8, cy); cr.stroke()
            else:
                if maxed:   # dua segitiga menghadap ke dalam
                    cr.move_to(cx - 3.0, cy + 0.9); cr.line_to(cx - 0.9, cy + 0.9); cr.line_to(cx - 0.9, cy + 3.0); cr.close_path()
                    cr.move_to(cx + 3.0, cy - 0.9); cr.line_to(cx + 0.9, cy - 0.9); cr.line_to(cx + 0.9, cy - 3.0); cr.close_path()
                else:       # dua segitiga menghadap ke luar
                    cr.move_to(cx - 3.2, cy + 3.2); cr.line_to(cx - 3.2, cy - 0.2); cr.line_to(cx + 0.2, cy + 3.2); cr.close_path()
                    cr.move_to(cx + 3.2, cy - 3.2); cr.line_to(cx + 3.2, cy + 0.2); cr.line_to(cx - 0.2, cy - 3.2); cr.close_path()
                cr.fill()


def traffic_hit(x, r=6.5, gap=8):
    """-> 0 tutup, 1 minimize, 2 perbesar, atau None."""
    for i in range(3):
        cx = r + 1 + i * (2 * r + gap)
        if abs(x - cx) <= r + gap / 2:
            return i
    return None


def cover_colors(seed):
    h = (sum(ord(c) * (i + 3) for i, c in enumerate(seed or "?")) % 360) / 360.0
    a = colorsys.hsv_to_rgb(h, 0.55, 0.95)
    b = colorsys.hsv_to_rgb((h + 0.08) % 1.0, 0.7, 0.62)
    return a, b


def draw_cover(cr, w, h, seed, letter):
    """Sampul sementara: gradasi warna unik per lagu + huruf awal (tanpa unduh gambar)."""
    a, b = cover_colors(seed)
    g = cairo.LinearGradient(0, 0, w, h)
    g.add_color_stop_rgb(0, *a)
    g.add_color_stop_rgb(1, *b)
    cr.set_source(g)
    rrect(cr, 0, 0, w, h, min(w, h) * 0.22)
    cr.fill()
    text(cr, (letter or "?")[:1].upper(), w / 2, h / 2, h * 0.46, "white", 0.95, bold=True, align="center")
