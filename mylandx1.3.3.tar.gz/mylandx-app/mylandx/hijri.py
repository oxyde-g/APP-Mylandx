"""Kalender Hijriyah: algoritma tabular (Kuwaiti) + penyesuaian ke penetapan resmi
pemerintah RI (jangkar awal bulan dari SKB libur nasional 2026-2027) + koreksi manual ±2 hari."""
from datetime import date, timedelta

BULAN = ["Muharram", "Safar", "Rabiul Awal", "Rabiul Akhir", "Jumadil Awal", "Jumadil Akhir",
         "Rajab", "Sya'ban", "Ramadan", "Syawal", "Dzulqa'dah", "Dzulhijjah"]

# Awal bulan (1 hari bulan) yang ditetapkan resmi, diturunkan dari tanggal libur di SKB 3 Menteri.
# (tahun_h, bulan_h): tanggal masehi
JANGKAR = {
    (1447, 7): date(2025, 12, 21),   # 27 Rajab = 16 Jan 2026 (Isra Mikraj)
    (1447, 10): date(2026, 3, 21),   # 1 Syawal (Idulfitri)
    (1447, 12): date(2026, 5, 18),   # 10 Dzulhijjah = 27 Mei (Iduladha)
    (1448, 1): date(2026, 6, 16),    # 1 Muharram
    (1448, 3): date(2026, 8, 14),    # 12 Rabiul Awal = 25 Agu (Maulid)
    (1448, 7): date(2026, 12, 10),   # 27 Rajab = 5 Jan 2027
    (1448, 10): date(2027, 3, 10),   # 1 Syawal (Idulfitri)
    (1448, 12): date(2027, 5, 8),    # 10 Dzulhijjah = 17 Mei (Iduladha)
    (1449, 1): date(2027, 6, 6),     # 1 Muharram
    (1449, 3): date(2027, 8, 4),     # 12 Rabiul Awal = 15 Agu (Maulid)
    (1449, 7): date(2027, 11, 30),   # 27 Rajab = 26 Des 2027
}


def _jdn(d):
    return d.toordinal() + 1721425


def _tabular(jdn):
    y = int((jdn - 1948440) / 354.36667) + 1
    while _start_tab(y + 1, 1) <= jdn:
        y += 1
    while _start_tab(y, 1) > jdn:
        y -= 1
    m = 12
    while _start_tab(y, m) > jdn:
        m -= 1
    return y, m, jdn - _start_tab(y, m) + 1


def _start_tab(y, m):
    """JDN tabular untuk 1 hari bulan (y, m)."""
    return 1 + -(-59 * (m - 1) // 2) + (y - 1) * 354 + (3 + 11 * y) // 30 + 1948440 - 1


def _idx(y, m):
    return y * 12 + (m - 1)


def _ym(idx):
    return idx // 12, idx % 12 + 1


_AIDX = sorted((_idx(y, m), _jdn(dt)) for (y, m), dt in JANGKAR.items())
_CACHE = {}


def _delta_for(idx):
    """selisih (anchor - tabular) dari jangkar terakhir sebelum/di bulan idx."""
    best = None
    for ai, aj in _AIDX:
        if ai <= idx:
            best = aj - _start_tab(*_ym(ai))
        else:
            break
    if best is None:
        ai, aj = _AIDX[0]
        best = aj - _start_tab(*_ym(ai))
    return best


def _build(lo, hi):
    """isi cache awal bulan untuk indeks bulan lo..hi di antara dua jangkar."""
    for ai, aj in _AIDX:
        _CACHE[ai] = aj
    # mundur dari tiap jangkar ke jangkar sebelumnya agar panjang bulan tetap 29/30
    for n in range(1, len(_AIDX)):
        a0, _ = _AIDX[n - 1]
        a1, j1 = _AIDX[n]
        s = j1
        fwd_delta = _delta_for(a0)
        for k in range(a1 - 1, a0, -1):
            fwd = _start_tab(*_ym(k)) + fwd_delta
            c30, c29 = s - 30, s - 29
            s = c30 if abs(c30 - fwd) <= abs(c29 - fwd) else c29
            _CACHE[k] = s


def _start(idx):
    if not _CACHE:
        _build(0, 0)
    if idx in _CACHE:
        return _CACHE[idx]
    return _start_tab(*_ym(idx)) + _delta_for(idx)


def dari_masehi(d, koreksi=0):
    """-> (tahun, bulan 1..12, hari) Hijriyah."""
    jdn = _jdn(d) - koreksi
    y, m, _ = _tabular(jdn - _delta_for(_idx(*_tabular(jdn)[:2])))
    idx = _idx(y, m)
    for k in (idx + 1, idx, idx - 1, idx - 2):
        st = _start(k)
        if st <= jdn:
            yy, mm = _ym(k)
            return yy, mm, jdn - st + 1
    yy, mm = _ym(idx - 2)
    return yy, mm, jdn - _start(idx - 2) + 1


def ke_masehi(y, m, hari, koreksi=0):
    return date.fromordinal(_start(_idx(y, m)) - 1721425 + hari - 1 + koreksi)


def teks(h):
    y, m, d = h
    return f"{d} {BULAN[m - 1]} {y} H"


def teks_pendek(h):
    return f"{h[2]} {BULAN[h[1] - 1]}"


# Peristiwa tetap dalam kalender Hijriyah: (bulan, hari) -> nama
PERISTIWA = {
    (1, 1): "Tahun Baru Islam",
    (1, 10): "Hari Asyura (puasa sunnah)",
    (3, 12): "Maulid Nabi Muhammad saw.",
    (7, 27): "Isra Mikraj Nabi Muhammad saw.",
    (8, 15): "Nisfu Sya'ban",
    (9, 1): "Awal Ramadan (mulai puasa)",
    (9, 17): "Nuzulul Qur'an",
    (10, 1): "Idulfitri",
    (10, 2): "Idulfitri (hari kedua)",
    (12, 8): "Hari Tarwiyah",
    (12, 9): "Hari Arafah (puasa sunnah)",
    (12, 10): "Iduladha",
    (12, 11): "Hari Tasyrik",
    (12, 12): "Hari Tasyrik",
    (12, 13): "Hari Tasyrik",
}
for _m in range(1, 13):
    for _d in (13, 14, 15):
        PERISTIWA.setdefault((_m, _d), "Ayyamul Bidh (puasa sunnah)")
PERISTIWA[(8, 15)] = "Nisfu Sya'ban · Ayyamul Bidh"
