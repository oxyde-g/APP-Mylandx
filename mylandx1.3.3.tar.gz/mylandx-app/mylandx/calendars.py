"""Kalender nasional (libur & cuti bersama resmi), hari besar nasional, hari internasional,
dan peristiwa Hijriyah, digabung jadi satu sumber untuk Beranda & Kalender.

Data resmi libur 2026 & 2027 diambil dari SKB 3 Menteri (setneg.go.id). Untuk tahun lain
libur dihitung/perkiraan (ditandai approx) -- Imlek/Nyepi/Waisak di luar 2026-2027 tidak tercakup
kecuali Imlek yang tabelnya tersedia."""
from datetime import date, timedelta

from . import hijri

LIBUR, CUTI, NASIONAL, INTL, HIJRI = "libur", "cuti", "nasional", "intl", "hijri"
JENIS_LABEL = {LIBUR: "Libur nasional", CUTI: "Cuti bersama", NASIONAL: "Hari nasional",
               INTL: "Hari internasional", HIJRI: "Hijriyah"}


def _ev(nama, jenis, minor=False, approx=False):
    return dict(nama=nama, jenis=jenis, minor=minor, approx=approx)


def _d(y, m, d):
    return date(y, m, d)


RESMI = {
    2026: {
        (1, 1): ("Tahun Baru 2026 Masehi", LIBUR),
        (1, 16): ("Isra Mikraj Nabi Muhammad saw.", LIBUR),
        (2, 16): ("Cuti Bersama Tahun Baru Imlek", CUTI),
        (2, 17): ("Tahun Baru Imlek 2577 Kongzili", LIBUR),
        (3, 18): ("Cuti Bersama Nyepi", CUTI),
        (3, 19): ("Hari Suci Nyepi (Saka 1948)", LIBUR),
        (3, 20): ("Cuti Bersama Idulfitri", CUTI),
        (3, 21): ("Idulfitri 1447 H", LIBUR),
        (3, 22): ("Idulfitri 1447 H", LIBUR),
        (3, 23): ("Cuti Bersama Idulfitri", CUTI),
        (3, 24): ("Cuti Bersama Idulfitri", CUTI),
        (4, 3): ("Wafat Yesus Kristus", LIBUR),
        (4, 5): ("Kebangkitan Yesus Kristus (Paskah)", LIBUR),
        (5, 1): ("Hari Buruh Internasional", LIBUR),
        (5, 14): ("Kenaikan Yesus Kristus", LIBUR),
        (5, 15): ("Cuti Bersama Kenaikan Yesus Kristus", CUTI),
        (5, 27): ("Iduladha 1447 H", LIBUR),
        (5, 28): ("Cuti Bersama Iduladha", CUTI),
        (5, 31): ("Hari Raya Waisak 2570 BE", LIBUR),
        (6, 1): ("Hari Lahir Pancasila", LIBUR),
        (6, 16): ("1 Muharam / Tahun Baru Islam 1448 H", LIBUR),
        (8, 17): ("Proklamasi Kemerdekaan RI", LIBUR),
        (8, 25): ("Maulid Nabi Muhammad saw.", LIBUR),
        (12, 24): ("Cuti Bersama Natal", CUTI),
        (12, 25): ("Kelahiran Yesus Kristus (Natal)", LIBUR),
    },
    2027: {
        (1, 1): ("Tahun Baru 2027 Masehi", LIBUR),
        (1, 5): ("Isra Mikraj Nabi Muhammad saw.", LIBUR),
        (2, 5): ("Cuti Bersama Tahun Baru Imlek", CUTI),
        (2, 6): ("Tahun Baru Imlek 2578 Kongzili", LIBUR),
        (3, 8): ("Hari Suci Nyepi (Saka 1949)", LIBUR),
        (3, 9): ("Cuti Bersama Idulfitri", CUTI),
        (3, 10): ("Idulfitri 1448 H", LIBUR),
        (3, 11): ("Idulfitri 1448 H", LIBUR),
        (3, 12): ("Cuti Bersama Idulfitri", CUTI),
        (3, 15): ("Cuti Bersama Idulfitri", CUTI),
        (3, 25): ("Cuti Bersama Wafat Yesus Kristus", CUTI),
        (3, 26): ("Wafat Yesus Kristus", LIBUR),
        (3, 28): ("Kebangkitan Yesus Kristus (Paskah)", LIBUR),
        (5, 1): ("Hari Buruh Internasional", LIBUR),
        (5, 6): ("Kenaikan Yesus Kristus", LIBUR),
        (5, 17): ("Iduladha 1448 H", LIBUR),
        (5, 18): ("Cuti Bersama Iduladha", CUTI),
        (5, 19): ("Cuti Bersama Waisak", CUTI),
        (5, 20): ("Hari Raya Waisak 2571 BE", LIBUR),
        (6, 1): ("Hari Lahir Pancasila", LIBUR),
        (6, 6): ("1 Muharam / Tahun Baru Islam 1449 H", LIBUR),
        (8, 15): ("Maulid Nabi Muhammad saw.", LIBUR),
        (8, 17): ("Proklamasi Kemerdekaan RI", LIBUR),
        (12, 24): ("Cuti Bersama Natal", CUTI),
        (12, 25): ("Kelahiran Yesus Kristus (Natal)", LIBUR),
        (12, 26): ("Isra Mikraj Nabi Muhammad saw.", LIBUR),
    },
}

IMLEK = {2024: (2, 10), 2025: (1, 29), 2026: (2, 17), 2027: (2, 6), 2028: (1, 26),
         2029: (2, 13), 2030: (2, 3)}

# Hari nasional (bukan libur) -- tanggal tetap
NASIONAL_TETAP = {
    (1, 25): "Hari Gizi dan Makanan",
    (2, 9): "Hari Pers Nasional",
    (3, 1): "Serangan Umum 1 Maret",
    (3, 9): "Hari Musik Nasional",
    (3, 11): "Hari Supersemar",
    (4, 21): "Hari Kartini",
    (5, 2): "Hari Pendidikan Nasional",
    (5, 20): "Hari Kebangkitan Nasional",
    (7, 23): "Hari Anak Nasional",
    (8, 14): "Hari Pramuka",
    (9, 9): "Hari Olahraga Nasional",
    (9, 11): "Hari Radio",
    (9, 24): "Hari Tani Nasional",
    (10, 1): "Hari Kesaktian Pancasila",
    (10, 2): "Hari Batik Nasional",
    (10, 5): "Hari TNI",
    (10, 28): "Hari Sumpah Pemuda",
    (11, 10): "Hari Pahlawan",
    (11, 12): "Hari Kesehatan Nasional",
    (11, 25): "Hari Guru Nasional",
    (12, 1): "Hari AIDS Sedunia (nasional)",
    (12, 22): "Hari Ibu",
}

INTL_TETAP = {
    (1, 1): "Tahun Baru Masehi (dunia)",
    (2, 4): "Hari Kanker Sedunia",
    (2, 14): "Hari Valentine",
    (3, 8): "Hari Perempuan Internasional",
    (3, 14): "Pi Day",
    (3, 22): "Hari Air Sedunia",
    (4, 1): "April Mop",
    (4, 7): "Hari Kesehatan Sedunia",
    (4, 22): "Hari Bumi",
    (4, 23): "Hari Buku Sedunia",
    (5, 3): "Hari Kebebasan Pers Sedunia",
    (5, 31): "Hari Tanpa Tembakau Sedunia",
    (6, 5): "Hari Lingkungan Hidup Sedunia",
    (6, 8): "Hari Laut Sedunia",
    (6, 21): "Hari Musik Sedunia",
    (7, 11): "Hari Populasi Dunia",
    (8, 12): "Hari Pemuda Internasional",
    (9, 8): "Hari Literasi Internasional",
    (9, 21): "Hari Perdamaian Internasional",
    (9, 27): "Hari Pariwisata Dunia",
    (10, 1): "Hari Lansia Internasional",
    (10, 5): "Hari Guru Sedunia",
    (10, 10): "Hari Kesehatan Mental Sedunia",
    (10, 16): "Hari Pangan Sedunia",
    (10, 24): "Hari PBB",
    (10, 31): "Halloween",
    (11, 14): "Hari Diabetes Sedunia",
    (11, 20): "Hari Anak Sedunia",
    (12, 1): "Hari AIDS Sedunia",
    (12, 10): "Hari HAM Sedunia",
    (12, 31): "Malam Tahun Baru",
}

# peristiwa Hijriyah yang sudah jadi libur resmi (supaya tidak ditulis dua kali)
_HIJRI_LIBUR_KEYS = {(1, 1), (3, 12), (7, 27), (10, 1), (10, 2), (12, 10)}
# hari "kecil": tetap tampil di daftar tanggal, tapi tidak jadi pengumuman di Beranda
_MINOR_NAMA = {"Pi Day", "April Mop", "Halloween", "Hari Radio", "Hari Gizi dan Makanan", "Hari Supersemar",
               "Hari Musik Sedunia", "Hari Populasi Dunia", "Hari Pariwisata Dunia", "Hari Musik Nasional",
               "Hari Pers Nasional", "Hari Kanker Sedunia", "Hari Laut Sedunia", "Hari Buku Sedunia",
               "Hari Tanpa Tembakau Sedunia", "Hari Lansia Internasional", "Hari Pemuda Internasional",
               "Hari Literasi Internasional", "Hari Diabetes Sedunia", "Hari Pramuka", "Hari Kesehatan Nasional",
               "Hari AIDS Sedunia (nasional)", "Hari Anak Sedunia", "Hari Kesehatan Dunia"}
_MINOR_HIJRI = {"Ayyamul Bidh (puasa sunnah)", "Hari Tarwiyah", "Hari Tasyrik"}


def _nth_weekday(y, m, weekday, n):
    d = date(y, m, 1)
    d += timedelta(days=(weekday - d.weekday()) % 7)
    return d + timedelta(weeks=n - 1)


def paskah(y):
    a, b, c = y % 19, y // 100, y % 100
    d, e = b // 4, b % 4
    f = (b + 8) // 25
    g = (b - f + 1) // 3
    h = (19 * a + b - d - g + 15) % 30
    i, k = c // 4, c % 4
    l = (32 + 2 * e + 2 * i - h - k) % 7
    m = (a + 11 * h + 22 * l) // 451
    mo = (h + l - 7 * m + 114) // 31
    dy = (h + l - 7 * m + 114) % 31 + 1
    return date(y, mo, dy)


_YEAR = {}


def _tahun(y):
    """tanggal -> list peristiwa non-Hijriyah untuk tahun y."""
    if y in _YEAR:
        return _YEAR[y]
    out = {}

    def add(d, e):
        out.setdefault(d, []).append(e)

    if y in RESMI:
        for (m, dd), (nama, jenis) in RESMI[y].items():
            add(date(y, m, dd), _ev(nama, jenis))
    else:
        approx = True
        add(date(y, 1, 1), _ev("Tahun Baru Masehi", LIBUR, approx=True))
        add(date(y, 5, 1), _ev("Hari Buruh Internasional", LIBUR, approx=True))
        add(date(y, 6, 1), _ev("Hari Lahir Pancasila", LIBUR, approx=True))
        add(date(y, 8, 17), _ev("Proklamasi Kemerdekaan RI", LIBUR, approx=True))
        add(date(y, 12, 25), _ev("Kelahiran Yesus Kristus (Natal)", LIBUR, approx=True))
        e = paskah(y)
        add(e - timedelta(days=2), _ev("Wafat Yesus Kristus", LIBUR, approx=True))
        add(e, _ev("Kebangkitan Yesus Kristus (Paskah)", LIBUR, approx=True))
        add(e + timedelta(days=39), _ev("Kenaikan Yesus Kristus", LIBUR, approx=True))
        if y in IMLEK:
            m, dd = IMLEK[y]
            add(date(y, m, dd), _ev("Tahun Baru Imlek", LIBUR, approx=True))
        for (hm, hd), nama in ((((1, 1)), "Tahun Baru Islam"), ((3, 12), "Maulid Nabi Muhammad saw."),
                               ((7, 27), "Isra Mikraj Nabi Muhammad saw."), ((10, 1), "Idulfitri"),
                               ((10, 2), "Idulfitri"), ((12, 10), "Iduladha")):
            d0 = date(y, 1, 1)
            hy = hijri.dari_masehi(d0)[0]
            for yy in (hy - 1, hy, hy + 1):
                try:
                    c = hijri.ke_masehi(yy, hm, hd)
                except Exception:
                    continue
                if c.year == y:
                    add(c, _ev(nama, LIBUR, approx=True))
    for (m, dd), nama in NASIONAL_TETAP.items():
        add(date(y, m, dd), _ev(nama, NASIONAL, minor=nama in _MINOR_NAMA))
    for (m, dd), nama in INTL_TETAP.items():
        add(date(y, m, dd), _ev(nama, INTL, minor=nama in _MINOR_NAMA))
    add(_nth_weekday(y, 5, 6, 2), _ev("Hari Ibu Internasional", INTL))
    add(_nth_weekday(y, 6, 6, 3), _ev("Hari Ayah Internasional", INTL))
    _YEAR[y] = out
    return out


def events(d, koreksi=0):
    """Semua peristiwa pada tanggal d: urut libur, cuti, nasional, intl, hijri."""
    base = list(_tahun(d.year).get(d, []))
    hy, hm, hd = hijri.dari_masehi(d, koreksi)
    nama = hijri.PERISTIWA.get((hm, hd))
    if nama:
        resmi = any(e["jenis"] in (LIBUR, CUTI) for e in base)
        if not ((hm, hd) in _HIJRI_LIBUR_KEYS and resmi):
            base.append(_ev(nama, HIJRI, minor=nama in _MINOR_HIJRI or nama.startswith("Ayyamul")))
    order = {LIBUR: 0, CUTI: 1, NASIONAL: 2, INTL: 3, HIJRI: 4}
    base.sort(key=lambda e: order[e["jenis"]])
    # buang duplikat nama
    seen, res = set(), []
    for e in base:
        if e["nama"] in seen:
            continue
        seen.add(e["nama"])
        res.append(e)
    return res


def is_libur(d):
    """Hari merah: libur nasional resmi (bukan cuti bersama)."""
    return any(e["jenis"] == LIBUR for e in _tahun(d.year).get(d, []))


def libur_nama(d):
    for e in _tahun(d.year).get(d, []):
        if e["jenis"] in (LIBUR, CUTI):
            return e["nama"]
    return None


def penting(d, koreksi=0):
    return [e for e in events(d, koreksi) if not e["minor"]]


def mendatang(d, hari=14, koreksi=0, hanya_penting=True):
    """[(tanggal, peristiwa)] mulai d (termasuk hari ini) sampai d+hari."""
    out = []
    for i in range(hari + 1):
        x = d + timedelta(days=i)
        for e in (penting(x, koreksi) if hanya_penting else events(x, koreksi)):
            out.append((x, e))
    return out


def ada_penanda(d, koreksi=0):
    """None | 'libur' | 'cuti' | 'event' -- untuk titik di grid kalender."""
    ev = events(d, koreksi)
    for j in (LIBUR, CUTI):
        if any(e["jenis"] == j for e in ev):
            return j
    return "event" if any(not e["minor"] for e in ev) else None
