"""Pembantu musik LOKAL (tanpa GUI): memindai file/folder audio dan menyaring daftar."""
import os
from pathlib import Path

AUDIO_EXT = (".mp3", ".flac", ".ogg", ".oga", ".opus", ".m4a", ".aac", ".wav", ".wma")
MAX_SCAN = 5000


def matches(track, q):
    q = (q or "").strip().lower()
    return not q or q in f"{track.get('title', '')} {track.get('artist', '')} {track.get('album', '')}".lower()


def _local_track(path):
    p = Path(path)
    stem = p.stem.replace("_", " ").strip()
    artist, title = "", stem
    if " - " in stem:
        artist, title = (x.strip() for x in stem.split(" - ", 1))
    return dict(id=f"local:{p}", source="local", title=title or stem, artist=artist or "Lokal", album=p.parent.name,
                duration=0, url=p.as_uri(), page="", preview=False, path=str(p))


def scan_paths(paths):
    """Daftar lagu dari file/folder (folder dipindai rekursif, duplikat dibuang)."""
    out, seen = [], set()

    def add(f):
        if f.lower().endswith(AUDIO_EXT) and f not in seen and len(out) < MAX_SCAN:
            seen.add(f)
            out.append(_local_track(f))
    for path in paths:
        if os.path.isdir(path):
            for root, dirs, files in os.walk(path):
                dirs.sort()
                for name in sorted(files):
                    add(os.path.join(root, name))
        elif os.path.isfile(path):
            add(path)
    return out
