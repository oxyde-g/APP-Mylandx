"""Mesin latar: cek alarm & pengingat tugas tiap detik, suara, notifikasi."""
import math
import shutil
import struct
import subprocess
import wave
from datetime import datetime, timedelta

from gi.repository import GLib

from . import prayer
from .util import parse_dt, due_label


# ---------------------------------------------------------------- suara
def _synth(path, events, length, sr=44100):
    """events: [(freq, start, dur, vol)] -> WAV mono 16-bit, bunyi lonceng lembut."""
    n = int(sr * length)
    buf = [0.0] * n
    for freq, start, dur, vol in events:
        s0 = int(start * sr)
        for i in range(int(dur * sr)):
            j = s0 + i
            if j >= n:
                break
            t = i / sr
            env = math.exp(-t * 5.0) * min(1.0, t * 400)
            v = (math.sin(2 * math.pi * freq * t)
                 + 0.35 * math.sin(2 * math.pi * freq * 2.01 * t)
                 + 0.12 * math.sin(2 * math.pi * freq * 3.02 * t))
            buf[j] += v * env * vol
    peak = max(1e-9, max(abs(x) for x in buf))
    data = b"".join(struct.pack("<h", int(max(-1, min(1, x / peak * 0.8)) * 32767)) for x in buf)
    with wave.open(str(path), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(sr)
        w.writeframes(data)


class Sound:
    LOOP_MS = 3000

    def __init__(self, store):
        self.store = store
        self.player = next((p for p in ("pw-play", "paplay", "aplay") if shutil.which(p)), None)
        self.files = {}
        self._src = 0
        self._procs = []
        self._users = 0

    # ---- adzan / file audio bebas (dipakai waktu sholat)
    def play_file(self, path):
        """Putar satu file audio sampai selesai. Return True jika berhasil dimulai."""
        self.stop_file()
        cmd = None
        if shutil.which("mpv"):
            cmd = ["mpv", "--no-video", "--really-quiet", "--no-terminal", path]
        elif self.player:
            cmd = [self.player, path]
        if not cmd:
            return False
        try:
            self._file_proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return True
        except OSError:
            return False

    def file_playing(self):
        p = getattr(self, "_file_proc", None)
        return bool(p and p.poll() is None)

    def stop_file(self):
        p = getattr(self, "_file_proc", None)
        if p and p.poll() is None:
            p.terminate()
        self._file_proc = None

    def _file(self, kind):
        path = self.store.dir / f"{kind}.wav"
        if not path.exists():
            try:
                if kind == "alarm":
                    ev = []
                    for rep in (0.0, 1.5):
                        for k, f in enumerate((1046.5, 1318.5, 1568.0, 2093.0)):
                            ev.append((f, rep + k * 0.22, 1.0, 1.0))
                    _synth(path, ev, 2.9)
                else:  # ding: tanda selesai timer
                    _synth(path, [(1318.5, 0.0, 1.2, 1.0), (1760.0, 0.18, 1.2, 0.8), (2093.0, 0.36, 1.3, 0.7)], 1.8)
            except OSError:
                return None
        return str(path)

    def _spawn(self, kind):
        if not self.store.settings.get("sound", True):
            return
        path = self._file(kind)
        if not (self.player and path):
            return
        self._procs = [p for p in self._procs if p.poll() is None]
        try:
            self._procs.append(subprocess.Popen([self.player, path], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL))
        except OSError:
            pass

    def once(self, kind="ding"):
        self._spawn(kind)

    def start_loop(self):
        self._users += 1
        if self._src:
            return
        self._spawn("alarm")
        self._src = GLib.timeout_add(self.LOOP_MS, self._again)

    def _again(self):
        self._spawn("alarm")
        return True

    def stop_loop(self):
        self._users = max(0, self._users - 1)
        if self._users == 0 and self._src:
            GLib.source_remove(self._src)
            self._src = 0
            for p in self._procs:
                if p.poll() is None:
                    p.terminate()
            self._procs = []


# ---------------------------------------------------------------- notifikasi
class Notifier:
    def __init__(self, store):
        self.store = store
        self.app = None  # diisi oleh Gtk.Application

    def send(self, title, body, urgent=False, nid=None):
        if not self.store.settings.get("notif", True):
            return
        try:
            if self.app is not None:
                from gi.repository import Gio
                n = Gio.Notification.new(title)
                n.set_body(body)
                n.set_priority(Gio.NotificationPriority.URGENT if urgent else Gio.NotificationPriority.NORMAL)
                n.set_default_action("app.show")
                self.app.send_notification(nid, n)
            elif shutil.which("notify-send"):
                subprocess.Popen(["notify-send", "-a", "mylandx", title, body],
                                 stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception as e:  # notifikasi tidak boleh membuat app crash
            print("mylandx: notifikasi gagal:", e)


# ---------------------------------------------------------------- mesin
class Engine:
    def __init__(self, store, sound, notifier):
        self.store, self.sound, self.notifier = store, sound, notifier
        self.on_ring = lambda alarm: None     # dipasang UI
        self.on_minute = []                   # callback tiap pergantian menit
        self._snooze = {}                     # id alarm -> datetime
        self._last_minute = None
        self.on_prayer = lambda key, when, played: None   # dipasang UI
        self._prayer_done = set()
        self._prayer_cache = {}
        self._src = GLib.timeout_add(1000, self._tick)

    def _tick(self):
        try:
            self.tick()
        except Exception as e:
            print("mylandx: tick error:", e)
        return True

    def tick(self, now=None):
        now = now or datetime.now()
        key = now.strftime("%Y-%m-%d %H:%M")
        hhmm = now.strftime("%H:%M")

        for a in list(self.store.alarms):
            if not a.get("enabled"):
                continue
            snooze_at = self._snooze.get(a["id"])
            fire = False
            if snooze_at and now >= snooze_at:
                fire = True
                self._snooze.pop(a["id"], None)
            elif a["time"] == hhmm and a.get("last_fired") != key and (not a.get("days") or now.weekday() in a["days"]):
                fire = True
                self.store.mark_alarm_fired(a["id"], key, disable=not a.get("days"))
            if fire:
                self.ring(a)

        if self.store.settings.get("notif", True):
            for t in list(self.store.tasks):
                if t.get("done") or not t.get("due") or t.get("remind", -1) < 0 or t.get("reminded"):
                    continue
                due = parse_dt(t["due"])
                if not due:
                    continue
                trigger = due - timedelta(minutes=t["remind"])
                if now >= trigger:
                    self.store.mark_reminded(t["id"])
                    if (now - trigger).total_seconds() <= 6 * 3600:  # kalau telat banget, jangan spam
                        self.notifier.send("Pengingat tugas", f"{t['title']}\n{due_label(due, now, self.store.settings['clock24'])}",
                                           urgent=True, nid="task-" + t["id"])

        self._tick_prayer(now)

        if key != self._last_minute:
            self._last_minute = key
            for fn in list(self.on_minute):
                fn()

    # ---------------- waktu sholat
    def lokasi(self):
        return prayer.lokasi_dari(self.store.settings)

    def city_now(self, now=None):
        """Waktu setempat kota sholat (naif). now = waktu sistem naif, atau None."""
        return prayer.sekarang(self.lokasi(), now)

    def prayer_times(self, d=None):
        st = self.store.settings
        lok = self.lokasi()
        d = d or self.city_now().date()
        key = (d, lok.kunci(), bool(st.get("asr_hanafi")))
        hit = self._prayer_cache.get(key)
        if hit is None:
            if len(self._prayer_cache) > 8:
                self._prayer_cache.clear()
            hit = self._prayer_cache[key] = prayer.jadwal(d, lok, bool(st.get("asr_hanafi")))
        return hit

    def next_prayer(self, now=None):
        """-> (key, waktu_setempat, now_setempat)"""
        st = self.store.settings
        cn = self.city_now(now)
        k, w = prayer.berikutnya(cn, self.lokasi(), bool(st.get("asr_hanafi")))
        return k, w, cn

    def _tick_prayer(self, now):
        """now = waktu sistem naif."""
        st = self.store.settings
        if not st.get("prayer", True):
            return
        cn = self.city_now(now)
        on = st.get("prayer_on", {})
        remind = int(st.get("prayer_remind", 0) or 0)
        kota = self.lokasi().nama
        for day in (cn.date() - timedelta(days=1), cn.date()):
            times = self.prayer_times(day)
            for k in prayer.KEYS:
                when = times.get(k)
                if not when or not on.get(k, True):
                    continue
                nama = prayer.NAMA[prayer.KEYS.index(k)]
                if remind > 0:
                    tag = (when, k, "pre")
                    trig = when - timedelta(minutes=remind)
                    if tag not in self._prayer_done and 0 <= (cn - trig).total_seconds() < 90:
                        self._prayer_done.add(tag)
                        self.notifier.send(f"{remind} menit lagi {nama}", f"{when:%H:%M} · {kota}", nid=f"prayer-pre-{k}")
                tag = (when, k)
                if tag not in self._prayer_done and 0 <= (cn - when).total_seconds() < 120:
                    self._prayer_done.add(tag)
                    self.fire_prayer(k, when)
        if len(self._prayer_done) > 60:
            self._prayer_done = {t for t in self._prayer_done if (cn - t[0]).total_seconds() < 86400}

    def adzan_path(self, key):
        st = self.store.settings
        if st.get("adzan_mode") != "adzan":
            return ""
        f = (st.get("adzan_subuh_file") if key == "subuh" else "") or st.get("adzan_file", "")
        from pathlib import Path
        return f if f and Path(f).is_file() else ""

    def fire_prayer(self, key, when, test=False):
        st = self.store.settings
        nama = prayer.NAMA[prayer.KEYS.index(key)]
        self.notifier.send(f"Waktu {nama} telah tiba", f"{when:%H:%M} · {self.lokasi().nama}",
                           urgent=True, nid=f"prayer-{key}")
        mode = st.get("adzan_mode", "adzan")
        played = False
        if st.get("sound", True) and mode != "senyap":
            path = self.adzan_path(key)
            if path:
                played = self.sound.play_file(path)
            if not played:
                self.sound.once("ding")
                played = mode == "chime" or not path
        self.on_prayer(key, when, played)

    def ring(self, alarm):
        self.notifier.send(alarm.get("label") or "Alarm", alarm["time"], urgent=True, nid="alarm-" + alarm["id"])
        self.on_ring(alarm)

    def snooze(self, alarm, minutes=5):
        self._snooze[alarm["id"]] = datetime.now() + timedelta(minutes=minutes)
        if not alarm.get("enabled"):  # alarm sekali pakai sudah dimatikan saat bunyi; hidupkan lagi untuk tunda
            self.store.update_alarm(alarm["id"], enabled=True)
