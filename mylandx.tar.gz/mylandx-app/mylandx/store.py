"""Penyimpanan data (JSON, atomic write) + observer sederhana. Tanpa dependensi GUI."""
import json
import os
import shutil
import time
import uuid
from datetime import datetime, date
from pathlib import Path

DEFAULT_SETTINGS = dict(
    theme="dark", accent="#7c6cff",
    focus=25, short=5, long=15, cycles=4, auto_next=False,
    sound=True, notif=True, clock24=True, background=False,
    volume=80,
)


def data_dir():
    env = os.environ.get("MYLANDX_DATA")
    if env:
        return Path(env)
    base = os.environ.get("XDG_DATA_HOME") or str(Path.home() / ".local" / "share")
    return Path(base) / "mylandx"


def uid():
    return uuid.uuid4().hex[:10]


class Store:
    def __init__(self, directory=None):
        self.dir = Path(directory) if directory else data_dir()
        self.dir.mkdir(parents=True, exist_ok=True)
        self.path = self.dir / "data.json"
        self.bak = self.dir / "data.bak.json"
        self.settings = dict(DEFAULT_SETTINGS)
        self.tasks = []
        self.alarms = []
        self.focus_log = {}
        self.notes = []
        self.favs = []
        self.library = []
        self.albums = []
        self.last_error = ""
        self._last_bak = 0.0
        self._subs = []
        self._sub_settings = []
        self.load()

    # ---------- persistence ----------
    @staticmethod
    def _read(path):
        raw = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(raw, dict):
            raise ValueError("bukan objek JSON")
        return raw

    def load(self):
        raw = None
        try:
            raw = self._read(self.path)
        except (OSError, ValueError):
            if self.path.exists():  # file rusak: karantina, lalu coba pulihkan dari cadangan
                try:
                    self.path.replace(self.dir / f"data.rusak-{datetime.now():%Y%m%d-%H%M%S}.json")
                except OSError:
                    pass
            snap_dir = self.dir / "backups"
            snaps = sorted(snap_dir.glob("data-*.json"), reverse=True) if snap_dir.is_dir() else []
            for cand in [self.bak, *snaps]:
                try:
                    raw = self._read(cand)
                    print(f"mylandx: data dipulihkan dari {cand.name}")
                    break
                except (OSError, ValueError):
                    continue
        raw = raw or {}
        if isinstance(raw.get("settings"), dict):
            self.settings.update({k: v for k, v in raw["settings"].items() if k in DEFAULT_SETTINGS})
        ok = lambda x: isinstance(x, dict) and x.get("id")
        self.tasks = [t for t in raw.get("tasks", []) if ok(t)]
        self.alarms = [a for a in raw.get("alarms", []) if ok(a)]
        self.notes = [n for n in raw.get("notes", []) if ok(n)]
        self.favs = [t for t in raw.get("favs", []) if ok(t)]
        self.library = [t for t in raw.get("library", []) if ok(t)]
        self.albums = [dict(a, tracks=list(a.get("tracks") or [])) for a in raw.get("albums", []) if ok(a)]
        self.focus_log = raw.get("focus", {}) if isinstance(raw.get("focus"), dict) else {}

    def _backup(self):
        """Cadangan berlapis: data.bak.json (maks. 1x/menit) + snapshot harian di backups/ (14 hari)."""
        try:
            if not self.path.exists():
                return
            now = time.time()
            if now - self._last_bak > 60:
                shutil.copy2(self.path, self.bak)
                self._last_bak = now
            snap_dir = self.dir / "backups"
            snap = snap_dir / f"data-{date.today():%Y%m%d}.json"
            if not snap.exists():
                snap_dir.mkdir(exist_ok=True)
                shutil.copy2(self.path, snap)
                for old in sorted(snap_dir.glob("data-*.json"))[:-14]:
                    old.unlink()
        except OSError:
            pass

    def save(self):
        blob = dict(version=2, settings=self.settings, tasks=self.tasks, alarms=self.alarms, notes=self.notes,
                    favs=self.favs, library=self.library, albums=self.albums, focus=self.focus_log)
        tmp = self.path.with_suffix(".tmp")
        try:
            self._backup()
            with open(tmp, "w", encoding="utf-8") as f:
                f.write(json.dumps(blob, ensure_ascii=False, indent=1))
                f.flush()
                os.fsync(f.fileno())
            os.replace(tmp, self.path)
            self.last_error = ""
            return True
        except OSError as e:
            self.last_error = str(e)
            print("mylandx: gagal menyimpan:", e)
            return False

    # ---------- observers ----------
    def on_change(self, fn):
        self._subs.append(fn)

    def on_settings(self, fn):
        self._sub_settings.append(fn)

    def _changed(self):
        self.save()
        for fn in list(self._subs):
            fn()

    # ---------- settings ----------
    def set_setting(self, key, value):
        if self.settings.get(key) == value:
            return
        self.settings[key] = value
        self.save()
        for fn in list(self._sub_settings):
            fn(key)
        for fn in list(self._subs):
            fn()

    # ---------- tasks ----------
    def add_task(self, **kw):
        t = dict(id=uid(), title="", note="", due=None, priority=1, done=False,
                 remind=-1, reminded=False, spent=0, created=datetime.now().isoformat(timespec="seconds"))
        t.update(kw)
        t["title"] = (t["title"] or "").strip() or "Tanpa judul"
        self.tasks.append(t)
        self._changed()
        return t

    def get_task(self, tid):
        return next((t for t in self.tasks if t["id"] == tid), None)

    def update_task(self, tid, **kw):
        t = self.get_task(tid)
        if not t:
            return
        if "due" in kw or "remind" in kw:
            kw["reminded"] = False
        t.update(kw)
        self._changed()

    def toggle_task(self, tid):
        t = self.get_task(tid)
        if t:
            t["done"] = not t["done"]
            t["done_at"] = datetime.now().isoformat(timespec="seconds") if t["done"] else None
            self._changed()

    def delete_task(self, tid):
        self.tasks = [t for t in self.tasks if t["id"] != tid]
        self._changed()

    def mark_reminded(self, tid):
        """Tandai sudah diingatkan tanpa memicu refresh UI."""
        t = self.get_task(tid)
        if t:
            t["reminded"] = True
            self.save()

    def tasks_on(self, d):
        out = []
        for t in self.tasks:
            due = t.get("due")
            if due and due[:10] == d.isoformat():
                out.append(t)
        return out

    # ---------- alarms ----------
    def add_alarm(self, **kw):
        a = dict(id=uid(), time="07:00", label="", days=[], enabled=True, last_fired="")
        a.update(kw)
        self.alarms.append(a)
        self._changed()
        return a

    def get_alarm(self, aid):
        return next((a for a in self.alarms if a["id"] == aid), None)

    def update_alarm(self, aid, **kw):
        a = self.get_alarm(aid)
        if a:
            a.update(kw)
            self._changed()

    def delete_alarm(self, aid):
        self.alarms = [a for a in self.alarms if a["id"] != aid]
        self._changed()

    def mark_alarm_fired(self, aid, key, disable=False):
        a = self.get_alarm(aid)
        if a:
            a["last_fired"] = key
            if disable:
                a["enabled"] = False
            self._changed()

    # ---------- fokus ----------
    def add_focus(self, minutes, sessions=0, task_id=None, day=None):
        key = (day or date.today()).isoformat()
        rec = self.focus_log.setdefault(key, {"minutes": 0, "count": 0})
        rec["minutes"] += int(minutes)
        rec["count"] += int(sessions)
        if task_id:
            t = self.get_task(task_id)
            if t:
                t["spent"] = t.get("spent", 0) + int(minutes)
        self._changed()

    def focus_on(self, d):
        return self.focus_log.get(d.isoformat(), {"minutes": 0, "count": 0})

    # ---------- catatan ----------
    def add_note(self, title="", body=""):
        now = datetime.now().isoformat(timespec="seconds")
        n = dict(id=uid(), title=title, body=body, pinned=False, created=now, updated=now)
        self.notes.append(n)
        self._changed()
        return n

    def get_note(self, nid):
        return next((n for n in self.notes if n["id"] == nid), None)

    def update_note(self, nid, quiet=False, **kw):
        """quiet=True: simpan ke disk tanpa memicu refresh UI (dipakai autosave saat mengetik)."""
        n = self.get_note(nid)
        if not n:
            return
        if any(n.get(k) != v for k, v in kw.items()):
            n.update(kw)
            n["updated"] = datetime.now().isoformat(timespec="seconds")
            if quiet:
                self.save()
            else:
                self._changed()

    def delete_note(self, nid):
        self.notes = [n for n in self.notes if n["id"] != nid]
        self._changed()

    # ---------- musik: favorit & library lokal ----------
    def is_fav(self, tid):
        return any(t["id"] == tid for t in self.favs)

    def toggle_fav(self, track):
        if self.is_fav(track["id"]):
            self.favs = [t for t in self.favs if t["id"] != track["id"]]
        else:
            self.favs.append(dict(track))
        self._changed()

    def add_library(self, tracks):
        have = {t["id"] for t in self.library}
        added = [dict(t) for t in tracks if t["id"] not in have]
        self.library.extend(added)
        self._changed()
        return len(added)

    def clear_library(self):
        self.library = []
        self.favs = [t for t in self.favs if t.get("source") != "local"]
        for al in self.albums:
            al["tracks"] = []
        self._changed()

    def remove_track(self, tid):
        """Hapus lagu dari daftar (file aslinya di komputer TIDAK disentuh)."""
        self.library = [t for t in self.library if t["id"] != tid]
        self.favs = [t for t in self.favs if t["id"] != tid]
        for al in self.albums:
            al["tracks"] = [x for x in al["tracks"] if x != tid]
        self._changed()

    # ---------- album ----------
    def add_album(self, name):
        al = dict(id=uid(), name=(name or "").strip() or "Album baru", tracks=[])
        self.albums.append(al)
        self._changed()
        return al

    def get_album(self, aid):
        return next((a for a in self.albums if a["id"] == aid), None)

    def rename_album(self, aid, name):
        al = self.get_album(aid)
        if al and name.strip():
            al["name"] = name.strip()
            self._changed()

    def delete_album(self, aid):
        """Hapus album saja; lagunya tetap ada di daftar."""
        self.albums = [a for a in self.albums if a["id"] != aid]
        self._changed()

    def album_add(self, aid, track_ids):
        al = self.get_album(aid)
        if al:
            for t in track_ids:
                if t not in al["tracks"]:
                    al["tracks"].append(t)
            self._changed()

    def album_remove(self, aid, tid):
        al = self.get_album(aid)
        if al and tid in al["tracks"]:
            al["tracks"].remove(tid)
            self._changed()

    def album_tracks(self, aid):
        al = self.get_album(aid)
        by_id = {t["id"]: t for t in self.library}
        return [by_id[i] for i in (al["tracks"] if al else []) if i in by_id]
