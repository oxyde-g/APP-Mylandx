"""Palet warna + generator CSS. Satu sumber kebenaran untuk widget CSS dan gambar Cairo."""

DARK = dict(
    bg="#0d0f15", side="#11141c", surface="#161a24", surface2="#1d2230", border="#272d3f",
    text="#e8ebf5", muted="#8890a8", danger="#ff6b7b", ok="#34d399", warn="#fbbf24",
)
LIGHT = dict(
    bg="#f2f3f8", side="#ffffff", surface="#ffffff", surface2="#eceef6", border="#dde0ec",
    text="#1a1e2b", muted="#677089", danger="#e03e4c", ok="#10a37a", warn="#c97d00",
)
ACCENTS = [
    ("Violet", "#7c6cff"), ("Biru", "#3b82f6"), ("Cyan", "#06b6d4"),
    ("Hijau", "#10b981"), ("Oranye", "#f59e0b"), ("Pink", "#ec4899"),
]


def _rgb(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) / 255.0 for i in (0, 2, 4))


def _mix(a, b, t):
    ra, rb = _rgb(a), _rgb(b)
    return "#" + "".join(f"{round((x * (1 - t) + y * t) * 255):02x}" for x, y in zip(ra, rb))


class Theme:
    def __init__(self):
        self.name = "dark"
        self.accent = ACCENTS[0][1]
        self.p = dict(DARK)

    def set(self, name, accent):
        self.name = "light" if name == "light" else "dark"
        self.accent = accent if (accent or "").startswith("#") and len(accent) == 7 else ACCENTS[0][1]
        self.p = dict(LIGHT if self.name == "light" else DARK)

    @property
    def dark(self):
        return self.name == "dark"

    def hex(self, key):
        return self.accent if key == "accent" else self.p[key]

    def rgba(self, key, alpha=1.0):
        r, g, b = _rgb(self.hex(key))
        return (r, g, b, alpha)

    def css_rgba(self, key, alpha):
        r, g, b = (round(c * 255) for c in _rgb(self.hex(key)))
        return f"rgba({r},{g},{b},{alpha})"

    def css(self):
        t = dict(self.p)
        t["accent"] = self.accent
        t["accent2"] = _mix(self.accent, "#ffffff", 0.18)
        t["accent_soft"] = self.css_rgba("accent", 0.16)
        t["accent_line"] = self.css_rgba("accent", 0.55)
        out = CSS
        for k in sorted(t, key=len, reverse=True):
            out = out.replace("$" + k, t[k])
        return out


THEME = Theme()

CSS = """
* { font-family: "Inter", "Adwaita Sans", "Cantarell", "Noto Sans", sans-serif; font-size: 13px; }
window.mylandx, window.dialog-win { background: $bg; color: $text; }
label.muted, .muted label { color: $muted; }
label.accent { color: $accent; }
label.danger-text { color: $danger; }
label.ok-text { color: $ok; }

headerbar { background: $side; background-image: none; box-shadow: none; border: none;
            border-bottom: 1px solid $border; min-height: 42px; color: $text; }
headerbar label { color: $text; font-weight: 700; }

.sidebar { background: $side; border-right: 1px solid $border; }
.brand { font-size: 21px; font-weight: 800; letter-spacing: 0.3px; }
.nav { background: transparent; background-image: none; box-shadow: none; text-shadow: none;
       border: 1px solid transparent; border-radius: 12px; padding: 9px 12px; color: $muted; font-weight: 600; }
.nav label { color: $muted; font-weight: 600; font-size: 14px; }
.nav:hover { background: $surface2; }
.nav:hover label { color: $text; }
.nav:checked { background: $accent_soft; }
.nav:checked label { color: $accent; }

.card { background: $surface; border: 1px solid $border; border-radius: 18px; padding: 18px; }
.card-flat { background: $surface2; border-radius: 14px; padding: 12px 14px; }
.row { background: $surface; border: 1px solid $border; border-radius: 14px; padding: 10px 14px; }
.row:hover { border-color: $accent_line; }
.row-done label.row-title { color: $muted; }

.h1 { font-size: 28px; font-weight: 800; }
.h2 { font-size: 16px; font-weight: 700; }
.h3 { font-size: 14px; font-weight: 700; }
.sub { color: $muted; font-size: 14px; }
.tiny { font-size: 11px; color: $muted; }
.stat { font-size: 34px; font-weight: 800; }
.digital { font-size: 76px; font-weight: 800; letter-spacing: -1px; }
.seconds { font-size: 26px; font-weight: 700; color: $accent; }
.alarm-time { font-size: 32px; font-weight: 800; }
.row-title { font-size: 14px; font-weight: 600; }
.ring-time { font-size: 15px; }

.prio { border-radius: 99px; min-width: 4px; }
.prio-0 { background: $ok; }
.prio-1 { background: $warn; }
.prio-2 { background: $danger; }

entry, spinbutton { background: $surface2; background-image: none; color: $text; border: 1px solid $border;
                    border-radius: 12px; padding: 7px 12px; min-height: 22px; box-shadow: none; }
entry:focus-within, spinbutton:focus-within { border-color: $accent; }
entry text, spinbutton text { color: $text; }
spinbutton { padding: 0 4px; }
spinbutton button { background: transparent; background-image: none; border: none; box-shadow: none; color: $muted; padding: 2px 6px; min-width: 18px; }
spinbutton button:hover { color: $accent; }
.bigspin { font-size: 30px; font-weight: 800; }
.bigspin text { font-size: 30px; font-weight: 800; }

button { background: $surface2; background-image: none; color: $text; border: 1px solid $border;
         border-radius: 12px; padding: 8px 16px; box-shadow: none; text-shadow: none; min-height: 22px; }
button:hover { border-color: $accent_line; background-image: none; }
button label { color: inherit; }
button.primary { background: $accent; border-color: transparent; color: #ffffff; font-weight: 700; }
button.primary label { color: #ffffff; }
button.primary:hover { background: $accent2; }
button.ghost { background: transparent; border-color: transparent; color: $muted; padding: 6px 10px; }
button.ghost:hover { background: $surface2; color: $text; }
button.danger:hover { color: $danger; }
button.chip { border-radius: 99px; padding: 5px 14px; font-weight: 600; color: $muted; background: transparent; }
button.chip:checked { background: $accent_soft; color: $accent; border-color: $accent_line; }
button.chip:checked label { color: $accent; }
button.round-nav { border-radius: 99px; padding: 4px 12px; font-size: 16px; }
button.day { border-radius: 10px; padding: 8px 6px; min-width: 38px; font-weight: 600; color: $muted; }
button.day:checked { background: $accent; color: #ffffff; border-color: transparent; }
button.day:checked label { color: #ffffff; }
button.swatch { border-radius: 99px; min-width: 26px; min-height: 26px; padding: 0; border: 3px solid transparent; }
button.swatch:checked { border-color: $text; }

switch { background: $surface2; background-image: none; border: 1px solid $border; border-radius: 99px;
         min-width: 46px; min-height: 26px; box-shadow: none; }
switch:checked { background: $accent; border-color: transparent; }
switch slider { background: #ffffff; background-image: none; border-radius: 99px; border: none;
                min-width: 20px; min-height: 20px; margin: 2px; box-shadow: none; }

checkbutton check { border-radius: 99px; min-width: 20px; min-height: 20px; border: 2px solid $muted;
                    background: transparent; background-image: none; box-shadow: none; color: #ffffff; }
checkbutton check:hover { border-color: $accent; }
checkbutton check:checked { background: $accent; border-color: $accent; }

dropdown > button, dropdown button { padding: 6px 12px; }
popover > contents, popover contents { background: $surface; color: $text; border: 1px solid $border;
                                       border-radius: 14px; padding: 6px; box-shadow: 0 8px 24px rgba(0,0,0,0.35); }
popover listview, popover list { background: transparent; color: $text; }
popover row, popover listview > row { border-radius: 8px; padding: 6px 10px; color: $text; }
popover row:hover, popover listview > row:hover { background: $surface2; }
popover row:selected, popover listview > row:selected { background: $accent_soft; color: $accent; }
calendar { background: transparent; color: $text; padding: 4px; }
calendar:selected { background: $accent; color: #ffffff; border-radius: 8px; }
calendar.header, calendar > header { color: $text; }
calendar button { background: transparent; border: none; padding: 2px 8px; }

scrolledwindow, scrolledwindow viewport { background: transparent; }
scrollbar { background: transparent; }
scrollbar slider { background: $border; border-radius: 99px; min-width: 6px; min-height: 30px; }
scrollbar slider:hover { background: $muted; }

separator { background: $border; min-height: 1px; min-width: 1px; }
tooltip, tooltip.background { background: $surface2; color: $text; border: 1px solid $border; border-radius: 8px; }
tooltip label { color: $text; }

.ring-banner { background: $surface; }

textview, textview text { background: $surface2; color: $text; }
.editor { background: $surface2; border: 1px solid $border; border-radius: 12px; }
.editor:focus-within { border-color: $accent; }
entry.note-title { font-size: 20px; font-weight: 700; }
button.accent, button.accent label { color: $accent; }
button.note-item { background: transparent; border: 1px solid transparent; border-radius: 12px; padding: 10px 12px; }
button.note-item:hover { background: $surface2; }
button.note-sel { background: $accent_soft; border-color: $accent_line; }
.row-sel { border-color: $accent_line; background: $accent_soft; }

.playerbar { background: $side; border-top: 1px solid $border; padding: 10px 18px; }
button.icon-btn { background: transparent; border-color: transparent; padding: 6px; border-radius: 10px; min-height: 20px; }
button.icon-btn:hover { background: $surface2; border-color: transparent; }
button.play-btn { background: $accent; border-color: transparent; border-radius: 99px; padding: 8px; }
button.play-btn:hover { background: $accent2; }
scale trough { background: $surface2; border: none; border-radius: 99px; min-height: 6px; }
scale highlight { background: $accent; border: none; border-radius: 99px; min-height: 6px; }
scale slider { background: #ffffff; border: none; border-radius: 99px; min-width: 14px; min-height: 14px; box-shadow: none; }
"""
