import os
import shutil
import sys
from pathlib import Path

import gi
gi.require_version("Gtk", "4.0")
gi.require_version("Gdk", "4.0")
from gi.repository import Gtk, Gdk, Gio, GLib

from . import APP_ID, __version__
from .theme import THEME
from .store import Store
from .engine import Sound, Notifier, Engine
from .player import Player
from .ui.window import MainWindow
from .ui.dialogs import RingDialog


class Ctx:
    """Objek yang dibagikan ke semua halaman."""
    window = None

    def go(self, key):
        self.window.go(key)

    def start_focus(self):
        self.window.go("focus")
        self.window.pages["focus"].start_now()

    @staticmethod
    def _autostart_path():
        return Path(GLib.get_user_config_dir()) / "autostart" / "mylandx.desktop"

    def autostart_enabled(self):
        return self._autostart_path().exists()

    def set_autostart(self, on):
        path = self._autostart_path()
        try:
            if on:
                path.parent.mkdir(parents=True, exist_ok=True)
                exe = shutil.which("mylandx") or os.path.abspath(sys.argv[0])
                path.write_text(
                    "[Desktop Entry]\nType=Application\nName=mylandx\n"
                    f"Exec={exe} --hidden\nIcon={APP_ID}\nX-GNOME-Autostart-enabled=true\nNoDisplay=true\n",
                    encoding="utf-8")
            elif path.exists():
                path.unlink()
        except OSError as e:
            print("mylandx: autostart gagal:", e)


class MylandxApp(Gtk.Application):
    def __init__(self, hidden=False):
        super().__init__(application_id=APP_ID, flags=Gio.ApplicationFlags.DEFAULT_FLAGS)
        self.hidden_start = hidden
        self.win = None
        self._held = False
        self._css = None

    # ---------------- siklus hidup
    def do_startup(self):
        Gtk.Application.do_startup(self)
        GLib.set_application_name("mylandx")
        Gtk.Window.set_default_icon_name(APP_ID)
        self.store = Store()
        self.sound = Sound(self.store)
        self.notifier = Notifier(self.store)
        self.notifier.app = self
        self.engine = Engine(self.store, self.sound, self.notifier)
        self.player = Player(volume=self.store.settings.get("volume", 80) / 100.0)
        self.ctx = Ctx()
        self.ctx.store, self.ctx.sound = self.store, self.sound
        self.ctx.notifier, self.ctx.engine, self.ctx.app = self.notifier, self.engine, self
        self.ctx.player = self.player
        self.engine.on_ring = self._ring

        show = Gio.SimpleAction.new("show", None)
        show.connect("activate", lambda *_: self._present())
        self.add_action(show)
        quit_ = Gio.SimpleAction.new("quit", None)
        quit_.connect("activate", lambda *_: self.quit())
        self.add_action(quit_)
        self.set_accels_for_action("app.quit", ["<Primary>q"])

        self._apply_theme()
        self._sync_background()
        self.store.on_settings(self._on_setting)
        self.store.on_change(lambda: self.win and self.win.schedule_refresh())

    def do_activate(self):
        first = self.win is None
        if first:
            self.win = MainWindow(self, self.ctx)
        if first and self.hidden_start and self.store.settings["background"]:
            return  # start diam-diam di latar belakang
        self._present()

    def do_shutdown(self):
        if self.win:
            self.win.flush_all()
        self.store.save()
        self.player.shutdown()
        Gtk.Application.do_shutdown(self)

    def _present(self):
        if self.win:
            self.win.set_visible(True)
            self.win.present()

    # ---------------- tema & pengaturan
    def _apply_theme(self):
        st = self.store.settings
        THEME.set(st["theme"], st["accent"])
        Gtk.Settings.get_default().set_property("gtk-application-prefer-dark-theme", THEME.dark)
        css = THEME.css()
        if self._css is None:
            self._css = Gtk.CssProvider()
            self._css.connect("parsing-error", lambda p, sec, err: print("mylandx CSS:", err.message))
            Gtk.StyleContext.add_provider_for_display(Gdk.Display.get_default(), self._css, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
        try:
            self._css.load_from_string(css)
        except AttributeError:  # GTK < 4.12
            self._css.load_from_data(css.encode("utf-8"))

    def _on_setting(self, key):
        if key in ("theme", "accent"):
            self._apply_theme()
        elif key == "background":
            self._sync_background()

    def _sync_background(self):
        want = bool(self.store.settings["background"])
        if want and not self._held:
            self.hold()
            self._held = True
        elif not want and self._held:
            self.release()
            self._held = False

    # ---------------- alarm
    def _ring(self, alarm):
        RingDialog(self.ctx, alarm).present()


def main(argv=None):
    argv = list(argv if argv is not None else sys.argv)
    if "--version" in argv:
        print(f"mylandx {__version__}")
        return 0
    hidden = "--hidden" in argv
    argv = [a for a in argv if a != "--hidden"]
    return MylandxApp(hidden).run(argv)
