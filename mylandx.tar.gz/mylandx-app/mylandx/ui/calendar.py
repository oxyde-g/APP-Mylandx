from datetime import date

import gi
gi.require_version("Gtk", "4.0")
from gi.repository import Gtk

from .. import draw
from ..util import BULAN, tanggal_panjang, libur, shift_month, parse_dt
from .common import vbox, hbox, label, button, Canvas, clear
from .dialogs import TaskDialog
from .page import Page
from .taskrow import make_task_row


class CalendarPage(Page):
    def __init__(self, ctx):
        super().__init__(ctx, "Kalender", "Klik tanggal untuk melihat tugas; klik dua kali untuk menambah.")
        today = date.today()
        self.year, self.month = today.year, today.month
        self.selected = today
        self.hover = None
        self.marks = {}
        self.body.append(self.head)

        cols = hbox(18)
        left = vbox(12, ["card"])
        left.set_hexpand(True)
        nav = hbox(8)
        nav.append(button("‹", ["round-nav"], lambda: self.shift(-1), "Bulan sebelumnya"))
        self.month_l = label("", ["h2"], xalign=0.5)
        self.month_l.set_hexpand(True)
        nav.append(self.month_l)
        nav.append(button("›", ["round-nav"], lambda: self.shift(1), "Bulan berikutnya"))
        nav.append(button("Hari ini", [], self.go_today))
        left.append(nav)

        self.grid = Canvas(self._draw, 560, 440, expand=True)
        self.grid.set_size_request(480, 400)
        click = Gtk.GestureClick()
        click.connect("pressed", self._pressed)
        self.grid.add_controller(click)
        motion = Gtk.EventControllerMotion()
        motion.connect("motion", self._motion)
        motion.connect("leave", self._leave)
        self.grid.add_controller(motion)
        self.grid.set_cursor_from_name("pointer")
        left.append(self.grid)
        cols.append(left)

        right = vbox(10, ["card"])
        right.set_size_request(330, -1)
        self.day_title = label("", ["h2"], wrap=True)
        self.day_holiday = label("", ["accent"], wrap=True)
        right.append(self.day_title)
        right.append(self.day_holiday)
        self.day_list = vbox(8)
        right.append(self.day_list)
        right.append(button("+ Tugas di tanggal ini", ["primary"], self._add))
        cols.append(right)
        self.body.append(cols)
        self.refresh()

    # ----- interaksi
    def shift(self, delta):
        self.year, self.month = shift_month(self.year, self.month, delta)
        self.refresh()

    def go_today(self):
        t = date.today()
        self.year, self.month, self.selected = t.year, t.month, t
        self.refresh()

    def _add(self):
        TaskDialog(self.ctx.window, self.ctx.store, preset_date=self.selected).present()

    def _pressed(self, gesture, n_press, x, y):
        d = draw.calendar_hit(self.grid.get_width(), self.grid.get_height(), self.year, self.month, x, y)
        if not d:
            return
        self.selected = d
        if (d.year, d.month) != (self.year, self.month):
            self.year, self.month = d.year, d.month
        self.refresh()
        if n_press >= 2:
            self._add()

    def _motion(self, ctl, x, y):
        d = draw.calendar_hit(self.grid.get_width(), self.grid.get_height(), self.year, self.month, x, y)
        if d != self.hover:
            self.hover = d
            self.grid.queue_draw()

    def _leave(self, ctl):
        self.hover = None
        self.grid.queue_draw()

    def _draw(self, cr, w, h):
        draw.draw_calendar(cr, w, h, self.year, self.month, self.selected, self.hover, self.marks)

    # ----- data
    def refresh(self):
        store = self.ctx.store
        self.month_l.set_text(f"{BULAN[self.month - 1]} {self.year}")
        self.marks = {}
        for t in store.tasks:
            due = parse_dt(t.get("due"))
            if due:
                tot, dn = self.marks.get(due.date(), (0, 0))
                self.marks[due.date()] = (tot + 1, dn + (1 if t.get("done") else 0))
        self.grid.queue_draw()

        d = self.selected
        self.day_title.set_text(tanggal_panjang(d))
        self.day_holiday.set_text(libur(d) or "")
        self.day_holiday.set_visible(bool(libur(d)))
        clear(self.day_list)
        tasks = sorted(store.tasks_on(d), key=lambda t: (t.get("done"), t.get("due")))
        if not tasks:
            self.day_list.append(label("Tidak ada tugas di hari ini.", ["sub"], wrap=True))
        for t in tasks:
            self.day_list.append(make_task_row(self.ctx, t, compact=True))
