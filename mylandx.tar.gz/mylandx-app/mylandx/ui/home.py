from datetime import datetime, date

import gi
gi.require_version("Gtk", "4.0")
from gi.repository import Gtk, GLib

from .. import draw
from ..util import (salam, tanggal_panjang, fmt_jam, next_alarm, durasi, ZONA, waktu_zona, parse_dt)
from .common import vbox, hbox, label, button, Canvas, clear
from .dialogs import TaskDialog, AlarmDialog
from .page import Page
from .taskrow import make_task_row


class HomePage(Page):
    def __init__(self, ctx):
        super().__init__(ctx, "", "")
        self._src = 0
        self.body.append(self.head)

        # --- kartu jam
        clock_card = hbox(26, ["card"])
        self.analog = Canvas(lambda cr, w, h: draw.draw_analog_clock(cr, w, h), 210, 210)
        self.analog.set_valign(Gtk.Align.CENTER)
        clock_card.append(self.analog)
        right = vbox(4)
        right.set_hexpand(True)
        right.set_valign(Gtk.Align.CENTER)
        trow = hbox(8)
        trow.set_valign(Gtk.Align.END)
        self.digital = label("", ["digital"])
        self.seconds = label("", ["seconds"])
        self.seconds.set_valign(Gtk.Align.END)
        self.seconds.set_margin_bottom(14)
        trow.append(self.digital)
        trow.append(self.seconds)
        right.append(trow)
        self.date_l = label("", ["h2"])
        right.append(self.date_l)
        self.zones = hbox(18)
        self.zones.set_margin_top(12)
        self.zone_labels = []
        for name, off in ZONA:
            col = vbox(0)
            col.append(label(name, ["tiny"]))
            l = label("", ["h3"])
            col.append(l)
            self.zones.append(col)
            self.zone_labels.append((l, off))
        right.append(self.zones)
        clock_card.append(right)
        self.body.append(clock_card)

        # --- kartu ringkas
        stats = hbox(16)
        stats.set_homogeneous(True)
        self.s_task = self._stat(stats, "Tugas aktif", "tasks")
        self.s_alarm = self._stat(stats, "Alarm berikutnya", "alarms")
        self.s_focus = self._stat(stats, "Fokus hari ini", "focus")
        self.body.append(stats)

        # --- tugas terdekat + aksi cepat
        lower = hbox(16)
        near = vbox(10, ["card"])
        near.set_hexpand(True)
        head = hbox(8)
        t = label("Tugas terdekat", ["h2"])
        t.set_hexpand(True)
        head.append(t)
        head.append(button("Lihat semua", ["ghost"], lambda: ctx.go("tasks")))
        near.append(head)
        self.near_list = vbox(8)
        near.append(self.near_list)
        lower.append(near)

        quick = vbox(10, ["card"])
        quick.set_size_request(250, -1)
        quick.append(label("Aksi cepat", ["h2"]))
        quick.append(button("Mulai fokus", ["primary"], lambda: ctx.start_focus()))
        quick.append(button("Tugas baru", [], lambda: TaskDialog(ctx.window, ctx.store).present()))
        quick.append(button("Alarm baru", [], lambda: AlarmDialog(ctx.window, ctx.store).present()))
        lower.append(quick)
        self.body.append(lower)

        self.connect("map", self._on_map)
        self.connect("unmap", self._on_unmap)
        self.refresh()
        self._tick()

    def _stat(self, parent, title, page):
        c = vbox(2, ["card"])
        c.append(label(title, ["tiny"]))
        big = label("", ["stat"])
        sub = label("", ["tiny"], ellipsize=True)
        c.append(big)
        c.append(sub)
        click = Gtk.GestureClick()
        click.connect("pressed", lambda *_: self.ctx.go(page))
        c.add_controller(click)
        c.set_cursor_from_name("pointer")
        parent.append(c)
        return big, sub

    def _on_map(self, *_):
        if not self._src:
            self._src = GLib.timeout_add(500, self._tick)

    def _on_unmap(self, *_):
        if self._src:
            GLib.source_remove(self._src)
            self._src = 0

    def _tick(self):
        now = datetime.now()
        st = self.ctx.store.settings
        if st["clock24"]:
            self.digital.set_text(now.strftime("%H:%M"))
            self.seconds.set_text(now.strftime(":%S"))
        else:
            self.digital.set_text(fmt_jam(now, False).rsplit(" ", 1)[0])
            self.seconds.set_text(now.strftime(":%S ") + ("AM" if now.hour < 12 else "PM"))
        self.analog.queue_draw()
        for l, off in self.zone_labels:
            l.set_text(fmt_jam(waktu_zona(off), st["clock24"]))
        return True

    def refresh(self):
        store = self.ctx.store
        now = datetime.now()
        self.h1.set_text(salam(now.hour))
        self.sub.set_text(tanggal_panjang(now.date()))
        self.date_l.set_text(tanggal_panjang(now.date()))

        active = [t for t in store.tasks if not t.get("done")]
        late = [t for t in active if parse_dt(t.get("due")) and parse_dt(t["due"]) < now]
        big, sub = self.s_task
        big.set_text(str(len(active)))
        sub.set_text(f"{len(late)} terlambat" if late else "semua aman")
        sub.remove_css_class("danger-text")
        if late:
            sub.add_css_class("danger-text")

        big, sub = self.s_alarm
        nxt = next_alarm(store.alarms, now)
        if nxt:
            dt, a = nxt
            big.set_text(fmt_jam(dt, store.settings["clock24"]))
            sub.set_text(f"{(a.get('label') or 'Alarm')} · {durasi((dt - now).total_seconds())} lagi")
        else:
            big.set_text("—")
            sub.set_text("tidak ada alarm aktif")

        big, sub = self.s_focus
        rec = store.focus_on(date.today())
        big.set_text(f"{rec['minutes']} mnt")
        sub.set_text(f"{rec['count']} sesi selesai")

        clear(self.near_list)
        def key(t):
            d = parse_dt(t.get("due"))
            return (d is None, d or datetime.max, -t.get("priority", 1))
        top = sorted(active, key=key)[:5]
        if not top:
            self.near_list.append(label("Belum ada tugas aktif. Santai dulu, atau tambah tugas baru.", ["sub"], wrap=True))
        for t in top:
            self.near_list.append(make_task_row(self.ctx, t, compact=True))
