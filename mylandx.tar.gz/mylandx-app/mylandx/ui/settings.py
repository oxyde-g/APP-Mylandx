import gi
gi.require_version("Gtk", "4.0")
from gi.repository import Gtk, Gio

from ..theme import ACCENTS
from .common import vbox, hbox, label, button, Chips, switch_row
from .page import Page


class SettingsPage(Page):
    def __init__(self, ctx):
        super().__init__(ctx, "Pengaturan", "Atur tampilan dan perilaku mylandx.")
        st = ctx.store.settings
        store = ctx.store
        self.body.append(self.head)

        # --- tampilan
        c = vbox(14, ["card"])
        c.append(label("Tampilan", ["h2"]))
        row = hbox(12)
        t = label("Tema", ["h3"])
        t.set_hexpand(True)
        row.append(t)
        self.theme_chips = Chips(["Gelap", "Terang"], 0 if st["theme"] == "dark" else 1,
                                 lambda i: store.set_setting("theme", "dark" if i == 0 else "light"))
        row.append(self.theme_chips)
        c.append(row)

        row = hbox(12)
        t = label("Warna aksen", ["h3"])
        t.set_hexpand(True)
        row.append(t)
        self.swatches = []
        first = None
        for name, hexv in ACCENTS:
            b = Gtk.ToggleButton()
            b.add_css_class("swatch")
            b.set_tooltip_text(name)
            if first is None:
                first = b
            else:
                b.set_group(first)
            b.set_active(hexv.lower() == st["accent"].lower())
            b.connect("toggled", lambda btn, h=hexv: btn.get_active() and store.set_setting("accent", h))
            row.append(b)
            self.swatches.append((b, hexv))
        c.append(row)
        self.body.append(c)
        self._swatch_css = Gtk.CssProvider()
        self._apply_swatch_css()

        # --- umum
        c = vbox(16, ["card"])
        c.append(label("Umum", ["h2"]))
        self.sw = {}
        for key, title, sub in (
            ("clock24", "Format 24 jam", "Matikan untuk tampilan AM/PM."),
            ("sound", "Suara alarm & timer", "Bunyi saat alarm berdering atau sesi fokus selesai."),
            ("notif", "Notifikasi desktop", "Pengingat tugas, alarm, dan timer muncul sebagai notifikasi."),
            ("auto_next", "Lanjut otomatis di Fokus", "Setelah sesi selesai, sesi berikutnya langsung berjalan."),
            ("background", "Tetap berjalan di latar belakang", "Menutup jendela tidak menghentikan alarm. Buka lagi lewat menu aplikasi, atau klik “Keluar” di sidebar untuk menutup total."),
        ):
            r, sw = switch_row(title, sub, st[key], lambda v, k=key: store.set_setting(k, v))
            c.append(r)
            self.sw[key] = sw
        r, self.autostart = switch_row("Mulai otomatis saat login", "Jalan diam-diam di latar belakang begitu kamu login.",
                                       ctx.autostart_enabled(), lambda v: ctx.set_autostart(v))
        c.append(r)

        row = hbox(12)
        t = vbox(2)
        t.set_hexpand(True)
        t.append(label("Sesi fokus sebelum istirahat panjang", ["h3"]))
        row.append(t)
        self.cycles = Gtk.SpinButton.new_with_range(2, 10, 1)
        self.cycles.set_value(st["cycles"])
        self.cycles.connect("value-changed", lambda s: store.set_setting("cycles", s.get_value_as_int()))
        row.append(self.cycles)
        c.append(row)
        self.body.append(c)

        # --- data
        c = vbox(10, ["card"])
        c.append(label("Data", ["h2"]))
        c.append(label(f"Semua data tersimpan lokal di:\n{store.dir}", ["sub"], wrap=True, selectable=True))
        c.append(button("Buka folder data", [], self._open_dir))
        self.body.append(c)

    def _open_dir(self):
        try:
            Gio.AppInfo.launch_default_for_uri(f"file://{self.ctx.store.dir}", None)
        except Exception as e:
            print("mylandx: gagal membuka folder:", e)

    def _apply_swatch_css(self):
        css = "".join(f"button.swatch.sw{i} {{ background: {h}; }}\n" for i, (_, h) in enumerate(self.swatches))
        for i, (b, _) in enumerate(self.swatches):
            b.add_css_class(f"sw{i}")
        try:
            self._swatch_css.load_from_string(css)
        except AttributeError:
            self._swatch_css.load_from_data(css.encode())
        from gi.repository import Gdk
        Gtk.StyleContext.add_provider_for_display(Gdk.Display.get_default(), self._swatch_css, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION + 1)

    def refresh(self):
        st = self.ctx.store.settings
        for key, sw in self.sw.items():
            if sw.get_active() != bool(st[key]):
                sw.set_active(bool(st[key]))
