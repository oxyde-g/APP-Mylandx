from datetime import datetime

import gi
gi.require_version("Gtk", "4.0")
gi.require_version("Gdk", "4.0")
from gi.repository import Gtk, Gdk, GLib

from .. import draw
from ..theme import THEME
from ..util import fmt_jam
from .common import vbox, hbox, label, button, Canvas, pad
from .home import HomePage
from .tasks import TasksPage
from .focus import FocusPage
from .alarms import AlarmsPage
from .calendar import CalendarPage
from .settings import SettingsPage
from .notes import NotesPage
from .music import MusicPage
from .playerbar import PlayerBar

NAV = [("home", "Beranda", "home"), ("tasks", "Tugas", "tasks"), ("focus", "Fokus", "focus"),
       ("alarms", "Alarm", "alarm"), ("calendar", "Kalender", "calendar"), ("notes", "Catatan", "notes"),
       ("music", "Musik", "music"), ("settings", "Pengaturan", "settings")]


class MainWindow(Gtk.ApplicationWindow):
    def __init__(self, app, ctx):
        super().__init__(application=app)
        self.ctx = ctx
        ctx.window = self
        self.add_css_class("mylandx")
        self.set_title("mylandx")
        self.set_default_size(1120, 740)
        self.set_size_request(940, 660)
        self.set_titlebar(Gtk.HeaderBar())
        self._refresh_src = 0

        outer = vbox(0)
        self.set_child(outer)
        root = hbox(0)
        root.set_vexpand(True)
        outer.append(root)
        self.playerbar = PlayerBar(ctx)
        outer.append(self.playerbar)

        # ---------------- sidebar
        side = vbox(4, ["sidebar"])
        side.set_size_request(226, -1)
        pad(side, 14, 12, 14, 12)
        brand = hbox(10)
        brand.set_margin_bottom(12)
        brand.set_margin_start(6)
        self.logo = Canvas(lambda cr, w, h: draw.draw_logo(cr, 0, 0, min(w, h)), 36, 36)
        brand.append(self.logo)
        b = label("mylandx", ["brand"])
        b.set_valign(Gtk.Align.CENTER)
        brand.append(b)
        side.append(brand)

        self.stack = Gtk.Stack()
        self.stack.set_transition_type(Gtk.StackTransitionType.CROSSFADE)
        self.stack.set_transition_duration(140)
        self.stack.set_hexpand(True)
        self.stack.set_vexpand(True)

        self.pages = {
            "home": HomePage(ctx), "tasks": TasksPage(ctx), "focus": FocusPage(ctx),
            "alarms": AlarmsPage(ctx), "calendar": CalendarPage(ctx), "notes": NotesPage(ctx),
            "music": MusicPage(ctx), "settings": SettingsPage(ctx),
        }
        self.nav, self.icons = {}, []
        first = None
        for i, (key, title, icon) in enumerate(NAV):
            btn = Gtk.ToggleButton()
            btn.add_css_class("nav")
            if first is None:
                first = btn
            else:
                btn.set_group(first)
            row = hbox(12)
            cv = Canvas(lambda cr, w, h, k=icon, bt=btn: draw.draw_icon(
                cr, k, 0, 0, 22, THEME.rgba("accent" if bt.get_active() else "muted")), 22, 22)
            row.append(cv)
            row.append(label(title))
            btn.set_child(row)
            btn.set_tooltip_text(f"{title}  (Ctrl+{i + 1})")
            btn.connect("toggled", self._nav_toggled, key, cv)
            side.append(btn)
            self.nav[key] = btn
            self.icons.append(cv)
            self.stack.add_named(self.pages[key], key)

        spacer = Gtk.Box()
        spacer.set_vexpand(True)
        side.append(spacer)
        foot = vbox(6, ["card-flat"])
        self.foot_time = label("", ["h3"])
        foot.append(self.foot_time)
        foot.append(button("Keluar", ["ghost", "danger"], lambda: app.quit(), "Tutup mylandx sepenuhnya (alarm berhenti)"))
        side.append(foot)

        root.append(side)
        root.append(self.stack)
        first.set_active(True)

        key = Gtk.EventControllerKey()
        key.connect("key-pressed", self._key)
        self.add_controller(key)
        self.connect("close-request", self._close)
        ctx.engine.on_minute.append(self._minute)
        self._minute()

    # ---------------- navigasi
    def _nav_toggled(self, btn, key, cv):
        cv.queue_draw()
        if btn.get_active():
            self.stack.set_visible_child_name(key)
            self.pages[key].refresh()

    def go(self, key):
        self.nav[key].set_active(True)

    def _key(self, ctl, keyval, keycode, state):
        if state & Gdk.ModifierType.CONTROL_MASK and Gdk.KEY_1 <= keyval < Gdk.KEY_1 + len(NAV):
            self.go(NAV[keyval - Gdk.KEY_1][0])
            return True
        return False

    def flush_all(self):
        """Simpan apa pun yang belum tersimpan (catatan yang sedang diketik, dll.)."""
        for p in self.pages.values():
            fl = getattr(p, "flush", None)
            if fl:
                fl()

    def _close(self, *_):
        self.flush_all()
        if self.ctx.store.settings["background"]:
            self.set_visible(False)
            return True
        return False

    # ---------------- refresh
    def _minute(self):
        self.foot_time.set_text(fmt_jam(datetime.now(), self.ctx.store.settings["clock24"]))
        self.schedule_refresh()

    def schedule_refresh(self):
        """Gabungkan banyak perubahan data menjadi satu refresh (juga aman dipanggil dari dalam signal widget)."""
        if not self._refresh_src:
            self._refresh_src = GLib.idle_add(self._do_refresh)

    def _do_refresh(self):
        self._refresh_src = 0
        for p in self.pages.values():
            p.refresh()
        for cv in self.icons:
            cv.queue_draw()
        self.logo.queue_draw()
        return False
