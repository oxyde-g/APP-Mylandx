"""Mesin latar: cek alarm & pengingat tugas tiap detik, suara, notifikasi."""
import math
import shutil
import struct
import subprocess
import wave
from datetime import datetime, timedelta

from gi.repository import GLib

from .util import parse_dt, due_label


# ---------------------------------------------------------------- suara
def _synth(path, events, length, sr=44100):
    """events: [(freq, start, dur, vol)] -> WAV mono 16-bit, bunyi lonceng lembut."""
    n = int(sr * length)
    buf = [0.0] * n
    for freq, start, dur, vol in events:
        s0 = int(start * sr)
        for i in range(int(dur * sr)):
            j = s0 + i
            if j >= n:
                break
            t = i / sr
            env = math.exp(-t * 5.0) * min(1.0, t * 400)
            v = (math.sin(2 * math.pi * freq * t)
                 + 0.35 * math.sin(2 * math.pi * freq * 2.01 * t)
                 + 0.12 * math.sin(2 * math.pi * freq * 3.02 * t))
            buf[j] += v * env * vol
    peak = max(1e-9, max(abs(x) for x in buf))
    data = b"".join(struct.pack("<h", int(max(-1, min(1, x / peak * 0.8)) * 32767)) for x in buf)
    with wave.open(str(path), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(sr)
        w.writeframes(data)


class Sound:
    LOOP_MS = 3000

    def __init__(self, store):
        self.store = store
        self.player = next((p for p in ("pw-play", "paplay", "aplay") if shutil.which(p)), None)
        self.files = {}
        self._src = 0
        self._procs = []
        self._users = 0

    def _file(self, kind):
        path = self.store.dir / f"{kind}.wav"
        if not path.exists():
            try:
                if kind == "alarm":
                    ev = []
                    for rep in (0.0, 1.5):
                        for k, f in enumerate((1046.5, 1318.5, 1568.0, 2093.0)):
                            ev.append((f, rep + k * 0.22, 1.0, 1.0))
                    _synth(path, ev, 2.9)
                else:  # ding: tanda selesai timer
                    _synth(path, [(1318.5, 0.0, 1.2, 1.0), (1760.0, 0.18, 1.2, 0.8), (2093.0, 0.36, 1.3, 0.7)], 1.8)
            except OSError:
                return None
        return str(path)

    def _spawn(self, kind):
        if not self.store.settings.get("sound", True):
            return
        path = self._file(kind)
        if not (self.player and path):
            return
        self._procs = [p for p in self._procs if p.poll() is None]
        try:
            self._procs.append(subprocess.Popen([self.player, path], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL))
        except OSError:
            pass

    def once(self, kind="ding"):
        self._spawn(kind)

    def start_loop(self):
        self._users += 1
        if self._src:
            return
        self._spawn("alarm")
        self._src = GLib.timeout_add(self.LOOP_MS, self._again)

    def _again(self):
        self._spawn("alarm")
        return True

    def stop_loop(self):
        self._users = max(0, self._users - 1)
        if self._users == 0 and self._src:
            GLib.source_remove(self._src)
            self._src = 0
            for p in self._procs:
                if p.poll() is None:
                    p.terminate()
            self._procs = []


# ---------------------------------------------------------------- notifikasi
class Notifier:
    def __init__(self, store):
        self.store = store
        self.app = None  # diisi oleh Gtk.Application

    def send(self, title, body, urgent=False, nid=None):
        if not self.store.settings.get("notif", True):
            return
        try:
            if self.app is not None:
                from gi.repository import Gio
                n = Gio.Notification.new(title)
                n.set_body(body)
                n.set_priority(Gio.NotificationPriority.URGENT if urgent else Gio.NotificationPriority.NORMAL)
                n.set_default_action("app.show")
                self.app.send_notification(nid, n)
            elif shutil.which("notify-send"):
                subprocess.Popen(["notify-send", "-a", "mylandx", title, body],
                                 stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception as e:  # notifikasi tidak boleh membuat app crash
            print("mylandx: notifikasi gagal:", e)


# ---------------------------------------------------------------- mesin
class Engine:
    def __init__(self, store, sound, notifier):
        self.store, self.sound, self.notifier = store, sound, notifier
        self.on_ring = lambda alarm: None     # dipasang UI
        self.on_minute = []                   # callback tiap pergantian menit
        self._snooze = {}                     # id alarm -> datetime
        self._last_minute = None
        self._src = GLib.timeout_add(1000, self._tick)

    def _tick(self):
        try:
            self.tick()
        except Exception as e:
            print("mylandx: tick error:", e)
        return True

    def tick(self, now=None):
        now = now or datetime.now()
        key = now.strftime("%Y-%m-%d %H:%M")
        hhmm = now.strftime("%H:%M")

        for a in list(self.store.alarms):
            if not a.get("enabled"):
                continue
            snooze_at = self._snooze.get(a["id"])
            fire = False
            if snooze_at and now >= snooze_at:
                fire = True
                self._snooze.pop(a["id"], None)
            elif a["time"] == hhmm and a.get("last_fired") != key and (not a.get("days") or now.weekday() in a["days"]):
                fire = True
                self.store.mark_alarm_fired(a["id"], key, disable=not a.get("days"))
            if fire:
                self.ring(a)

        if self.store.settings.get("notif", True):
            for t in list(self.store.tasks):
                if t.get("done") or not t.get("due") or t.get("remind", -1) < 0 or t.get("reminded"):
                    continue
                due = parse_dt(t["due"])
                if not due:
                    continue
                trigger = due - timedelta(minutes=t["remind"])
                if now >= trigger:
                    self.store.mark_reminded(t["id"])
                    if (now - trigger).total_seconds() <= 6 * 3600:  # kalau telat banget, jangan spam
                        self.notifier.send("Pengingat tugas", f"{t['title']}\n{due_label(due, now, self.store.settings['clock24'])}",
                                           urgent=True, nid="task-" + t["id"])

        if key != self._last_minute:
            self._last_minute = key
            for fn in list(self.on_minute):
                fn()

    def ring(self, alarm):
        self.notifier.send(alarm.get("label") or "Alarm", alarm["time"], urgent=True, nid="alarm-" + alarm["id"])
        self.on_ring(alarm)

    def snooze(self, alarm, minutes=5):
        self._snooze[alarm["id"]] = datetime.now() + timedelta(minutes=minutes)
        if not alarm.get("enabled"):  # alarm sekali pakai sudah dimatikan saat bunyi; hidupkan lagi untuk tunda
            self.store.update_alarm(alarm["id"], enabled=True)
