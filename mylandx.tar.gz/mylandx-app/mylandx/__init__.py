"""mylandx — pengingat tugas, timer belajar, alarm, jam & kalender untuk Linux."""
APP_ID = "org.mylandx.Mylandx"
APP_NAME = "mylandx"
__version__ = "1.2.0"
