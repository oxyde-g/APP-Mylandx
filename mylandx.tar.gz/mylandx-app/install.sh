#!/usr/bin/env bash
# Installer mylandx untuk Fedora Linux (tanpa root, kecuali kalau ada paket yang kurang).
set -euo pipefail
cd "$(dirname "$0")"

PREFIX="${HOME}/.local"
APP_ID="org.mylandx.Mylandx"

echo "==> Memeriksa dependensi"
need=()
/usr/bin/python3 -c 'import gi; gi.require_version("Gtk","4.0"); from gi.repository import Gtk' 2>/dev/null || need+=(python3-gobject gtk4)
/usr/bin/python3 -c 'import cairo' 2>/dev/null || need+=(python3-cairo)
command -v mpv >/dev/null || need+=(mpv)   # pemutar musik
if ! command -v pw-play >/dev/null && ! command -v paplay >/dev/null; then need+=(pipewire-utils); fi
if [ ${#need[@]} -gt 0 ]; then
    echo "    Paket yang perlu dipasang: ${need[*]}"
    sudo dnf install -y "${need[@]}"
else
    echo "    Semua dependensi sudah ada."
fi

echo "==> Memasang ke ${PREFIX}"
install -d "${PREFIX}/lib/mylandx" "${PREFIX}/bin" "${PREFIX}/share/applications" \
           "${PREFIX}/share/icons/hicolor/scalable/apps" "${PREFIX}/share/icons/hicolor/256x256/apps"
rm -rf "${PREFIX}/lib/mylandx/mylandx"
cp -r mylandx "${PREFIX}/lib/mylandx/"
find "${PREFIX}/lib/mylandx" -name __pycache__ -type d -prune -exec rm -rf {} +

# launcher memakai python sistem (/usr/bin/python3) supaya selalu menemukan PyGObject
sed '1s|.*|#!/usr/bin/python3|' bin/mylandx > "${PREFIX}/bin/mylandx"
chmod 755 "${PREFIX}/bin/mylandx"

install -m644 "data/${APP_ID}.svg" "${PREFIX}/share/icons/hicolor/scalable/apps/${APP_ID}.svg"
install -m644 "data/${APP_ID}.png" "${PREFIX}/share/icons/hicolor/256x256/apps/${APP_ID}.png"
sed "s|@EXEC@|${PREFIX}/bin/mylandx|" "data/${APP_ID}.desktop" > "${PREFIX}/share/applications/${APP_ID}.desktop"
chmod 644 "${PREFIX}/share/applications/${APP_ID}.desktop"

update-desktop-database "${PREFIX}/share/applications" 2>/dev/null || true
gtk-update-icon-cache -f -t "${PREFIX}/share/icons/hicolor" 2>/dev/null || true
gtk4-update-icon-cache -f -t "${PREFIX}/share/icons/hicolor" 2>/dev/null || true

echo
echo "Selesai! Buka dari menu aplikasi (cari “mylandx”) atau jalankan:  mylandx"
case ":${PATH}:" in *":${PREFIX}/bin:"*) ;; *) echo "Catatan: ${PREFIX}/bin belum ada di PATH — logout/login sekali, atau pakai ${PREFIX}/bin/mylandx";; esac
