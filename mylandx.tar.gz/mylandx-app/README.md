# mylandx

App desktop ringan untuk Fedora Linux: **pengingat tugas, timer belajar (Pomodoro), alarm, jam, dan kalender**.
Dibuat dengan Python + GTK4 — tidak butuh Electron, tidak ada layanan latar yang berat, datanya lokal di komputermu.

## Pasang
```bash
tar xzf mylandx.tar.gz && cd mylandx-app
./install.sh
```
Lalu buka dari menu aplikasi (cari "mylandx") atau ketik `mylandx` di terminal.
Mau coba tanpa memasang? `./bin/mylandx`

Dependensi (dipasang otomatis kalau kurang): `python3-gobject`, `gtk4`, `python3-cairo`, `pipewire-utils`, `mpv` (pemutar musik).

## Fitur
| Halaman | Isi |
|---|---|
| **Beranda** | Jam analog + digital, tanggal, jam WIB/WITA/WIT/UTC, ringkasan tugas, alarm berikutnya, fokus hari ini |
| **Tugas** | Tambah cepat (Enter), tenggat, prioritas, catatan, pengingat (tepat waktu s/d 1 hari sebelum), filter, penanda terlambat |
| **Fokus** | Timer Pomodoro (fokus / istirahat / istirahat panjang), durasi bebas, kaitkan ke tugas, statistik 7 hari |
| **Alarm** | Banyak alarm, ulang per hari (hari kerja, akhir pekan, dst.), tunda 5 menit, suara lonceng |
| **Kalender** | Tampilan bulan, titik penanda tugas, libur nasional tanggal tetap, klik 2x untuk tambah tugas |
| **Catatan** | Editor teks (tombol *Hapus* di tiap catatan) dengan simpan otomatis (±0,6 detik setelah berhenti mengetik), cari, sematkan, hitung kata. Cadangan berlapis: `data.bak.json` + snapshot harian 14 hari di `backups/`, dan data rusak dipulihkan otomatis |
| **Musik** | Pemutar **lokal**: tambah file/folder musikmu, putar dengan antrean + acak/ulang, favorit, dan **album buatan sendiri** untuk memisahkan lagu per kategori. Bisa hapus lagu dari daftar (file aslinya tidak disentuh), keluarkan dari album, ubah nama/hapus album. Bar pemutar di bawah dengan tombol ✕ untuk menutup |
| **Pengaturan** | Tema gelap/terang, 6 warna aksen, 24 jam/AM-PM, suara, notifikasi, jalan di latar belakang, mulai saat login |

Pintasan: `Ctrl+1…8` pindah halaman, `Ctrl+Q` keluar, `Esc` menutup dialog.

## Catatan
* **Latar belakang**: aktifkan "Tetap berjalan di latar belakang" di Pengaturan agar alarm tetap bunyi saat jendela ditutup. Buka lagi dengan menjalankan mylandx; tombol **Keluar** di sidebar menutup total.
* **Libur nasional** yang tampil hanya yang tanggalnya tetap (1 Jan, 1 Mei, 1 Jun, 17 Agu, 25 Des). Libur yang bergeser tiap tahun tidak ikut.
* **Data**: `~/.local/share/mylandx/data.json` (cadangan otomatis kalau file rusak). Aman di-backup / disalin ke laptop lain.
* **Copot**: `./uninstall.sh` (tambah `--purge` untuk hapus data).
* Kalau tampilan terasa janggal atau ada error, jalankan dari terminal (`mylandx`) dan kirim pesan error-nya.
